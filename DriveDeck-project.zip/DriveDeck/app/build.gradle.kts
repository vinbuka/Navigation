plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.drivedeck"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.drivedeck"
        minSdk = 29
        targetSdk = 34
        versionCode = 5
        versionName = "0.5.0"
        // только процессоры телефонов (без x86) — вдвое меньше размер APK
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
        resourceConfigurations += listOf("ru", "uk", "en")
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            // подпись отладочным ключом, чтобы APK можно было просто установить
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.media:media:1.7.0")
    implementation("org.maplibre.gl:android-sdk:11.5.2")
}
