package com.drivedeck

object Phrases {
    private fun isRound(s: Step) = s.type == "roundabout" || s.type == "rotary" || s.type == "roundabout turn"

    fun arrow(s: Step): String = when {
        s.type == "arrive" -> "🏁"
        isRound(s) -> "⟳"
        else -> when (s.modifier) {
            "left" -> "⬅"
            "right" -> "➡"
            "slight left" -> "↖"
            "slight right" -> "↗"
            "sharp left" -> "↙"
            "sharp right" -> "↘"
            "uturn" -> "↩"
            else -> "⬆"
        }
    }

    /** Не озвучивать «продолжайте прямо» на каждой смене названия улицы. */
    fun silent(s: Step) =
        (s.type == "new name" || s.type == "continue") && (s.modifier == "" || s.modifier == "straight")

    private fun dir(mod: String, uk: Boolean): String = when (mod) {
        "left" -> if (uk) "ліворуч" else "налево"
        "right" -> if (uk) "праворуч" else "направо"
        "slight left" -> if (uk) "лівіше" else "левее"
        "slight right" -> if (uk) "правіше" else "правее"
        "sharp left" -> if (uk) "різко ліворуч" else "резко налево"
        "sharp right" -> if (uk) "різко праворуч" else "резко направо"
        else -> if (uk) "прямо" else "прямо"
    }

    fun maneuver(s: Step, d: Int, lang: String): String {
        val uk = lang == "uk"
        if (s.type == "arrive" && d <= 40) {
            return if (uk) "Ви прибули до пункту призначення" else "Вы прибыли в пункт назначения"
        }
        val via = if (d <= 40) "" else if (uk) "Через $d метрів, " else "Через $d метров, "
        val body = when {
            s.type == "arrive" -> if (uk) "ви прибудете до пункту призначення" else "вы прибудете в пункт назначения"
            isRound(s) -> if (uk) "круговий рух" else "круговое движение"
            s.modifier == "straight" -> if (uk) "рухайтесь прямо" else "двигайтесь прямо"
            s.modifier == "uturn" -> if (uk) "розвернітеся" else "развернитесь"
            else -> (if (uk) "поверніть " else "поверните ") + dir(s.modifier, uk)
        }
        return (via + body).replaceFirstChar { it.titlecase() }
    }

    fun started(lang: String) = if (lang == "uk") "Маршрут побудовано" else "Маршрут построен"
    fun deviation(lang: String) =
        if (lang == "uk") "Ви відхилилися від маршруту. Перераховую." else "Вы отклонились от маршрута. Пересчитываю."
    fun test(lang: String) = if (lang == "uk") "Перевірка голосу" else "Проверка голоса"
}
