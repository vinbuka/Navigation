package com.drivedeck

import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

fun haversine(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
    val r = 6371000.0
    val dLat = Math.toRadians(lat2 - lat1)
    val dLon = Math.toRadians(lon2 - lon1)
    val a = sin(dLat / 2) * sin(dLat / 2) +
        cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2) * sin(dLon / 2)
    return 2 * r * asin(sqrt(a))
}

class Navigator(val route: Route) {
    class Update(val step: Step, val dist: Double, val announce: Int, val off: Boolean, val arrived: Boolean)

    private var idx = if (route.steps.size > 1) 1 else 0
    private var minD = Double.MAX_VALUE
    private var offCount = 0
    private val announced = HashSet<Int>()
    private val thresholds = listOf(40, 200, 500)

    fun distToRoute(lat: Double, lon: Double): Double = distToPts(route.pts, lat, lon)

    fun update(lat: Double, lon: Double): Update {
        val steps = route.steps
        val last = steps.size - 1
        var st = steps[idx]
        var d = haversine(lat, lon, st.lat, st.lon)
        if (d < minD) minD = d
        val passed = minD < 80 && d > minD + 60
        if ((d < 35 || passed) && idx < last) {
            idx++
            announced.clear()
            minD = Double.MAX_VALUE
            st = steps[idx]
            d = haversine(lat, lon, st.lat, st.lon)
        }
        val arrived = idx == last && d < 30

        var announce = 0
        val t = thresholds.firstOrNull { d <= it }
        if (t != null && t !in announced) {
            announced.addAll(thresholds.filter { it >= t })
            announce = t
        }

        if (distToRoute(lat, lon) > 60) offCount++ else offCount = 0
        return Update(st, d, announce, offCount >= 3, arrived)
    }
}

/** Расстояние (м) от точки до ломаной. */
fun distToPts(pts: List<DoubleArray>, lat: Double, lon: Double): Double {
    var best = Double.MAX_VALUE
    val k = cos(Math.toRadians(lat))
    for (i in 0 until pts.size - 1) {
        val ax = (pts[i][1] - lon) * k
        val ay = pts[i][0] - lat
        val bx = (pts[i + 1][1] - lon) * k
        val by = pts[i + 1][0] - lat
        val dx = bx - ax
        val dy = by - ay
        val l2 = dx * dx + dy * dy
        var t = if (l2 == 0.0) 0.0 else (-ax * dx - ay * dy) / l2
        t = t.coerceIn(0.0, 1.0)
        val px = ax + t * dx
        val py = ay + t * dy
        val d = sqrt(px * px + py * py) * 111320.0
        if (d < best) best = d
    }
    return best
}
