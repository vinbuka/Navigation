package com.drivedeck

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.location.LocationManager
import android.provider.Settings

/** Через 5 минут после закрытия приложения напоминает выключить геолокацию, которую включили для навигации. */
class LocationReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val lm = context.getSystemService(LocationManager::class.java)
        if (!lm.isLocationEnabled) return // уже выключена
        val uk = Prefs(context).uiLang == "uk"
        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(
                "loc_reminder",
                if (uk) "Нагадування про геолокацію" else "Напоминание о геолокации",
                NotificationManager.IMPORTANCE_DEFAULT
            )
        )
        val open = PendingIntent.getActivity(
            context, 0, Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(context, "loc_reminder")
            .setSmallIcon(R.drawable.ic_locate)
            .setContentTitle("DriveDeck")
            .setContentText(
                if (uk) "Геолокація лишилась увімкненою. Натисніть, щоб вимкнути."
                else "Геолокация осталась включённой. Нажмите, чтобы выключить."
            )
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(42, n)
    }
}
