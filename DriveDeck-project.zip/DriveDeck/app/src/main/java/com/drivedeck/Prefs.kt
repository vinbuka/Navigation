package com.drivedeck

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("drivedeck", Context.MODE_PRIVATE)

    /** auto | portrait | landscape */
    var orientation: String
        get() = sp.getString("orientation", "auto") ?: "auto"
        set(v) { sp.edit().putString("orientation", v).apply() }

    /** auto | day | night */
    var theme: String
        get() = sp.getString("theme", "auto") ?: "auto"
        set(v) { sp.edit().putString("theme", v).apply() }

    /** ru | uk */
    var lang: String
        get() = sp.getString("lang", "ru") ?: "ru"
        set(v) { sp.edit().putString("lang", v).apply() }

    /** sedan | suv | truck | moto | arrow */
    var carType: String
        get() = sp.getString("carType", "sedan") ?: "sedan"
        set(v) { sp.edit().putString("carType", v).apply() }

    var carColor: Int
        get() = sp.getInt("carColor", 0xFF1E88E5.toInt())
        set(v) { sp.edit().putInt("carColor", v).apply() }
}
