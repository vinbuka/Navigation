package com.drivedeck

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("drivedeck", Context.MODE_PRIVATE)

    /** auto | portrait | landscape */
    var orientation: String
        get() = sp.getString("orientation", "auto") ?: "auto"
        set(v) { sp.edit().putString("orientation", v).apply() }

    /** auto | day | night */
    var theme: String
        get() = sp.getString("theme", "auto") ?: "auto"
        set(v) { sp.edit().putString("theme", v).apply() }

    /** ru | uk */
    var lang: String
        get() = sp.getString("lang", "ru") ?: "ru"
        set(v) { sp.edit().putString("lang", v).apply() }

    var carType: String
        get() = sp.getString("carType", "sedan") ?: "sedan"
        set(v) { sp.edit().putString("carType", v).apply() }

    var carColor: Int
        get() = sp.getInt("carColor", 0xFF1E88E5.toInt())
        set(v) { sp.edit().putInt("carColor", v).apply() }

    // ---- положение камеры (в том числе наклон) ----
    fun hasCamera() = sp.contains("camLat")
    val camLat: Double get() = sp.getFloat("camLat", 49f).toDouble()
    val camLon: Double get() = sp.getFloat("camLon", 31f).toDouble()
    val camZoom: Double get() = sp.getFloat("camZoom", 5.5f).toDouble()
    val camTilt: Double get() = sp.getFloat("camTilt", 0f).toDouble()
    val camBearing: Double get() = sp.getFloat("camBearing", 0f).toDouble()

    fun saveCamera(lat: Double, lon: Double, zoom: Double, tilt: Double, bearing: Double) {
        sp.edit()
            .putFloat("camLat", lat.toFloat())
            .putFloat("camLon", lon.toFloat())
            .putFloat("camZoom", zoom.toFloat())
            .putFloat("camTilt", tilt.toFloat())
            .putFloat("camBearing", bearing.toFloat())
            .apply()
    }

    // ---- последние места, дом, работа ----
    private fun toJson(p: Place) = JSONObject().put("n", p.name).put("la", p.lat).put("lo", p.lon)
    private fun fromJson(o: JSONObject) = Place(o.getString("n"), o.getDouble("la"), o.getDouble("lo"))

    fun recents(): List<Place> {
        val s = sp.getString("recents", null) ?: return emptyList()
        return try {
            val a = JSONArray(s)
            val out = ArrayList<Place>()
            for (i in 0 until a.length()) out.add(fromJson(a.getJSONObject(i)))
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun addRecent(p: Place) {
        val list = ArrayList<Place>()
        list.add(p)
        for (r in recents()) if (r.name != p.name) list.add(r)
        val a = JSONArray()
        for (x in list.take(5)) a.put(toJson(x))
        sp.edit().putString("recents", a.toString()).apply()
    }

    fun place(key: String): Place? {
        val s = sp.getString("place_$key", null) ?: return null
        return try { fromJson(JSONObject(s)) } catch (e: Exception) { null }
    }

    fun setPlace(key: String, p: Place) {
        sp.edit().putString("place_$key", toJson(p).toString()).apply()
    }

    /** Номер для имени по умолчанию: «Точка назначения N». */
    fun nextPointNumber(): Int {
        val n = sp.getInt("pointNo", 0) + 1
        sp.edit().putInt("pointNo", n).apply()
        return n
    }
}
