package com.drivedeck

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.session.MediaSessionManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.support.v4.media.session.MediaControllerCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.sources.GeoJsonSource
import java.util.Calendar
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : Activity() {

    companion object {
        private const val STYLE_URL = "https://tiles.openfreemap.org/styles/liberty"
        private const val YTM = "com.google.android.apps.youtube.music"
        private const val REQ_LOCATION = 1
        private const val ZOOM = 17.0
    }

    private lateinit var prefs: Prefs
    private lateinit var voice: Voice
    private lateinit var offline: OfflineMaps
    private lateinit var mapView: MapView
    private lateinit var status: TextView
    private lateinit var nightDim: View
    private lateinit var car: ImageView
    private lateinit var bar: LinearLayout
    private lateinit var navPanel: LinearLayout
    private lateinit var navArrow: TextView
    private lateinit var navDist: TextView
    private lateinit var navStreet: TextView
    private lateinit var navInfo: TextView

    private var map: MapLibreMap? = null
    private var styleReady = false
    private var lastBearing = 0.0
    private var lastLoc: Location? = null

    private var navigator: Navigator? = null
    private var currentRoute: Route? = null
    private var dest: Place? = null
    @Volatile private var recalculating = false
    private var lastRecalcAt = 0L

    private val handler = Handler(Looper.getMainLooper())
    private val themeTick = object : Runnable {
        override fun run() {
            applyTheme()
            handler.postDelayed(this, 60000L)
        }
    }

    private val locationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) = onFix(location)
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, s: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {
            status.text = "GPS выключен"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        applyOrientation()
        MapLibre.getInstance(this)
        setContentView(R.layout.activity_main)
        goFullscreen()

        mapView = findViewById(R.id.mapView)
        status = findViewById(R.id.status)
        nightDim = findViewById(R.id.nightDim)
        car = findViewById(R.id.car)
        refreshCar()
        bar = findViewById(R.id.bar)
        navPanel = findViewById(R.id.navPanel)
        navArrow = findViewById(R.id.navArrow)
        navDist = findViewById(R.id.navDist)
        navStreet = findViewById(R.id.navStreet)
        navInfo = findViewById(R.id.navInfo)
        status.text = "Ожидание GPS…"

        voice = Voice(this, prefs.lang) { msg -> runOnUiThread { toast(msg) } }
        offline = OfflineMaps(this, STYLE_URL)

        mapView.onCreate(savedInstanceState)
        mapView.getMapAsync { m ->
            map = m
            m.setStyle(STYLE_URL) { style ->
                style.addSource(GeoJsonSource("route-src", Net.EMPTY_GEOJSON))
                style.addLayer(
                    LineLayer("route-layer", "route-src").withProperties(
                        PropertyFactory.lineColor(Color.parseColor("#1E88E5")),
                        PropertyFactory.lineWidth(7f),
                        PropertyFactory.lineCap(Property.LINE_CAP_ROUND),
                        PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND)
                    )
                )
                styleReady = true
                if (currentRoute != null) drawRoute(currentRoute)
            }
            m.addOnMapLongClickListener {
                showMenu()
                true
            }
        }

        findViewById<Button>(R.id.btnPrev).setOnClickListener {
            controller()?.transportControls?.skipToPrevious()
        }
        findViewById<Button>(R.id.btnNext).setOnClickListener {
            controller()?.transportControls?.skipToNext()
        }
        findViewById<Button>(R.id.btnPlay).setOnClickListener {
            val c = controller() ?: return@setOnClickListener
            if (c.playbackState?.state == PlaybackStateCompat.STATE_PLAYING) c.transportControls.pause()
            else c.transportControls.play()
        }
        findViewById<Button>(R.id.btnShuffle).setOnClickListener {
            val c = controller() ?: return@setOnClickListener
            val on = c.shuffleMode == PlaybackStateCompat.SHUFFLE_MODE_ALL ||
                c.shuffleMode == PlaybackStateCompat.SHUFFLE_MODE_GROUP
            c.transportControls.setShuffleMode(
                if (on) PlaybackStateCompat.SHUFFLE_MODE_NONE else PlaybackStateCompat.SHUFFLE_MODE_ALL
            )
            toast("Команда перемешивания отправлена: " + if (on) "выкл" else "вкл")
        }

        applyTheme()
        startLocation()
    }

    // ---------- GPS и навигация ----------

    private fun startLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), REQ_LOCATION)
            return
        }
        val lm = getSystemService(LocationManager::class.java)
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, locationListener)
        } catch (e: SecurityException) {
            status.text = "Нет доступа к GPS"
        } catch (e: IllegalArgumentException) {
            status.text = "GPS недоступен на устройстве"
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code == REQ_LOCATION) {
            if (results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) startLocation()
            else status.text = "Разрешите доступ к геопозиции в настройках"
        }
    }

    private fun onFix(loc: Location) {
        lastLoc = loc
        status.text = "GPS: ${(loc.speed * 3.6f).toInt()} км/ч"
        if (loc.hasBearing() && loc.speed > 1f) lastBearing = loc.bearing.toDouble()
        map?.moveCamera(
            CameraUpdateFactory.newCameraPosition(
                CameraPosition.Builder()
                    .target(LatLng(loc.latitude, loc.longitude))
                    .zoom(ZOOM).bearing(lastBearing).tilt(0.0).build()
            )
        )

        val nav = navigator ?: return
        val u = nav.update(loc.latitude, loc.longitude)
        if (u.arrived) {
            voice.speak(Phrases.maneuver(u.step, 0, prefs.lang))
            cancelNavigation(true)
            toast("Вы прибыли")
            return
        }
        navArrow.text = Phrases.arrow(u.step)
        navDist.text = fmtDist(u.dist)
        navStreet.text = u.step.street
        if (u.announce > 0 && !Phrases.silent(u.step)) {
            voice.speak(Phrases.maneuver(u.step, u.announce, prefs.lang))
        }
        if (u.off) recalc(loc)
    }

    private fun recalc(loc: Location) {
        val d = dest ?: return
        val now = System.currentTimeMillis()
        if (recalculating || now - lastRecalcAt < 10000L) return
        recalculating = true
        lastRecalcAt = now
        voice.speak(Phrases.deviation(prefs.lang))
        Thread {
            try {
                val rs = Net.routes(loc.latitude, loc.longitude, d.lat, d.lon)
                runOnUiThread {
                    recalculating = false
                    if (dest != null) startNavigation(rs[0], true)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    recalculating = false
                    toast("Не удалось пересчитать маршрут (нужен интернет)")
                }
            }
        }.start()
    }

    private fun startNavigation(route: Route, silent: Boolean = false) {
        navigator = Navigator(route)
        drawRoute(route)
        navPanel.visibility = View.VISIBLE
        val first = route.steps[if (route.steps.size > 1) 1 else 0]
        navArrow.text = Phrases.arrow(first)
        navDist.text = ""
        navStreet.text = first.street
        navInfo.text = "Всего: ${fmtDist(route.distance)} · ${fmtTime(route.duration)}"
        if (!silent) voice.speak(Phrases.started(prefs.lang))
    }

    private fun cancelNavigation(quiet: Boolean = false) {
        if (navigator == null && !quiet) {
            toast("Навигация не запущена")
            return
        }
        navigator = null
        dest = null
        drawRoute(null)
        navPanel.visibility = View.GONE
        if (!quiet) toast("Навигация отменена")
    }

    private fun drawRoute(r: Route?) {
        currentRoute = r
        if (!styleReady) return
        map?.style?.getSourceAs<GeoJsonSource>("route-src")?.setGeoJson(Net.routeJson(r))
    }

    // ---------- Поиск и выбор маршрута (ОНЛАЙН) ----------

    private fun askDestination() {
        if (lastLoc == null) {
            toast("Нет сигнала GPS — сначала дождитесь определения позиции")
            return
        }
        val input = EditText(this)
        input.hint = "Адрес или населённый пункт"
        input.setSingleLine()
        AlertDialog.Builder(this)
            .setTitle("Куда едем? (поиск онлайн)")
            .setView(input)
            .setPositiveButton("Найти") { _, _ -> search(input.text.toString()) }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun search(q: String) {
        if (q.isBlank()) return
        toast("Поиск…")
        val lang = prefs.lang
        Thread {
            try {
                val res = Net.geocode(q, lang)
                runOnUiThread { if (res.isEmpty()) toast("Ничего не найдено") else pickPlace(res) }
            } catch (e: Exception) {
                runOnUiThread { toast("Поиск не удался (нужен интернет)") }
            }
        }.start()
    }

    private fun pickPlace(res: List<Place>) {
        AlertDialog.Builder(this)
            .setTitle("Выберите место")
            .setItems(res.map { it.name }.toTypedArray()) { _, i -> buildRoutes(res[i]) }
            .show()
    }

    private fun buildRoutes(place: Place) {
        val loc = lastLoc ?: return
        toast("Прокладываю маршрут…")
        Thread {
            try {
                val rs = Net.routes(loc.latitude, loc.longitude, place.lat, place.lon)
                runOnUiThread { pickRoute(rs, place) }
            } catch (e: Exception) {
                runOnUiThread { toast("Маршрут не построен (нужен интернет или дорога не найдена)") }
            }
        }.start()
    }

    private fun pickRoute(rs: List<Route>, place: Place) {
        if (rs.size == 1) {
            dest = place
            startNavigation(rs[0])
            return
        }
        val items = rs.mapIndexed { i, r ->
            "Маршрут ${i + 1}: ${fmtDist(r.distance)}, ${fmtTime(r.duration)}" + if (i == 0) " (быстрый)" else ""
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Выберите дорогу")
            .setItems(items) { _, i ->
                dest = place
                startNavigation(rs[i])
            }
            .show()
    }

    // ---------- Меню и настройки ----------

    private fun showMenu() {
        val items = arrayOf("Музыка (YouTube Music)", "Куда едем?", "Отменить навигацию", "Загрузка карт", "Настройки")
        AlertDialog.Builder(this)
            .setItems(items) { _, i ->
                when (i) {
                    0 -> openYouTubeMusic()
                    1 -> askDestination()
                    2 -> cancelNavigation()
                    3 -> offline.show()
                    4 -> showSettings()
                }
            }
            .show()
    }

    private fun <T> next(cur: T, list: List<T>): T = list[(list.indexOf(cur) + 1) % list.size]

    private fun showSettings() {
        val o = mapOf("auto" to "авто (датчик)", "portrait" to "портретная", "landscape" to "альбомная")
        val t = mapOf("auto" to "авто (по времени)", "day" to "день", "night" to "ночь")
        val l = mapOf("ru" to "Русский", "uk" to "Українська")
        val items = arrayOf(
            "Ориентация: ${o[prefs.orientation]}",
            "Тема: ${t[prefs.theme]}",
            "Язык голоса: ${l[prefs.lang]}",
            "Проверить голос",
            "Моя машинка (тип и цвет)"
        )
        AlertDialog.Builder(this)
            .setTitle("Настройки")
            .setItems(items) { _, i ->
                if (i == 4) {
                    showCarDialog()
                } else {
                    when (i) {
                        0 -> {
                            prefs.orientation = next(prefs.orientation, listOf("auto", "portrait", "landscape"))
                            applyOrientation()
                        }
                        1 -> {
                            prefs.theme = next(prefs.theme, listOf("auto", "day", "night"))
                            applyTheme()
                        }
                        2 -> {
                            prefs.lang = next(prefs.lang, listOf("ru", "uk"))
                            voice.lang = prefs.lang
                        }
                        3 -> voice.speak(Phrases.test(prefs.lang))
                    }
                    showSettings()
                }
            }
            .setNegativeButton("Закрыть", null)
            .show()
    }

    private fun refreshCar() {
        car.setImageBitmap(CarIcon.draw(prefs.carType, prefs.carColor, 192))
    }

    private fun showCarDialog() {
        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        fun lp(w: Int, h: Int): LinearLayout.LayoutParams {
            val l = LinearLayout.LayoutParams(px(w), px(h))
            l.setMargins(px(4), px(4), px(4), px(4))
            return l
        }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setPadding(px(16), px(8), px(16), px(8))

        val preview = ImageView(this)
        root.addView(preview, lp(96, 96))

        val thumbs = ArrayList<Pair<String, ImageView>>()
        fun refresh() {
            preview.setImageBitmap(CarIcon.draw(prefs.carType, prefs.carColor, 192))
            for ((key, iv) in thumbs) {
                iv.setImageBitmap(CarIcon.draw(key, prefs.carColor, 96))
                iv.alpha = if (key == prefs.carType) 1f else 0.4f
            }
            refreshCar()
        }

        val typesRow = LinearLayout(this)
        typesRow.orientation = LinearLayout.HORIZONTAL
        for ((key, _) in CarIcon.TYPES) {
            val iv = ImageView(this)
            iv.setOnClickListener {
                prefs.carType = key
                refresh()
            }
            thumbs.add(key to iv)
            typesRow.addView(iv, lp(52, 52))
        }
        val scroll = HorizontalScrollView(this)
        scroll.addView(typesRow)
        root.addView(scroll)

        val rows = listOf(CarIcon.COLORS.subList(0, 4), CarIcon.COLORS.subList(4, 8))
        for (colors in rows) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (col in colors) {
                val v = View(this)
                val gd = GradientDrawable()
                gd.shape = GradientDrawable.OVAL
                gd.setColor(col)
                gd.setStroke(px(2), Color.GRAY)
                v.background = gd
                v.setOnClickListener {
                    prefs.carColor = col
                    refresh()
                }
                row.addView(v, lp(40, 40))
            }
            root.addView(row)
        }

        refresh()
        AlertDialog.Builder(this)
            .setTitle("Моя машинка")
            .setView(root)
            .setPositiveButton("Готово", null)
            .show()
    }

    private fun applyOrientation() {
        requestedOrientation = when (prefs.orientation) {
            "portrait" -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            "landscape" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        }
    }

    /** Ночью карта затемняется полупрозрачным слоем (отдельного тёмного стиля карты пока нет). */
    private fun applyTheme() {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val night = when (prefs.theme) {
            "night" -> true
            "day" -> false
            else -> hour < 6 || hour >= 20
        }
        nightDim.setBackgroundColor(Color.argb(0x99, 0, 0x08, 0x18))
        nightDim.visibility = if (night) View.VISIBLE else View.GONE
        bar.setBackgroundColor(if (night) Color.argb(0xEE, 0, 0, 0) else Color.argb(0xCC, 0, 0, 0))
    }

    private fun openYouTubeMusic() {
        val intent = packageManager.getLaunchIntentForPackage(YTM)
        if (intent == null) toast("YouTube Music не установлен") else startActivity(intent)
    }

    // ---------- Музыка через MediaSession ----------

    private fun controller(): MediaControllerCompat? {
        if (!NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)) {
            toast("Включите для DriveDeck «Доступ к уведомлениям», чтобы управлять музыкой")
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            return null
        }
        val msm = getSystemService(MediaSessionManager::class.java)
        val list = try {
            msm.getActiveSessions(ComponentName(this, MediaListener::class.java))
        } catch (e: SecurityException) {
            toast("Нет доступа к медиасессиям")
            return null
        }
        val c = list.firstOrNull { it.packageName == YTM }
        if (c == null) {
            toast("YouTube Music не играет. Запустите его через меню.")
            return null
        }
        return MediaControllerCompat(this, MediaSessionCompat.Token.fromToken(c.sessionToken))
    }

    // ---------- Прочее ----------

    private fun fmtDist(m: Double): String =
        if (m < 1000) "${((m / 10).roundToInt() * 10)} м" else String.format(Locale.US, "%.1f км", m / 1000)

    private fun fmtTime(sec: Double): String {
        val min = (sec / 60).roundToInt()
        return if (min >= 60) "${min / 60} ч ${min % 60} мин" else "$min мин"
    }

    private fun goFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.hide(WindowInsetsCompat.Type.systemBars())
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onStart() { super.onStart(); mapView.onStart() }
    override fun onResume() {
        super.onResume(); mapView.onResume(); goFullscreen()
        handler.removeCallbacks(themeTick); handler.post(themeTick)
    }
    override fun onPause() { handler.removeCallbacks(themeTick); mapView.onPause(); super.onPause() }
    override fun onStop() { mapView.onStop(); super.onStop() }
    override fun onLowMemory() { super.onLowMemory(); mapView.onLowMemory() }
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState); mapView.onSaveInstanceState(outState)
    }
    override fun onDestroy() {
        try { getSystemService(LocationManager::class.java).removeUpdates(locationListener) } catch (_: Exception) {}
        voice.shutdown()
        mapView.onDestroy()
        super.onDestroy()
    }
}
