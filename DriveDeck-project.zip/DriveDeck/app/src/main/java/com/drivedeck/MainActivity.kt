package com.drivedeck

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioManager
import android.media.session.MediaSessionManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.support.v4.media.session.MediaControllerCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONArray
import org.json.JSONObject
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.BackgroundLayer
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.FillExtrusionLayer
import org.maplibre.android.style.layers.FillLayer
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.layers.SymbolLayer
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.android.style.sources.VectorSource
import java.util.Calendar
import java.util.Locale
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sqrt

private class Chip(val text: String, val color: Int, val selected: Boolean, val onClick: () -> Unit)

class MainActivity : Activity() {

    companion object {
        private const val STYLE_URL = "https://tiles.openfreemap.org/styles/liberty"
        private const val YTM = "com.google.android.apps.youtube.music"
        private const val REQ_LOCATION = 1
        private const val MAX_ROUTES = 6
        private val ROUTE_COLORS = listOf("#1E88E5", "#FB8C00", "#43A047", "#8E24AA", "#E53935", "#00ACC1")
    }

    private lateinit var prefs: Prefs
    private lateinit var voice: Voice
    private lateinit var offline: OfflineMaps
    private lateinit var mapView: MapView
    private lateinit var status: TextView
    private lateinit var nightDim: View
    private lateinit var bar: LinearLayout
    private lateinit var navPanel: LinearLayout
    private lateinit var navArrow: TextView
    private lateinit var navDist: TextView
    private lateinit var navStreet: TextView
    private lateinit var navInfo: TextView
    private lateinit var panel: LinearLayout
    private lateinit var panelTitle: TextView
    private lateinit var chipsScroll: HorizontalScrollView
    private lateinit var panelChips: LinearLayout
    private lateinit var panelActions: LinearLayout
    private lateinit var btnLocate: ImageButton
    private lateinit var btnPlay: ImageButton

    private var map: MapLibreMap? = null
    private var styleReady = false
    private var car3dOn = false
    private var startingMusic = false
    private var lastLocateTap = 0L
    private var locChecked = false
    private var weEnabledLocation = false
    private var nightNow = false
    private var padTop = 0

    // положение и режим слежения
    private var lastLoc: Location? = null
    private var lastBearing = 0.0
    private var lastGpsAt = 0L
    private var hadFix = false
    private var following = false
    private var followWhenFound = false
    private var gestureActive = false

    // индикаторы
    private var foundIconVisible = false
    private var online = true
    private var netCallback: ConnectivityManager.NetworkCallback? = null

    // планирование и навигация
    private var navigator: Navigator? = null
    private var planDest: Place? = null
    private val vias = ArrayList<Place>()
    private var candidates: List<Route> = emptyList()
    private var selectedRoute = 0
    private var destVersion = 0
    private var destRenamed = false
    private var pickMode = 0 // 0 нет, 1 выбор точки назначения, 2 промежуточная точка
    private var drawn: List<Route> = emptyList()
    private var drawnSel = 0
    @Volatile private var recalculating = false
    private var lastRecalcAt = 0L

    private val handler = Handler(Looper.getMainLooper())
    private val mediaTick = object : Runnable {
        override fun run() {
            syncPlayIcon()
            handler.postDelayed(this, 2000L)
        }
    }
    private val themeTick = object : Runnable {
        override fun run() {
            applyTheme()
            handler.postDelayed(this, 60000L)
        }
    }

    private val locationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            val now = SystemClock.elapsedRealtime()
            if (location.provider == LocationManager.GPS_PROVIDER) {
                lastGpsAt = now
            } else if (now - lastGpsAt < 5000L) {
                return // свежий GPS точнее сети
            }
            onFix(location)
        }
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, s: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        Tr.uk = prefs.uiLang == "uk"
        applyOrientation()
        MapLibre.getInstance(this)
        setContentView(R.layout.activity_main)
        goFullscreen()

        mapView = findViewById(R.id.mapView)
        status = findViewById(R.id.status)
        nightDim = findViewById(R.id.nightDim)
        bar = findViewById(R.id.bar)
        navPanel = findViewById(R.id.navPanel)
        navArrow = findViewById(R.id.navArrow)
        navDist = findViewById(R.id.navDist)
        navStreet = findViewById(R.id.navStreet)
        navInfo = findViewById(R.id.navInfo)
        panel = findViewById(R.id.panel)
        panelTitle = findViewById(R.id.panelTitle)
        chipsScroll = findViewById(R.id.chipsScroll)
        panelChips = findViewById(R.id.panelChips)
        panelActions = findViewById(R.id.panelActions)
        btnLocate = findViewById(R.id.btnLocate)
        btnPlay = findViewById(R.id.btnPlay)

        voice = Voice(this, prefs.lang) { msg -> runOnUiThread { toast(msg) } }
        offline = OfflineMaps(this, STYLE_URL)

        mapView.onCreate(savedInstanceState)
        mapView.getMapAsync { m -> setupMap(m) }

        findViewById<ImageButton>(R.id.btnPrev).setOnClickListener {
            controller()?.transportControls?.skipToPrevious()
        }
        findViewById<ImageButton>(R.id.btnNext).setOnClickListener {
            controller()?.transportControls?.skipToNext()
        }
        btnPlay.setOnClickListener { onPlayClick() }
        btnLocate.setOnClickListener {
            val now = SystemClock.elapsedRealtime()
            if (now - lastLocateTap < 350L && navigator == null) {
                // двойное нажатие — запуск навигации («Куда едем?»)
                lastLocateTap = 0L
                openDestinationDialog()
            } else {
                lastLocateTap = now
                onLocateClick()
            }
        }
        updateLocateButton()

        registerNetwork()
        applyTheme()
        startLocation()
    }

    // ---------- Карта ----------

    private fun px(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun setupMap(m: MapLibreMap) {
        map = m
        m.uiSettings.setLogoMargins(px(8), 0, 0, px(60))
        m.uiSettings.setAttributionMargins(px(100), 0, 0, px(60))
        restoreCamera(m)
        m.setStyle(STYLE_URL) { style -> onStyleReady(style) }
        m.addOnMapLongClickListener {
            showMenu()
            true
        }
        m.addOnMapClickListener { ll -> onMapClick(ll) }
        m.addOnCameraMoveStartedListener { reason ->
            if (reason == MapLibreMap.OnCameraMoveStartedListener.REASON_API_GESTURE) gestureActive = true
        }
        m.addOnCameraIdleListener { onCameraIdle() }
        m.addOnCameraMoveListener { update3d() }
    }

    private fun restoreCamera(m: MapLibreMap) {
        val b = CameraPosition.Builder()
        if (prefs.hasCamera()) {
            b.target(LatLng(prefs.camLat, prefs.camLon))
                .zoom(prefs.camZoom).tilt(prefs.camTilt).bearing(prefs.camBearing)
        } else {
            b.target(LatLng(49.0, 31.0)).zoom(5.5).tilt(0.0).bearing(0.0)
        }
        m.moveCamera(CameraUpdateFactory.newCameraPosition(b.build()))
    }

    private fun saveCamera() {
        val cp = map?.cameraPosition ?: return
        val t = cp.target ?: return
        prefs.saveCamera(t.latitude, t.longitude, cp.zoom, cp.tilt, cp.bearing)
    }

    private fun carBitmap(): Bitmap {
        val b = CarIcon.draw(prefs.carType, prefs.carColor, 192)
        b.density = DisplayMetrics.DENSITY_DEFAULT
        return b
    }

    private fun onStyleReady(style: Style) {
        if (nightNow) applyNight(style) else if (prefs.contrast) applyContrast(style)
        ensureHouseNumbers(style)
        style.addSource(GeoJsonSource("route-casing-src", Net.EMPTY_GEOJSON))
        style.addLayer(
            LineLayer("route-casing", "route-casing-src").withProperties(
                PropertyFactory.lineColor(Color.WHITE),
                PropertyFactory.lineWidth(13f),
                PropertyFactory.lineOpacity(0.9f),
                PropertyFactory.lineCap(Property.LINE_CAP_ROUND),
                PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND)
            )
        )
        for (i in 0 until MAX_ROUTES) {
            style.addSource(GeoJsonSource("route-src-$i", Net.EMPTY_GEOJSON))
            style.addLayer(
                LineLayer("route-layer-$i", "route-src-$i").withProperties(
                    PropertyFactory.lineColor(Color.parseColor(ROUTE_COLORS[i])),
                    PropertyFactory.lineWidth(5f),
                    PropertyFactory.lineCap(Property.LINE_CAP_ROUND),
                    PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND)
                )
            )
        }
        style.addSource(GeoJsonSource("via-src", Net.EMPTY_GEOJSON))
        style.addLayer(
            CircleLayer("via-layer", "via-src").withProperties(
                PropertyFactory.circleRadius(7f),
                PropertyFactory.circleColor(Color.parseColor("#1E88E5")),
                PropertyFactory.circleStrokeWidth(3f),
                PropertyFactory.circleStrokeColor(Color.WHITE)
            )
        )
        style.addSource(GeoJsonSource("dest-src", Net.EMPTY_GEOJSON))
        style.addLayer(
            CircleLayer("dest-layer", "dest-src").withProperties(
                PropertyFactory.circleRadius(10f),
                PropertyFactory.circleColor(Color.parseColor("#E53935")),
                PropertyFactory.circleStrokeWidth(3f),
                PropertyFactory.circleStrokeColor(Color.WHITE)
            )
        )
        style.addSource(GeoJsonSource("car3d-src", Net.EMPTY_GEOJSON))
        style.addLayer(
            FillExtrusionLayer("car3d-layer", "car3d-src").withProperties(
                PropertyFactory.fillExtrusionColor(Expression.get("color")),
                PropertyFactory.fillExtrusionHeight(Expression.get("h")),
                PropertyFactory.fillExtrusionBase(Expression.get("b")),
                PropertyFactory.fillExtrusionOpacity(1f),
                PropertyFactory.visibility(Property.NONE)
            )
        )
        style.addImage("car-icon", carBitmap())
        style.addSource(GeoJsonSource("car-src", Net.EMPTY_GEOJSON))
        style.addLayer(
            SymbolLayer("car-layer", "car-src").withProperties(
                PropertyFactory.iconImage("car-icon"),
                PropertyFactory.iconSize(0.3f),
                PropertyFactory.iconAllowOverlap(true),
                PropertyFactory.iconIgnorePlacement(true),
                PropertyFactory.iconRotate(Expression.get("bearing")),
                PropertyFactory.iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_MAP),
                PropertyFactory.iconPitchAlignment(Property.ICON_PITCH_ALIGNMENT_MAP)
            )
        )
        styleReady = true
        showRoutes(drawn, drawnSel)
        updateMarkers()
        lastLoc?.let { updateCar(it) }
        update3d()
    }

    /** Номера домов при сильном приближении (если слой уже есть в стиле — просто открываем его раньше). */
    private fun ensureHouseNumbers(style: Style) {
        try {
            var existing: SymbolLayer? = null
            var font: Array<String>? = null
            for (layer in style.layers) {
                if (layer is SymbolLayer) {
                    val id = layer.id.lowercase(Locale.US)
                    if (id.contains("housenumber")) existing = layer
                    if (font == null && id.contains("name")) {
                        try { font = layer.textFont.value } catch (e: Exception) { }
                    }
                }
            }
            if (existing != null) {
                existing.minZoom = 16.5f
                existing.setProperties(PropertyFactory.visibility(Property.VISIBLE))
                return
            }
            var srcId: String? = null
            for (src in style.sources) {
                if (src is VectorSource) {
                    srcId = src.id
                    break
                }
            }
            if (srcId == null) return
            val hn = SymbolLayer("dd-housenumber", srcId).withSourceLayer("housenumber")
            hn.minZoom = 16.5f
            hn.setProperties(
                PropertyFactory.textField(Expression.get("housenumber")),
                PropertyFactory.textSize(13f),
                PropertyFactory.textColor(if (nightNow) Color.WHITE else Color.parseColor("#37474F")),
                PropertyFactory.textHaloColor(if (nightNow) Color.parseColor("#0B1220") else Color.WHITE),
                PropertyFactory.textHaloWidth(1.6f),
                PropertyFactory.textFont(font ?: arrayOf("Noto Sans Regular")),
                PropertyFactory.textAllowOverlap(false)
            )
            style.addLayer(hn)
        } catch (e: Exception) {
            // номера домов не добавились — остальная карта работает
        }
    }

    /** Ночная карта: тёмная земля, светлые яркие дороги, белые подписи с тёмной каймой. */
    private fun applyNight(style: Style) {
        for (layer in style.layers) {
            val id = layer.id.lowercase(Locale.US)
            try {
                when (layer) {
                    is BackgroundLayer -> layer.setProperties(PropertyFactory.backgroundColor(Color.parseColor("#0B1220")))
                    is FillLayer -> {
                        val c = when {
                            id.contains("water") -> "#14406E"
                            id.contains("wood") || id.contains("forest") || id.contains("park") ||
                                id.contains("grass") || id.contains("garden") || id.contains("landcover") -> "#123524"
                            id.contains("building") -> "#2A3342"
                            else -> "#16202F"
                        }
                        layer.setProperties(PropertyFactory.fillColor(Color.parseColor(c)))
                    }
                    is FillExtrusionLayer -> {
                        if (id.contains("building")) {
                            layer.setProperties(PropertyFactory.fillExtrusionColor(Color.parseColor("#3E4A5E")))
                        }
                    }
                    is LineLayer -> {
                        val c: String? = when {
                            id.contains("casing") -> "#05080F"
                            id.contains("waterway") -> "#14406E"
                            id.contains("boundary") -> "#8FA0C0"
                            id.contains("road") || id.contains("bridge") || id.contains("tunnel") || id.contains("highway") -> when {
                                id.contains("path") || id.contains("pedestrian") || id.contains("rail") || id.contains("steps") -> "#6B7A90"
                                id.contains("motorway") -> "#FF9100"
                                id.contains("trunk") || id.contains("primary") -> "#FFD54F"
                                id.contains("secondary") || id.contains("tertiary") -> "#FFF59D"
                                else -> "#E3E9F4"
                            }
                            else -> null
                        }
                        if (c != null) layer.setProperties(PropertyFactory.lineColor(Color.parseColor(c)))
                    }
                    is SymbolLayer -> layer.setProperties(
                        PropertyFactory.textColor(Color.WHITE),
                        PropertyFactory.textHaloColor(Color.parseColor("#0B1220")),
                        PropertyFactory.textHaloWidth(2f)
                    )
                    else -> {}
                }
            } catch (e: Exception) {
                // слой не поддерживает свойство — пропускаем
            }
        }
    }

    private fun reloadStyle() {
        val m = map ?: return
        styleReady = false
        car3dOn = false
        m.setStyle(STYLE_URL) { style -> onStyleReady(style) }
    }

    /** Усиливает контраст карты: яркие дороги с тёмной обводкой, насыщенные вода и зелень, чёткие подписи. */
    private fun applyContrast(style: Style) {
        for (layer in style.layers) {
            val id = layer.id.lowercase(Locale.US)
            try {
                when (layer) {
                    is LineLayer -> {
                        if (id.contains("casing")) {
                            layer.setProperties(PropertyFactory.lineColor(Color.parseColor("#263238")))
                        } else if (id.contains("road") || id.contains("bridge") || id.contains("tunnel") || id.contains("highway")) {
                            val c = when {
                                id.contains("path") || id.contains("pedestrian") || id.contains("rail") || id.contains("steps") -> null
                                id.contains("motorway") -> "#FF9800"
                                id.contains("trunk") || id.contains("primary") -> "#FFC107"
                                id.contains("secondary") || id.contains("tertiary") -> "#FFF176"
                                else -> "#FFFFFF"
                            }
                            if (c != null) layer.setProperties(PropertyFactory.lineColor(Color.parseColor(c)))
                        }
                    }
                    is FillLayer -> {
                        if (id.contains("water")) {
                            layer.setProperties(PropertyFactory.fillColor(Color.parseColor("#4DA3F0")))
                        } else if (id.contains("wood") || id.contains("forest")) {
                            layer.setProperties(PropertyFactory.fillColor(Color.parseColor("#7FC47F")))
                        } else if (id.contains("park") || id.contains("grass") || id.contains("garden")) {
                            layer.setProperties(PropertyFactory.fillColor(Color.parseColor("#B5DD94")))
                        } else if (id.contains("building")) {
                            layer.setProperties(PropertyFactory.fillColor(Color.parseColor("#C9CFD4")))
                        }
                    }
                    is FillExtrusionLayer -> {
                        if (id.contains("building")) {
                            layer.setProperties(PropertyFactory.fillExtrusionColor(Color.parseColor("#B0BEC5")))
                        }
                    }
                    is SymbolLayer -> layer.setProperties(
                        PropertyFactory.textColor(Color.BLACK),
                        PropertyFactory.textHaloColor(Color.WHITE),
                        PropertyFactory.textHaloWidth(2f)
                    )
                    else -> {}
                }
            } catch (e: Exception) {
                // слой не поддерживает свойство — пропускаем
            }
        }
    }

    private fun refreshCar() {
        val st = map?.style ?: return
        if (!styleReady) return
        st.removeImage("car-icon")
        st.addImage("car-icon", carBitmap())
        update3d()
    }

    private fun updateCar(loc: Location) {
        if (!styleReady) return
        val feat = JSONObject()
            .put("type", "Feature")
            .put("properties", JSONObject().put("bearing", lastBearing))
            .put(
                "geometry",
                JSONObject().put("type", "Point")
                    .put("coordinates", JSONArray().put(loc.longitude).put(loc.latitude))
            )
        map?.style?.getSourceAs<GeoJsonSource>("car-src")?.setGeoJson(feat.toString())
        update3d()
    }

    /** При наклоне карты вместо плоской иконки показываем объёмную машинку. */
    private fun update3d() {
        val loc = lastLoc ?: return
        if (!styleReady) return
        val m = map ?: return
        val st = m.style ?: return
        val cp = m.cameraPosition
        val want3d = cp.tilt >= 12.0
        if (want3d != car3dOn) {
            car3dOn = want3d
            st.getLayerAs<SymbolLayer>("car-layer")?.setProperties(
                PropertyFactory.visibility(if (want3d) Property.NONE else Property.VISIBLE)
            )
            st.getLayerAs<FillExtrusionLayer>("car3d-layer")?.setProperties(
                PropertyFactory.visibility(if (want3d) Property.VISIBLE else Property.NONE)
            )
        }
        if (want3d) {
            val metersPerDp = 78271.517 * cos(Math.toRadians(loc.latitude)) / Math.pow(2.0, cp.zoom)
            st.getSourceAs<GeoJsonSource>("car3d-src")?.setGeoJson(
                Car3D.geoJson(prefs.carType, prefs.carColor, loc.latitude, loc.longitude, lastBearing, 56.0 * metersPerDp)
            )
        }
    }

    private fun showRoutes(list: List<Route>, sel: Int) {
        drawn = list
        drawnSel = sel
        if (!styleReady) return
        val st = map?.style ?: return
        st.getSourceAs<GeoJsonSource>("route-casing-src")?.setGeoJson(Net.routeJson(list.getOrNull(sel)))
        for (i in 0 until MAX_ROUTES) {
            st.getSourceAs<GeoJsonSource>("route-src-$i")?.setGeoJson(Net.routeJson(list.getOrNull(i)))
            st.getLayerAs<LineLayer>("route-layer-$i")?.setProperties(
                PropertyFactory.lineWidth(if (i == sel) 9f else 5f),
                PropertyFactory.lineOpacity(if (i == sel) 1f else 0.6f)
            )
        }
    }

    private fun updateMarkers() {
        if (!styleReady) return
        val st = map?.style ?: return
        val d = planDest
        st.getSourceAs<GeoJsonSource>("dest-src")?.setGeoJson(Net.pointsJson(if (d != null) listOf(d) else emptyList()))
        st.getSourceAs<GeoJsonSource>("via-src")?.setGeoJson(Net.pointsJson(vias))
    }

    private fun onCameraIdle() {
        if (!gestureActive) return
        gestureActive = false
        val loc = lastLoc
        val m = map
        if (following && loc != null && m != null) {
            val pt = m.projection.toScreenLocation(LatLng(loc.latitude, loc.longitude))
            val dx = pt.x - mapView.width / 2f
            val dy = pt.y - (padTop + (mapView.height - padTop) / 2f)
            if (sqrt(dx * dx + dy * dy) > px(60)) {
                following = false
                updateLocateButton()
            }
        }
        saveCamera()
    }

    /** При навигации смещаем «центр» вниз: машина внизу экрана, впереди видно маршрут. */
    private fun applyNavPadding(on: Boolean) {
        val m = map ?: return
        val top = if (on) (mapView.height * 0.42f).toInt() else 0
        if (top != padTop) {
            padTop = top
            m.setPadding(0, top, 0, 0)
        }
    }

    private fun updateLocateButton() {
        btnLocate.setColorFilter(if (following) Color.parseColor("#42A5F5") else Color.WHITE)
    }

    private fun onLocateClick() {
        val loc = lastLoc
        if (loc == null) {
            followWhenFound = true
            toast(tr("Определяю местоположение…", "Визначаю місцеперебування…"))
            startLocation()
            return
        }
        following = true
        updateLocateButton()
        val m = map ?: return
        applyNavPadding(navigator != null)
        val cur = m.cameraPosition
        val z = if (cur.zoom < 15.0) 16.0 else cur.zoom
        m.easeCamera(
            CameraUpdateFactory.newCameraPosition(
                CameraPosition.Builder()
                    .target(LatLng(loc.latitude, loc.longitude))
                    .zoom(z).bearing(cur.bearing).tilt(cur.tilt).build()
            ), 600
        )
    }

    /** Слежение: наклон не трогаем; масштаб меняется только при навигации (по скорости). */
    private fun followCamera(loc: Location, maneuverDist: Double) {
        val m = map ?: return
        applyNavPadding(navigator != null)
        val cur = m.cameraPosition
        var zoom = cur.zoom
        if (navigator != null) {
            val v = loc.speed * 3.6
            var target = when {
                v < 15 -> 17.5
                v < 40 -> 17.0
                v < 70 -> 16.2
                v < 100 -> 15.4
                else -> 14.8
            }
            if (maneuverDist in 0.0..200.0) target = minOf(target + 0.8, 18.0)
            zoom = cur.zoom + (target - cur.zoom) * 0.35
        }
        val bearing = if (loc.hasBearing() && loc.speed > 1f) loc.bearing.toDouble() else cur.bearing
        m.easeCamera(
            CameraUpdateFactory.newCameraPosition(
                CameraPosition.Builder()
                    .target(LatLng(loc.latitude, loc.longitude))
                    .zoom(zoom).bearing(bearing).tilt(cur.tilt).build()
            ), 900
        )
    }

    // ---------- GPS ----------

    private fun hasLocPermission() =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun checkLocationService() {
        if (!hasLocPermission()) return
        val lm = getSystemService(LocationManager::class.java)
        val on = lm.isLocationEnabled
        if (!locChecked) {
            locChecked = true
            prefs.locWasOff = !on
            if (!on) askEnableLocation()
        }
        if (prefs.locWasOff && on) weEnabledLocation = true
    }

    /** Android не позволяет приложению самому включить геолокацию — открываем настройки. */
    private fun askEnableLocation() {
        AlertDialog.Builder(this)
            .setTitle(tr("Геолокация выключена", "Геолокацію вимкнено"))
            .setMessage(
                tr(
                    "Для навигации нужна геолокация. Android не позволяет приложениям включать её самим, поэтому откроются настройки. Через 5 минут после закрытия приложения я напомню выключить её обратно.",
                    "Для навігації потрібна геолокація. Android не дозволяє застосункам вмикати її самим, тому відкриються налаштування. Через 5 хвилин після закриття застосунку я нагадаю вимкнути її назад."
                )
            )
            .setPositiveButton(tr("Открыть настройки", "Відкрити налаштування")) { _, _ ->
                startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
            }
            .setNegativeButton(tr("Не сейчас", "Не зараз"), null)
            .show()
    }

    private fun reminderIntent(): PendingIntent = PendingIntent.getBroadcast(
        this, 7, Intent(this, LocationReminderReceiver::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun scheduleReminder() {
        val am = getSystemService(AlarmManager::class.java)
        am.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 5 * 60 * 1000L, reminderIntent())
    }

    private fun cancelReminder() {
        getSystemService(AlarmManager::class.java).cancel(reminderIntent())
    }

    private fun ageSec(l: Location): Double =
        (SystemClock.elapsedRealtimeNanos() - l.elapsedRealtimeNanos) / 1e9

    private fun startLocation() {
        if (!hasLocPermission()) {
            val perms = ArrayList<String>()
            perms.add(Manifest.permission.ACCESS_FINE_LOCATION)
            perms.add(Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(perms.toTypedArray(), REQ_LOCATION)
            return
        }
        val lm = getSystemService(LocationManager::class.java)
        try { lm.removeUpdates(locationListener) } catch (_: Exception) {}
        val names = ArrayList<String>()
        names.add(LocationManager.GPS_PROVIDER)
        names.add(LocationManager.NETWORK_PROVIDER)
        if (Build.VERSION.SDK_INT >= 31) names.add(LocationManager.FUSED_PROVIDER)

        var started = 0
        var best: Location? = null
        for (name in names) {
            try {
                if (!lm.isProviderEnabled(name)) continue
                lm.requestLocationUpdates(name, 1000L, 0f, locationListener)
                started++
                val last = lm.getLastKnownLocation(name)
                if (last != null && (best == null || last.time > best.time)) best = last
            } catch (e: SecurityException) {
                // нет права на этот источник
            } catch (e: IllegalArgumentException) {
                // источника нет на устройстве
            }
        }
        if (started == 0) {
            toast(tr("Геолокация выключена или нет разрешения — включите её в настройках телефона", "Геолокацію вимкнено або немає дозволу — увімкніть її в налаштуваннях телефону"))
            return
        }
        // старую «последнюю известную» позицию не показываем
        if (best != null && ageSec(best) < 120.0) onFix(best)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code == REQ_LOCATION && hasLocPermission()) startLocation()
    }

    private fun onFix(loc: Location) {
        lastLoc = loc
        if (loc.hasBearing() && loc.speed > 1f) lastBearing = loc.bearing.toDouble()
        updateCar(loc)
        if (!hadFix) {
            hadFix = true
            showFoundIcon()
            if (followWhenFound) {
                followWhenFound = false
                onLocateClick()
            }
        }

        var maneuverDist = -1.0
        val nav = navigator
        if (nav != null && !(loc.hasAccuracy() && loc.accuracy > 60f)) {
            val u = nav.update(loc.latitude, loc.longitude)
            if (u.arrived) {
                voice.speak(Phrases.maneuver(u.step, 0, prefs.lang))
                cancelNavigation(true)
                toast(tr("Вы прибыли", "Ви прибули"))
            } else {
                navArrow.text = Phrases.arrow(u.step)
                navDist.text = fmtDist(u.dist)
                navStreet.text = u.step.street
                maneuverDist = u.dist
                if (u.announce > 0 && !Phrases.silent(u.step)) {
                    voice.speak(Phrases.maneuver(u.step, u.announce, prefs.lang))
                }
                if (u.off) recalc(loc)
            }
        }
        if (following && !gestureActive) followCamera(loc, maneuverDist)
    }

    private fun showFoundIcon() {
        foundIconVisible = true
        refreshStatusIcons()
        handler.postDelayed({
            foundIconVisible = false
            refreshStatusIcons()
        }, 5000L)
    }

    private fun refreshStatusIcons() {
        val sb = StringBuilder()
        if (foundIconVisible) sb.append("📍")
        if (!online) {
            if (sb.isNotEmpty()) sb.append(" ")
            sb.append("🚫🌐")
        }
        status.text = sb.toString()
        status.visibility = if (sb.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun registerNetwork() {
        try {
            val cm = getSystemService(ConnectivityManager::class.java)
            val net = cm.activeNetwork
            val caps = if (net != null) cm.getNetworkCapabilities(net) else null
            online = caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            refreshStatusIcons()
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onLost(network: Network) {
                    runOnUiThread {
                        online = false
                        refreshStatusIcons()
                    }
                }
                override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                    val ok = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
                    runOnUiThread {
                        online = ok
                        refreshStatusIcons()
                    }
                }
            }
            netCallback = cb
            cm.registerDefaultNetworkCallback(cb)
        } catch (e: Exception) {
            // индикатор сети просто не будет работать
        }
    }

    // ---------- Навигация ----------

    private fun recalc(loc: Location) {
        val d = planDest ?: return
        val now = System.currentTimeMillis()
        if (recalculating || now - lastRecalcAt < 10000L) return
        recalculating = true
        lastRecalcAt = now
        voice.speak(Phrases.deviation(prefs.lang))
        Thread {
            try {
                val r = Net.fastRoute(loc.latitude, loc.longitude, d.lat, d.lon)
                runOnUiThread {
                    recalculating = false
                    if (planDest != null && navigator != null) startNavigation(r, true)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    recalculating = false
                    toast(tr("Не удалось пересчитать маршрут (нужен интернет)", "Не вдалося перерахувати маршрут (потрібен інтернет)"))
                }
            }
        }.start()
    }

    private fun startNavigation(route: Route, silent: Boolean = false) {
        navigator = Navigator(route)
        applyNavPadding(true)
        candidates = emptyList()
        pickMode = 0
        hidePanel()
        showRoutes(listOf(route), 0)
        navPanel.visibility = View.VISIBLE
        val first = route.steps[if (route.steps.size > 1) 1 else 0]
        navArrow.text = Phrases.arrow(first)
        navDist.text = ""
        navStreet.text = first.street
        navInfo.text = tr("Всего: ${fmtDist(route.distance)} · ${fmtTime(route.duration)}", "Усього: ${fmtDist(route.distance)} · ${fmtTime(route.duration)}")
        if (!silent) {
            planDest?.let { prefs.addRecent(it) }
            voice.speak(Phrases.started(prefs.lang))
            following = true
            updateLocateButton()
            val loc = lastLoc
            val m = map
            if (loc != null && m != null) {
                val cur = m.cameraPosition
                m.easeCamera(
                    CameraUpdateFactory.newCameraPosition(
                        CameraPosition.Builder()
                            .target(LatLng(loc.latitude, loc.longitude))
                            .zoom(17.0).bearing(cur.bearing).tilt(cur.tilt).build()
                    ), 700
                )
            }
        }
    }

    private fun cancelNavigation(quiet: Boolean = false) {
        navigator = null
        applyNavPadding(false)
        planDest = null
        vias.clear()
        candidates = emptyList()
        pickMode = 0
        hidePanel()
        showRoutes(emptyList(), 0)
        updateMarkers()
        navPanel.visibility = View.GONE
        if (!quiet) toast(tr("Навигация отменена", "Навігацію скасовано"))
    }

    // ---------- Выбор места, подтверждение, маршруты ----------

    private fun hidePanel() {
        panel.visibility = View.GONE
    }

    private fun smallButton(text: String, color: Int, size: Float, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = size
        b.setTextColor(Color.WHITE)
        b.minHeight = 0
        b.minimumHeight = 0
        b.minWidth = 0
        b.minimumWidth = 0
        val small = size < 16f
        b.setPadding(px(if (small) 8 else 14), px(if (small) 4 else 8), px(if (small) 8 else 14), px(if (small) 4 else 8))
        val gd = GradientDrawable()
        gd.cornerRadius = px(14).toFloat()
        gd.setColor(color)
        b.background = gd
        b.setOnClickListener { onClick() }
        return b
    }

    private fun margins(): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        l.setMargins(px(4), px(2), px(4), px(2))
        return l
    }

    private fun showPanel(title: String, chips: List<Chip>, actions: List<Pair<String, () -> Unit>>) {
        panelTitle.text = title
        panelChips.removeAllViews()
        for (c in chips) {
            val b = smallButton(c.text, c.color, 14f, c.onClick)
            b.alpha = if (c.selected) 1f else 0.5f
            panelChips.addView(b, margins())
        }
        chipsScroll.visibility = if (chips.isEmpty()) View.GONE else View.VISIBLE
        panelActions.removeAllViews()
        for ((idx, pair) in actions.withIndex()) {
            val color = when {
                idx == actions.size - 1 -> Color.parseColor("#C62828")
                idx == 0 && actions.size > 1 -> Color.parseColor("#00A152")
                else -> Color.parseColor("#37474F")
            }
            panelActions.addView(smallButton(pair.first, color, 23f, pair.second), margins())
        }
        panel.visibility = View.VISIBLE
    }

    private fun cancelPlanning() {
        pickMode = 0
        candidates = emptyList()
        vias.clear()
        hidePanel()
        val nav = navigator
        if (nav != null) {
            showRoutes(listOf(nav.route), 0)
        } else {
            planDest = null
            showRoutes(emptyList(), 0)
        }
        updateMarkers()
    }

    private fun openDestinationDialog() {
        cancelPlanning()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(px(16), px(8), px(16), px(8))
        val input = EditText(this)
        input.hint = tr("Адрес или населённый пункт", "Адреса або населений пункт")
        input.setSingleLine()
        input.textSize = 17f
        root.addView(input)

        var dialog: AlertDialog? = null
        fun item(text: String, action: () -> Unit) {
            val tv = TextView(this)
            tv.text = text
            tv.textSize = 17f
            tv.setPadding(px(4), px(12), px(4), px(12))
            tv.setOnClickListener {
                dialog?.dismiss()
                action()
            }
            root.addView(tv)
        }

        val home = prefs.place("home")
        val work = prefs.place("work")
        val shown = ArrayList<Pair<String, Place>>()
        if (home != null) shown.add(tr("🏠 Дом: ${home.name}", "🏠 Дім: ${home.name}") to home)
        if (work != null) shown.add(tr("💼 Работа: ${work.name}", "💼 Робота: ${work.name}") to work)
        for (r in prefs.recents().take(5 - shown.size)) shown.add("🕘 ${r.name}" to r)
        for ((label, p) in shown) item(label) { previewDestination(p) }
        item(tr("📍 Выбрать точку на карте", "📍 Обрати точку на мапі")) { beginPick(false) }
        if (home == null || work == null) {
            val hint = TextView(this)
            hint.text = tr("Дом и работу можно задать кнопками 🏠 и 💼 после выбора места.", "Дім і роботу можна задати кнопками 🏠 і 💼 після вибору місця.")
            hint.textSize = 13f
            hint.setPadding(px(4), px(8), px(4), px(4))
            root.addView(hint)
        }

        val scroll = ScrollView(this)
        scroll.addView(root)
        val d = AlertDialog.Builder(this)
            .setTitle(tr("Куда едем?", "Куди їдемо?"))
            .setView(scroll)
            .setPositiveButton(tr("Найти", "Знайти")) { _, _ -> search(input.text.toString()) }
            .setNegativeButton(tr("Отмена", "Скасувати"), null)
            .create()
        dialog = d
        d.show()
    }

    private fun search(q: String) {
        if (q.isBlank()) return
        toast(tr("Поиск…", "Пошук…"))
        val lang = prefs.lang
        Thread {
            try {
                val res = Net.geocode(q, lang)
                runOnUiThread { if (res.isEmpty()) toast(tr("Ничего не найдено", "Нічого не знайдено")) else pickPlace(res) }
            } catch (e: Exception) {
                runOnUiThread { toast(tr("Поиск не удался (нужен интернет)", "Пошук не вдався (потрібен інтернет)")) }
            }
        }.start()
    }

    private fun pickPlace(res: List<Place>) {
        AlertDialog.Builder(this)
            .setTitle(tr("Выберите место", "Оберіть місце"))
            .setItems(res.map { it.name }.toTypedArray()) { _, i -> previewDestination(res[i]) }
            .show()
    }

    private fun beginPick(forVia: Boolean) {
        pickMode = if (forVia) 2 else 1
        following = false
        updateLocateButton()
        showPanel(
            if (forVia) tr("Коснитесь карты: промежуточная точка маршрута", "Торкніться мапи: проміжна точка маршруту") else tr("Коснитесь карты: куда ехать", "Торкніться мапи: куди їхати"),
            emptyList(),
            listOf<Pair<String, () -> Unit>>(tr("Отмена", "Скасувати") to { cancelPlanning() })
        )
    }

    private fun onMapClick(ll: LatLng): Boolean {
        if (pickMode == 1) {
            previewDestination(Place(tr("Определяю адрес…", "Визначаю адресу…"), ll.latitude, ll.longitude))
            val v = destVersion
            val lang = prefs.lang
            Thread {
                val addr = try { Net.reverse(ll.latitude, ll.longitude, lang) } catch (e: Exception) { null }
                runOnUiThread {
                    val cur = planDest
                    if (v == destVersion && !destRenamed && cur != null) {
                        val name = if (!addr.isNullOrBlank()) addr else tr("Точка назначения ${prefs.nextPointNumber()}", "Точка призначення ${prefs.nextPointNumber()}")
                        planDest = cur.copy(name = name)
                        if (candidates.isEmpty() && navigator == null && pickMode == 0) showDestPanel()
                    }
                }
            }.start()
            return true
        }
        if (pickMode == 2) {
            vias.add(Place(tr("Точка", "Точка"), ll.latitude, ll.longitude))
            pickMode = 0
            updateMarkers()
            requestRoutes()
            return true
        }
        return false
    }

    private fun previewDestination(p: Place) {
        destVersion++
        destRenamed = false
        candidates = emptyList()
        vias.clear()
        pickMode = 0
        planDest = p
        showRoutes(emptyList(), 0)
        updateMarkers()
        following = false
        updateLocateButton()
        map?.let { m ->
            val cur = m.cameraPosition
            m.easeCamera(
                CameraUpdateFactory.newCameraPosition(
                    CameraPosition.Builder()
                        .target(LatLng(p.lat, p.lon))
                        .zoom(maxOf(cur.zoom, 13.0)).bearing(cur.bearing).tilt(cur.tilt).build()
                ), 600
            )
        }
        showDestPanel()
    }

    private fun showDestPanel() {
        val p = planDest ?: return
        showPanel(
            p.name,
            emptyList(),
            listOf<Pair<String, () -> Unit>>(
                tr("Маршруты", "Маршрути") to { requestRoutes() },
                "✏" to { renameDestination() },
                "🏠" to {
                    planDest?.let { prefs.setPlace("home", it) }
                    toast(tr("Сохранено как «Дом»", "Збережено як «Дім»"))
                },
                "💼" to {
                    planDest?.let { prefs.setPlace("work", it) }
                    toast(tr("Сохранено как «Работа»", "Збережено як «Робота»"))
                },
                "✕" to { cancelPlanning() }
            )
        )
    }

    private fun renameDestination() {
        val p = planDest ?: return
        val box = LinearLayout(this)
        box.setPadding(px(16), px(8), px(16), px(8))
        val input = EditText(this)
        input.setText(p.name)
        input.setSingleLine()
        input.setSelectAllOnFocus(true)
        box.addView(input, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        AlertDialog.Builder(this)
            .setTitle(tr("Название места", "Назва місця"))
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                val n = input.text.toString().trim()
                val cur = planDest
                if (n.isNotEmpty() && cur != null) {
                    val renamed = cur.copy(name = n)
                    planDest = renamed
                    prefs.addRecent(renamed)
                    destRenamed = true
                    showDestPanel()
                }
            }
            .setNegativeButton(tr("Отмена", "Скасувати"), null)
            .show()
    }

    private fun requestRoutes() {
        val d = planDest ?: return
        val loc = lastLoc
        if (loc == null) {
            toast(tr("Местоположение не найдено — маршрут строится от вашей позиции", "Місцеперебування не знайдено — маршрут будується від вашої позиції"))
            return
        }
        toast(tr("Строю маршруты…", "Будую маршрути…"))
        val viaArr = vias.map { doubleArrayOf(it.lat, it.lon) }
        Thread {
            try {
                val rs = Net.routesMulti(loc.latitude, loc.longitude, d.lat, d.lon, viaArr)
                runOnUiThread {
                    candidates = rs
                    selectedRoute = 0
                    showRoutesPanel(true)
                }
            } catch (e: Exception) {
                runOnUiThread { toast(tr("Маршрут не построен (нужен интернет или дорога не найдена)", "Маршрут не побудовано (потрібен інтернет або дорогу не знайдено)")) }
            }
        }.start()
    }

    private fun showRoutesPanel(fit: Boolean) {
        showRoutes(candidates, selectedRoute)
        updateMarkers()
        val chips = candidates.mapIndexed { i, r ->
            Chip(
                "${i + 1}. ${r.label}\n${fmtDist(r.distance)} · ${fmtTime(r.duration)}",
                Color.parseColor(ROUTE_COLORS[i % ROUTE_COLORS.size]),
                i == selectedRoute
            ) {
                selectedRoute = i
                showRoutesPanel(false)
            }
        }
        showPanel(
            tr("Выберите маршрут (цвет на карте). Для своей дороги добавьте точку.", "Оберіть маршрут (колір на мапі). Для власної дороги додайте точку."),
            chips,
            listOf<Pair<String, () -> Unit>>(
                tr("▶ Ехать", "▶ Їхати") to {
                    if (selectedRoute < candidates.size) startNavigation(candidates[selectedRoute])
                },
                tr("＋ Точка", "＋ Точка") to { beginPick(true) },
                "✕" to { cancelPlanning() }
            )
        )
        if (fit) fitRoutes()
    }

    private fun fitRoutes() {
        val b = LatLngBounds.Builder()
        var count = 0
        for (r in candidates) {
            val a = r.pts
            val stepN = maxOf(1, a.size / 30)
            var i = 0
            while (i < a.size) {
                b.include(LatLng(a[i][0], a[i][1]))
                count++
                i += stepN
            }
            b.include(LatLng(a.last()[0], a.last()[1]))
        }
        if (count < 2) return
        following = false
        updateLocateButton()
        try {
            map?.easeCamera(
                CameraUpdateFactory.newLatLngBounds(b.build(), px(50), px(50), px(50), px(280)), 800
            )
        } catch (e: Exception) {
            // не удалось вписать — остаёмся как есть
        }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (panel.visibility == View.VISIBLE) cancelPlanning() else super.onBackPressed()
    }

    // ---------- Меню и настройки ----------

    private fun showMenu() {
        val navigating = navigator != null
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(px(10), px(14), px(10), px(14))
        var dlg: AlertDialog? = null
        fun entry(text: String, size: Float, color: Int, action: () -> Unit) {
            val tv = TextView(this)
            tv.text = text
            tv.textSize = size
            tv.setTextColor(color)
            tv.gravity = Gravity.CENTER
            tv.setPadding(px(24), px(22), px(24), px(22))
            val gd = GradientDrawable()
            gd.cornerRadius = px(16).toFloat()
            gd.setColor(Color.parseColor("#26354A"))
            tv.background = gd
            tv.setOnClickListener {
                dlg?.dismiss()
                action()
            }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, px(10), 0, px(10))
            root.addView(tv, lp)
        }
        entry(if (navigating) tr("Отменить навигацию", "Скасувати навігацію") else tr("Куда едем?", "Куди їдемо?"), 28f, Color.WHITE) {
            if (navigating) cancelNavigation() else openDestinationDialog()
        }
        entry(tr("Настройки", "Налаштування"), 18f, Color.parseColor("#B0BEC5")) { showSettings() }
        val d = AlertDialog.Builder(this, R.style.NormalDialog).setView(root).create()
        dlg = d
        d.show()
    }

    private fun <T> next(cur: T, list: List<T>): T = list[(list.indexOf(cur) + 1) % list.size]

    private fun showSettings() {
        val o = mapOf("auto" to tr("авто (датчик)", "авто (датчик)"), "portrait" to tr("портретная", "портретна"), "landscape" to tr("альбомная", "альбомна"))
        val t = mapOf("auto" to tr("авто (по времени)", "авто (за часом)"), "day" to tr("день", "день"), "night" to tr("ночь", "ніч"))
        val l = mapOf("ru" to tr("Русский", "Русский"), "uk" to tr("Українська", "Українська"))
        val items = arrayOf(
            tr("Ориентация: ${o[prefs.orientation]}", "Орієнтація: ${o[prefs.orientation]}"),
            tr("Тема: ${t[prefs.theme]}", "Тема: ${t[prefs.theme]}"),
            tr("Язык приложения: ${l[prefs.uiLang]}", "Мова застосунку: ${l[prefs.uiLang]}"),
            tr("Язык голоса: ${l[prefs.lang]}", "Мова голосу: ${l[prefs.lang]}"),
            tr("Контраст карты: ", "Контраст мапи: ") + (if (prefs.contrast) tr("высокий", "високий") else tr("обычный", "звичайний")),
            tr("Проверить голос", "Перевірити голос"),
            tr("Моя машинка (тип и цвет)", "Моя машинка (тип і колір)"),
            tr("Загрузка карт", "Завантаження мап")
        )
        AlertDialog.Builder(this, R.style.MidDialog)
            .setTitle(tr("Настройки", "Налаштування"))
            .setItems(items) { _, i ->
                when (i) {
                    6 -> showCarDialog()
                    7 -> offline.show()
                    else -> {
                        when (i) {
                            0 -> {
                                prefs.orientation = next(prefs.orientation, listOf("auto", "portrait", "landscape"))
                                applyOrientation()
                            }
                            1 -> {
                                prefs.theme = next(prefs.theme, listOf("auto", "day", "night"))
                                applyTheme()
                            }
                            2 -> {
                                prefs.uiLang = next(prefs.uiLang, listOf("ru", "uk"))
                                Tr.uk = prefs.uiLang == "uk"
                            }
                            3 -> {
                                prefs.lang = next(prefs.lang, listOf("ru", "uk"))
                                voice.lang = prefs.lang
                            }
                            4 -> {
                                prefs.contrast = !prefs.contrast
                                reloadStyle()
                            }
                            5 -> voice.speak(Phrases.test(prefs.lang))
                        }
                        showSettings()
                    }
                }
            }
            .setNegativeButton(tr("Закрыть", "Закрити"), null)
            .show()
    }

    private fun showCarDialog() {
        fun lp(w: Int, h: Int): LinearLayout.LayoutParams {
            val l = LinearLayout.LayoutParams(px(w), px(h))
            l.setMargins(px(4), px(4), px(4), px(4))
            return l
        }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setPadding(px(16), px(8), px(16), px(8))

        val preview = ImageView(this)
        root.addView(preview, lp(96, 96))

        val thumbs = ArrayList<Pair<String, ImageView>>()
        fun refresh() {
            preview.setImageBitmap(CarIcon.draw(prefs.carType, prefs.carColor, 192))
            for ((key, iv) in thumbs) {
                iv.setImageBitmap(CarIcon.draw(key, prefs.carColor, 96))
                iv.alpha = if (key == prefs.carType) 1f else 0.4f
            }
            refreshCar()
        }

        val typesRow = LinearLayout(this)
        typesRow.orientation = LinearLayout.HORIZONTAL
        for ((key, _) in CarIcon.TYPES) {
            val iv = ImageView(this)
            iv.setOnClickListener {
                prefs.carType = key
                refresh()
            }
            thumbs.add(key to iv)
            typesRow.addView(iv, lp(52, 52))
        }
        val scroll = HorizontalScrollView(this)
        scroll.addView(typesRow)
        root.addView(scroll)

        val rows = listOf(CarIcon.COLORS.subList(0, 4), CarIcon.COLORS.subList(4, 8))
        for (colors in rows) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (col in colors) {
                val v = View(this)
                val gd = GradientDrawable()
                gd.shape = GradientDrawable.OVAL
                gd.setColor(col)
                gd.setStroke(px(2), Color.GRAY)
                v.background = gd
                v.setOnClickListener {
                    prefs.carColor = col
                    refresh()
                }
                row.addView(v, lp(40, 40))
            }
            root.addView(row)
        }

        refresh()
        AlertDialog.Builder(this, R.style.BigDialog)
            .setTitle(tr("Моя машинка", "Моя машинка"))
            .setView(root)
            .setPositiveButton(tr("Готово", "Готово"), null)
            .show()
    }

    private fun applyOrientation() {
        requestedOrientation = when (prefs.orientation) {
            "portrait" -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            "landscape" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        }
    }

    /** Ночью карта затемняется полупрозрачным слоем (отдельного тёмного стиля карты пока нет). */
    private fun applyTheme() {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val night = when (prefs.theme) {
            "night" -> true
            "day" -> false
            else -> hour < 6 || hour >= 20
        }
        val changed = night != nightNow
        nightNow = night
        nightDim.setBackgroundColor(Color.argb(0x22, 0, 0x08, 0x18))
        nightDim.visibility = if (night) View.VISIBLE else View.GONE
        if (changed && styleReady) reloadStyle()
    }

    private fun openYouTubeMusic() {
        val intent = packageManager.getLaunchIntentForPackage(YTM)
        if (intent == null) toast(tr("YouTube Music не установлен", "YouTube Music не встановлено")) else startActivity(intent)
    }

    // ---------- Музыка через MediaSession ----------

    private fun listenerEnabled() =
        NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

    private fun onPlayClick() {
        if (!listenerEnabled()) {
            controller() // попросит включить доступ к уведомлениям
            return
        }
        val c = controller(true)
        if (c == null) {
            startMusicFromScratch()
            return
        }
        if (c.playbackState?.state == PlaybackStateCompat.STATE_PLAYING) {
            c.transportControls.pause()
            setPlayIcon(false)
        } else {
            c.transportControls.play()
            setPlayIcon(true)
        }
    }

    /** Клавиша «Play» уходит системе: она возобновляет последний плеер в фоне, без открытия приложения. */
    private fun sendMediaKey(code: Int) {
        val am = getSystemService(AudioManager::class.java)
        val now = SystemClock.uptimeMillis()
        am.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, code, 0))
        am.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_UP, code, 0))
    }

    private fun startMusicFromScratch() {
        if (startingMusic) return
        startingMusic = true
        toast(tr("Запускаю YouTube Music в фоне…", "Запускаю YouTube Music у фоні…"))
        sendMediaKey(KeyEvent.KEYCODE_MEDIA_PLAY)
        waitForSession(0)
    }

    private fun waitForSession(attempt: Int) {
        handler.postDelayed({
            val c = controller(true)
            if (c != null) {
                c.transportControls.play()
                setPlayIcon(true)
                startingMusic = false
            } else if (attempt < 2) {
                waitForSession(attempt + 1)
            } else {
                // в фоне не вышло — открываем YouTube Music, сами запускаем музыку и возвращаемся
                toast(tr("Не удалось запустить в фоне — открываю YouTube Music",
                    "Не вдалося запустити у фоні — відкриваю YouTube Music"))
                openYouTubeMusic()
                pollSession(0)
            }
        }, 1200L)
    }

    private fun pollSession(n: Int) {
        handler.postDelayed({
            val c = controller(true)
            if (c != null) {
                c.transportControls.play()
                setPlayIcon(true)
                startingMusic = false
                handler.postDelayed({ bringBack() }, 1500L)
            } else if (n < 12) {
                pollSession(n + 1)
            } else {
                startingMusic = false
            }
        }, 700L)
    }

    private fun bringBack() {
        try {
            val am = getSystemService(ActivityManager::class.java)
            am.moveTaskToFront(taskId, 0)
        } catch (e: Exception) {
            try {
                startActivity(
                    Intent(this, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                )
            } catch (_: Exception) {
            }
        }
    }

    private fun setPlayIcon(playing: Boolean) {
        btnPlay.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
    }

    private fun syncPlayIcon() {
        if (!listenerEnabled()) return
        val c = controller(true) ?: return
        setPlayIcon(c.playbackState?.state == PlaybackStateCompat.STATE_PLAYING)
    }

    private fun controller(quiet: Boolean = false): MediaControllerCompat? {
        if (!listenerEnabled()) {
            if (!quiet) {
                toast(tr("Включите для DriveDeck «Доступ к уведомлениям», чтобы управлять музыкой", "Увімкніть для DriveDeck «Доступ до сповіщень», щоб керувати музикою"))
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
            return null
        }
        val msm = getSystemService(MediaSessionManager::class.java)
        val list = try {
            msm.getActiveSessions(ComponentName(this, MediaListener::class.java))
        } catch (e: SecurityException) {
            if (!quiet) toast(tr("Нет доступа к медиасессиям", "Немає доступу до медіасесій"))
            return null
        }
        val c = list.firstOrNull { it.packageName == YTM }
        if (c == null) {
            if (!quiet) toast(tr("YouTube Music не играет. Нажмите ⏯ — он запустится.", "YouTube Music не грає. Натисніть ⏯ — він запуститься."))
            return null
        }
        return MediaControllerCompat(this, MediaSessionCompat.Token.fromToken(c.sessionToken))
    }

    // ---------- Прочее ----------

    private fun fmtDist(m: Double): String =
        if (m < 1000) tr("${((m / 10).roundToInt() * 10)} м", "${((m / 10).roundToInt() * 10)} м") else String.format(Locale.US, tr("%.1f км", "%.1f км"), m / 1000)

    private fun fmtTime(sec: Double): String {
        val min = (sec / 60).roundToInt()
        return if (min >= 60) tr("${min / 60} ч ${min % 60} мин", "${min / 60} год ${min % 60} хв") else tr("$min мин", "$min хв")
    }

    private fun goFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.hide(WindowInsetsCompat.Type.systemBars())
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onStart() {
        super.onStart()
        mapView.onStart()
        cancelReminder()
    }
    override fun onResume() {
        super.onResume(); mapView.onResume(); goFullscreen()
        handler.removeCallbacks(themeTick); handler.post(themeTick)
        handler.removeCallbacks(mediaTick); handler.post(mediaTick)
        if (hasLocPermission()) startLocation()
        checkLocationService()
    }
    override fun onPause() {
        saveCamera()
        handler.removeCallbacks(themeTick)
        handler.removeCallbacks(mediaTick)
        mapView.onPause()
        super.onPause()
    }
    override fun onStop() {
        if (weEnabledLocation) scheduleReminder()
        mapView.onStop()
        super.onStop()
    }
    override fun onLowMemory() { super.onLowMemory(); mapView.onLowMemory() }
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState); mapView.onSaveInstanceState(outState)
    }
    override fun onDestroy() {
        try { getSystemService(LocationManager::class.java).removeUpdates(locationListener) } catch (_: Exception) {}
        try {
            val cb = netCallback
            if (cb != null) getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(cb)
        } catch (_: Exception) {}
        voice.shutdown()
        mapView.onDestroy()
        super.onDestroy()
    }
}
