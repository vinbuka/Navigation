package com.drivedeck

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.session.MediaSessionManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.support.v4.media.session.MediaControllerCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONArray
import org.json.JSONObject
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.FillExtrusionLayer
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.layers.SymbolLayer
import org.maplibre.android.style.sources.GeoJsonSource
import java.util.Calendar
import java.util.Locale
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sqrt

private class Chip(val text: String, val color: Int, val selected: Boolean, val onClick: () -> Unit)

class MainActivity : Activity() {

    companion object {
        private const val STYLE_URL = "https://tiles.openfreemap.org/styles/liberty"
        private const val YTM = "com.google.android.apps.youtube.music"
        private const val REQ_LOCATION = 1
        private const val MAX_ROUTES = 6
        private val ROUTE_COLORS = listOf("#1E88E5", "#FB8C00", "#43A047", "#8E24AA", "#E53935", "#00ACC1")
    }

    private lateinit var prefs: Prefs
    private lateinit var voice: Voice
    private lateinit var offline: OfflineMaps
    private lateinit var mapView: MapView
    private lateinit var status: TextView
    private lateinit var nightDim: View
    private lateinit var bar: LinearLayout
    private lateinit var navPanel: LinearLayout
    private lateinit var navArrow: TextView
    private lateinit var navDist: TextView
    private lateinit var navStreet: TextView
    private lateinit var navInfo: TextView
    private lateinit var panel: LinearLayout
    private lateinit var panelTitle: TextView
    private lateinit var chipsScroll: HorizontalScrollView
    private lateinit var panelChips: LinearLayout
    private lateinit var panelActions: LinearLayout
    private lateinit var btnLocate: ImageButton

    private var map: MapLibreMap? = null
    private var styleReady = false
    private var car3dOn = false

    // положение и режим слежения
    private var lastLoc: Location? = null
    private var lastBearing = 0.0
    private var lastGpsAt = 0L
    private var hadFix = false
    private var following = false
    private var followWhenFound = false
    private var gestureActive = false

    // индикаторы
    private var foundIconVisible = false
    private var online = true
    private var netCallback: ConnectivityManager.NetworkCallback? = null

    // планирование и навигация
    private var navigator: Navigator? = null
    private var planDest: Place? = null
    private val vias = ArrayList<Place>()
    private var candidates: List<Route> = emptyList()
    private var selectedRoute = 0
    private var pickMode = 0 // 0 нет, 1 выбор точки назначения, 2 промежуточная точка
    private var drawn: List<Route> = emptyList()
    private var drawnSel = 0
    @Volatile private var recalculating = false
    private var lastRecalcAt = 0L

    private val handler = Handler(Looper.getMainLooper())
    private val themeTick = object : Runnable {
        override fun run() {
            applyTheme()
            handler.postDelayed(this, 60000L)
        }
    }

    private val locationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            val now = SystemClock.elapsedRealtime()
            if (location.provider == LocationManager.GPS_PROVIDER) {
                lastGpsAt = now
            } else if (now - lastGpsAt < 5000L) {
                return // свежий GPS точнее сети
            }
            onFix(location)
        }
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, s: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        applyOrientation()
        MapLibre.getInstance(this)
        setContentView(R.layout.activity_main)
        goFullscreen()

        mapView = findViewById(R.id.mapView)
        status = findViewById(R.id.status)
        nightDim = findViewById(R.id.nightDim)
        bar = findViewById(R.id.bar)
        navPanel = findViewById(R.id.navPanel)
        navArrow = findViewById(R.id.navArrow)
        navDist = findViewById(R.id.navDist)
        navStreet = findViewById(R.id.navStreet)
        navInfo = findViewById(R.id.navInfo)
        panel = findViewById(R.id.panel)
        panelTitle = findViewById(R.id.panelTitle)
        chipsScroll = findViewById(R.id.chipsScroll)
        panelChips = findViewById(R.id.panelChips)
        panelActions = findViewById(R.id.panelActions)
        btnLocate = findViewById(R.id.btnLocate)

        voice = Voice(this, prefs.lang) { msg -> runOnUiThread { toast(msg) } }
        offline = OfflineMaps(this, STYLE_URL)

        mapView.onCreate(savedInstanceState)
        mapView.getMapAsync { m -> setupMap(m) }

        findViewById<Button>(R.id.btnPrev).setOnClickListener {
            controller()?.transportControls?.skipToPrevious()
        }
        findViewById<Button>(R.id.btnNext).setOnClickListener {
            controller()?.transportControls?.skipToNext()
        }
        findViewById<Button>(R.id.btnPlay).setOnClickListener {
            val c = controller() ?: return@setOnClickListener
            if (c.playbackState?.state == PlaybackStateCompat.STATE_PLAYING) c.transportControls.pause()
            else c.transportControls.play()
        }
        btnLocate.setOnClickListener { onLocateClick() }
        updateLocateButton()

        registerNetwork()
        applyTheme()
        startLocation()
    }

    // ---------- Карта ----------

    private fun px(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun setupMap(m: MapLibreMap) {
        map = m
        m.uiSettings.setLogoMargins(px(8), 0, 0, px(60))
        m.uiSettings.setAttributionMargins(px(100), 0, 0, px(60))
        restoreCamera(m)
        m.setStyle(STYLE_URL) { style -> onStyleReady(style) }
        m.addOnMapLongClickListener {
            showMenu()
            true
        }
        m.addOnMapClickListener { ll -> onMapClick(ll) }
        m.addOnCameraMoveStartedListener { reason ->
            if (reason == MapLibreMap.OnCameraMoveStartedListener.REASON_API_GESTURE) gestureActive = true
        }
        m.addOnCameraIdleListener { onCameraIdle() }
        m.addOnCameraMoveListener { update3d() }
    }

    private fun restoreCamera(m: MapLibreMap) {
        val b = CameraPosition.Builder()
        if (prefs.hasCamera()) {
            b.target(LatLng(prefs.camLat, prefs.camLon))
                .zoom(prefs.camZoom).tilt(prefs.camTilt).bearing(prefs.camBearing)
        } else {
            b.target(LatLng(49.0, 31.0)).zoom(5.5).tilt(0.0).bearing(0.0)
        }
        m.moveCamera(CameraUpdateFactory.newCameraPosition(b.build()))
    }

    private fun saveCamera() {
        val cp = map?.cameraPosition ?: return
        val t = cp.target ?: return
        prefs.saveCamera(t.latitude, t.longitude, cp.zoom, cp.tilt, cp.bearing)
    }

    private fun carBitmap(): Bitmap {
        val b = CarIcon.draw(prefs.carType, prefs.carColor, 192)
        b.density = DisplayMetrics.DENSITY_DEFAULT
        return b
    }

    private fun onStyleReady(style: Style) {
        for (i in 0 until MAX_ROUTES) {
            style.addSource(GeoJsonSource("route-src-$i", Net.EMPTY_GEOJSON))
            style.addLayer(
                LineLayer("route-layer-$i", "route-src-$i").withProperties(
                    PropertyFactory.lineColor(Color.parseColor(ROUTE_COLORS[i])),
                    PropertyFactory.lineWidth(5f),
                    PropertyFactory.lineCap(Property.LINE_CAP_ROUND),
                    PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND)
                )
            )
        }
        style.addSource(GeoJsonSource("via-src", Net.EMPTY_GEOJSON))
        style.addLayer(
            CircleLayer("via-layer", "via-src").withProperties(
                PropertyFactory.circleRadius(7f),
                PropertyFactory.circleColor(Color.parseColor("#1E88E5")),
                PropertyFactory.circleStrokeWidth(3f),
                PropertyFactory.circleStrokeColor(Color.WHITE)
            )
        )
        style.addSource(GeoJsonSource("dest-src", Net.EMPTY_GEOJSON))
        style.addLayer(
            CircleLayer("dest-layer", "dest-src").withProperties(
                PropertyFactory.circleRadius(10f),
                PropertyFactory.circleColor(Color.parseColor("#E53935")),
                PropertyFactory.circleStrokeWidth(3f),
                PropertyFactory.circleStrokeColor(Color.WHITE)
            )
        )
        style.addSource(GeoJsonSource("car3d-src", Net.EMPTY_GEOJSON))
        style.addLayer(
            FillExtrusionLayer("car3d-layer", "car3d-src").withProperties(
                PropertyFactory.fillExtrusionColor(Expression.get("color")),
                PropertyFactory.fillExtrusionHeight(Expression.get("h")),
                PropertyFactory.fillExtrusionBase(Expression.get("b")),
                PropertyFactory.fillExtrusionOpacity(1f),
                PropertyFactory.visibility(Property.NONE)
            )
        )
        style.addImage("car-icon", carBitmap())
        style.addSource(GeoJsonSource("car-src", Net.EMPTY_GEOJSON))
        style.addLayer(
            SymbolLayer("car-layer", "car-src").withProperties(
                PropertyFactory.iconImage("car-icon"),
                PropertyFactory.iconSize(0.3f),
                PropertyFactory.iconAllowOverlap(true),
                PropertyFactory.iconIgnorePlacement(true),
                PropertyFactory.iconRotate(Expression.get("bearing")),
                PropertyFactory.iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_MAP),
                PropertyFactory.iconPitchAlignment(Property.ICON_PITCH_ALIGNMENT_MAP)
            )
        )
        styleReady = true
        showRoutes(drawn, drawnSel)
        updateMarkers()
        lastLoc?.let { updateCar(it) }
        update3d()
    }

    private fun refreshCar() {
        val st = map?.style ?: return
        if (!styleReady) return
        st.removeImage("car-icon")
        st.addImage("car-icon", carBitmap())
        update3d()
    }

    private fun updateCar(loc: Location) {
        if (!styleReady) return
        val feat = JSONObject()
            .put("type", "Feature")
            .put("properties", JSONObject().put("bearing", lastBearing))
            .put(
                "geometry",
                JSONObject().put("type", "Point")
                    .put("coordinates", JSONArray().put(loc.longitude).put(loc.latitude))
            )
        map?.style?.getSourceAs<GeoJsonSource>("car-src")?.setGeoJson(feat.toString())
        update3d()
    }

    /** При наклоне карты вместо плоской иконки показываем объёмную машинку. */
    private fun update3d() {
        val loc = lastLoc ?: return
        if (!styleReady) return
        val m = map ?: return
        val st = m.style ?: return
        val cp = m.cameraPosition
        val want3d = cp.tilt >= 12.0
        if (want3d != car3dOn) {
            car3dOn = want3d
            st.getLayerAs<SymbolLayer>("car-layer")?.setProperties(
                PropertyFactory.visibility(if (want3d) Property.NONE else Property.VISIBLE)
            )
            st.getLayerAs<FillExtrusionLayer>("car3d-layer")?.setProperties(
                PropertyFactory.visibility(if (want3d) Property.VISIBLE else Property.NONE)
            )
        }
        if (want3d) {
            val metersPerDp = 78271.517 * cos(Math.toRadians(loc.latitude)) / Math.pow(2.0, cp.zoom)
            st.getSourceAs<GeoJsonSource>("car3d-src")?.setGeoJson(
                Car3D.geoJson(prefs.carType, prefs.carColor, loc.latitude, loc.longitude, lastBearing, 56.0 * metersPerDp)
            )
        }
    }

    private fun showRoutes(list: List<Route>, sel: Int) {
        drawn = list
        drawnSel = sel
        if (!styleReady) return
        val st = map?.style ?: return
        for (i in 0 until MAX_ROUTES) {
            st.getSourceAs<GeoJsonSource>("route-src-$i")?.setGeoJson(Net.routeJson(list.getOrNull(i)))
            st.getLayerAs<LineLayer>("route-layer-$i")?.setProperties(
                PropertyFactory.lineWidth(if (i == sel) 9f else 5f),
                PropertyFactory.lineOpacity(if (i == sel) 1f else 0.6f)
            )
        }
    }

    private fun updateMarkers() {
        if (!styleReady) return
        val st = map?.style ?: return
        val d = planDest
        st.getSourceAs<GeoJsonSource>("dest-src")?.setGeoJson(Net.pointsJson(if (d != null) listOf(d) else emptyList()))
        st.getSourceAs<GeoJsonSource>("via-src")?.setGeoJson(Net.pointsJson(vias))
    }

    private fun onCameraIdle() {
        if (!gestureActive) return
        gestureActive = false
        val loc = lastLoc
        val m = map
        if (following && loc != null && m != null) {
            val pt = m.projection.toScreenLocation(LatLng(loc.latitude, loc.longitude))
            val dx = pt.x - mapView.width / 2f
            val dy = pt.y - mapView.height / 2f
            if (sqrt(dx * dx + dy * dy) > px(60)) {
                following = false
                updateLocateButton()
            }
        }
        saveCamera()
    }

    private fun updateLocateButton() {
        btnLocate.setColorFilter(if (following) Color.parseColor("#42A5F5") else Color.WHITE)
    }

    private fun onLocateClick() {
        val loc = lastLoc
        if (loc == null) {
            followWhenFound = true
            toast("Определяю местоположение…")
            startLocation()
            return
        }
        following = true
        updateLocateButton()
        val m = map ?: return
        val cur = m.cameraPosition
        val z = if (cur.zoom < 15.0) 16.0 else cur.zoom
        m.easeCamera(
            CameraUpdateFactory.newCameraPosition(
                CameraPosition.Builder()
                    .target(LatLng(loc.latitude, loc.longitude))
                    .zoom(z).bearing(cur.bearing).tilt(cur.tilt).build()
            ), 600
        )
    }

    /** Слежение: наклон не трогаем; масштаб меняется только при навигации (по скорости). */
    private fun followCamera(loc: Location, maneuverDist: Double) {
        val m = map ?: return
        val cur = m.cameraPosition
        var zoom = cur.zoom
        if (navigator != null) {
            val v = loc.speed * 3.6
            var target = when {
                v < 15 -> 17.5
                v < 40 -> 17.0
                v < 70 -> 16.2
                v < 100 -> 15.4
                else -> 14.8
            }
            if (maneuverDist in 0.0..200.0) target = minOf(target + 0.8, 18.0)
            zoom = cur.zoom + (target - cur.zoom) * 0.35
        }
        val bearing = if (loc.hasBearing() && loc.speed > 1f) loc.bearing.toDouble() else cur.bearing
        m.easeCamera(
            CameraUpdateFactory.newCameraPosition(
                CameraPosition.Builder()
                    .target(LatLng(loc.latitude, loc.longitude))
                    .zoom(zoom).bearing(bearing).tilt(cur.tilt).build()
            ), 900
        )
    }

    // ---------- GPS ----------

    private fun hasLocPermission() =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun ageSec(l: Location): Double =
        (SystemClock.elapsedRealtimeNanos() - l.elapsedRealtimeNanos) / 1e9

    private fun startLocation() {
        if (!hasLocPermission()) {
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                REQ_LOCATION
            )
            return
        }
        val lm = getSystemService(LocationManager::class.java)
        try { lm.removeUpdates(locationListener) } catch (_: Exception) {}
        val names = ArrayList<String>()
        names.add(LocationManager.GPS_PROVIDER)
        names.add(LocationManager.NETWORK_PROVIDER)
        if (Build.VERSION.SDK_INT >= 31) names.add(LocationManager.FUSED_PROVIDER)

        var started = 0
        var best: Location? = null
        for (name in names) {
            try {
                if (!lm.isProviderEnabled(name)) continue
                lm.requestLocationUpdates(name, 1000L, 0f, locationListener)
                started++
                val last = lm.getLastKnownLocation(name)
                if (last != null && (best == null || last.time > best.time)) best = last
            } catch (e: SecurityException) {
                // нет права на этот источник
            } catch (e: IllegalArgumentException) {
                // источника нет на устройстве
            }
        }
        if (started == 0) {
            toast("Геолокация выключена или нет разрешения — включите её в настройках телефона")
            return
        }
        // старую «последнюю известную» позицию не показываем
        if (best != null && ageSec(best) < 120.0) onFix(best)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code == REQ_LOCATION && hasLocPermission()) startLocation()
    }

    private fun onFix(loc: Location) {
        lastLoc = loc
        if (loc.hasBearing() && loc.speed > 1f) lastBearing = loc.bearing.toDouble()
        updateCar(loc)
        if (!hadFix) {
            hadFix = true
            showFoundIcon()
            if (followWhenFound) {
                followWhenFound = false
                onLocateClick()
            }
        }

        var maneuverDist = -1.0
        val nav = navigator
        if (nav != null && !(loc.hasAccuracy() && loc.accuracy > 60f)) {
            val u = nav.update(loc.latitude, loc.longitude)
            if (u.arrived) {
                voice.speak(Phrases.maneuver(u.step, 0, prefs.lang))
                cancelNavigation(true)
                toast("Вы прибыли")
            } else {
                navArrow.text = Phrases.arrow(u.step)
                navDist.text = fmtDist(u.dist)
                navStreet.text = u.step.street
                maneuverDist = u.dist
                if (u.announce > 0 && !Phrases.silent(u.step)) {
                    voice.speak(Phrases.maneuver(u.step, u.announce, prefs.lang))
                }
                if (u.off) recalc(loc)
            }
        }
        if (following && !gestureActive) followCamera(loc, maneuverDist)
    }

    private fun showFoundIcon() {
        foundIconVisible = true
        refreshStatusIcons()
        handler.postDelayed({
            foundIconVisible = false
            refreshStatusIcons()
        }, 5000L)
    }

    private fun refreshStatusIcons() {
        val sb = StringBuilder()
        if (foundIconVisible) sb.append("📍")
        if (!online) {
            if (sb.isNotEmpty()) sb.append(" ")
            sb.append("🚫🌐")
        }
        status.text = sb.toString()
        status.visibility = if (sb.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun registerNetwork() {
        try {
            val cm = getSystemService(ConnectivityManager::class.java)
            val net = cm.activeNetwork
            val caps = if (net != null) cm.getNetworkCapabilities(net) else null
            online = caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            refreshStatusIcons()
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onLost(network: Network) {
                    runOnUiThread {
                        online = false
                        refreshStatusIcons()
                    }
                }
                override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                    val ok = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
                    runOnUiThread {
                        online = ok
                        refreshStatusIcons()
                    }
                }
            }
            netCallback = cb
            cm.registerDefaultNetworkCallback(cb)
        } catch (e: Exception) {
            // индикатор сети просто не будет работать
        }
    }

    // ---------- Навигация ----------

    private fun recalc(loc: Location) {
        val d = planDest ?: return
        val now = System.currentTimeMillis()
        if (recalculating || now - lastRecalcAt < 10000L) return
        recalculating = true
        lastRecalcAt = now
        voice.speak(Phrases.deviation(prefs.lang))
        Thread {
            try {
                val r = Net.fastRoute(loc.latitude, loc.longitude, d.lat, d.lon)
                runOnUiThread {
                    recalculating = false
                    if (planDest != null && navigator != null) startNavigation(r, true)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    recalculating = false
                    toast("Не удалось пересчитать маршрут (нужен интернет)")
                }
            }
        }.start()
    }

    private fun startNavigation(route: Route, silent: Boolean = false) {
        navigator = Navigator(route)
        candidates = emptyList()
        pickMode = 0
        hidePanel()
        showRoutes(listOf(route), 0)
        navPanel.visibility = View.VISIBLE
        val first = route.steps[if (route.steps.size > 1) 1 else 0]
        navArrow.text = Phrases.arrow(first)
        navDist.text = ""
        navStreet.text = first.street
        navInfo.text = "Всего: ${fmtDist(route.distance)} · ${fmtTime(route.duration)}"
        if (!silent) {
            planDest?.let { prefs.addRecent(it) }
            voice.speak(Phrases.started(prefs.lang))
            following = true
            updateLocateButton()
            val loc = lastLoc
            val m = map
            if (loc != null && m != null) {
                val cur = m.cameraPosition
                m.easeCamera(
                    CameraUpdateFactory.newCameraPosition(
                        CameraPosition.Builder()
                            .target(LatLng(loc.latitude, loc.longitude))
                            .zoom(17.0).bearing(cur.bearing).tilt(cur.tilt).build()
                    ), 700
                )
            }
        }
    }

    private fun cancelNavigation(quiet: Boolean = false) {
        navigator = null
        planDest = null
        vias.clear()
        candidates = emptyList()
        pickMode = 0
        hidePanel()
        showRoutes(emptyList(), 0)
        updateMarkers()
        navPanel.visibility = View.GONE
        if (!quiet) toast("Навигация отменена")
    }

    // ---------- Выбор места, подтверждение, маршруты ----------

    private fun hidePanel() {
        panel.visibility = View.GONE
    }

    private fun smallButton(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 23f
        b.setTextColor(Color.WHITE)
        b.minHeight = 0
        b.minimumHeight = 0
        b.minWidth = 0
        b.minimumWidth = 0
        b.setPadding(px(10), px(6), px(10), px(6))
        b.setOnClickListener { onClick() }
        return b
    }

    private fun margins(): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        l.setMargins(px(4), px(2), px(4), px(2))
        return l
    }

    private fun showPanel(title: String, chips: List<Chip>, actions: List<Pair<String, () -> Unit>>) {
        panelTitle.text = title
        panelChips.removeAllViews()
        for (c in chips) {
            val b = smallButton(c.text, c.onClick)
            b.setBackgroundColor(c.color)
            b.alpha = if (c.selected) 1f else 0.5f
            panelChips.addView(b, margins())
        }
        chipsScroll.visibility = if (chips.isEmpty()) View.GONE else View.VISIBLE
        panelActions.removeAllViews()
        for ((text, act) in actions) panelActions.addView(smallButton(text, act), margins())
        panel.visibility = View.VISIBLE
    }

    private fun cancelPlanning() {
        pickMode = 0
        candidates = emptyList()
        vias.clear()
        hidePanel()
        val nav = navigator
        if (nav != null) {
            showRoutes(listOf(nav.route), 0)
        } else {
            planDest = null
            showRoutes(emptyList(), 0)
        }
        updateMarkers()
    }

    private fun openDestinationDialog() {
        cancelPlanning()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(px(16), px(8), px(16), px(8))
        val input = EditText(this)
        input.hint = "Адрес или населённый пункт"
        input.setSingleLine()
        input.textSize = 28f
        root.addView(input)

        var dialog: AlertDialog? = null
        fun item(text: String, action: () -> Unit) {
            val tv = TextView(this)
            tv.text = text
            tv.textSize = 28f
            tv.setPadding(px(4), px(12), px(4), px(12))
            tv.setOnClickListener {
                dialog?.dismiss()
                action()
            }
            root.addView(tv)
        }

        val home = prefs.place("home")
        val work = prefs.place("work")
        val shown = ArrayList<Pair<String, Place>>()
        if (home != null) shown.add("🏠 Дом: ${home.name}" to home)
        if (work != null) shown.add("💼 Работа: ${work.name}" to work)
        for (r in prefs.recents().take(5 - shown.size)) shown.add("🕘 ${r.name}" to r)
        for ((label, p) in shown) item(label) { previewDestination(p) }
        item("📍 Выбрать точку на карте") { beginPick(false) }
        if (home == null || work == null) {
            val hint = TextView(this)
            hint.text = "Дом и работу можно задать кнопками 🏠 и 💼 после выбора места."
            hint.textSize = 21f
            hint.setPadding(px(4), px(8), px(4), px(4))
            root.addView(hint)
        }

        val scroll = ScrollView(this)
        scroll.addView(root)
        val d = AlertDialog.Builder(this, R.style.BigDialog)
            .setTitle("Куда едем?")
            .setView(scroll)
            .setPositiveButton("Найти") { _, _ -> search(input.text.toString()) }
            .setNegativeButton("Отмена", null)
            .create()
        dialog = d
        d.show()
    }

    private fun search(q: String) {
        if (q.isBlank()) return
        toast("Поиск…")
        val lang = prefs.lang
        Thread {
            try {
                val res = Net.geocode(q, lang)
                runOnUiThread { if (res.isEmpty()) toast("Ничего не найдено") else pickPlace(res) }
            } catch (e: Exception) {
                runOnUiThread { toast("Поиск не удался (нужен интернет)") }
            }
        }.start()
    }

    private fun pickPlace(res: List<Place>) {
        AlertDialog.Builder(this, R.style.BigDialog)
            .setTitle("Выберите место")
            .setItems(res.map { it.name }.toTypedArray()) { _, i -> previewDestination(res[i]) }
            .show()
    }

    private fun beginPick(forVia: Boolean) {
        pickMode = if (forVia) 2 else 1
        following = false
        updateLocateButton()
        showPanel(
            if (forVia) "Коснитесь карты: промежуточная точка маршрута" else "Коснитесь карты: куда ехать",
            emptyList(),
            listOf<Pair<String, () -> Unit>>("Отмена" to { cancelPlanning() })
        )
    }

    private fun onMapClick(ll: LatLng): Boolean {
        if (pickMode == 1) {
            val name = String.format(Locale.US, "Точка на карте (%.4f, %.4f)", ll.latitude, ll.longitude)
            previewDestination(Place(name, ll.latitude, ll.longitude))
            return true
        }
        if (pickMode == 2) {
            vias.add(Place("Точка", ll.latitude, ll.longitude))
            pickMode = 0
            updateMarkers()
            requestRoutes()
            return true
        }
        return false
    }

    private fun previewDestination(p: Place) {
        candidates = emptyList()
        vias.clear()
        pickMode = 0
        planDest = p
        showRoutes(emptyList(), 0)
        updateMarkers()
        following = false
        updateLocateButton()
        map?.let { m ->
            val cur = m.cameraPosition
            m.easeCamera(
                CameraUpdateFactory.newCameraPosition(
                    CameraPosition.Builder()
                        .target(LatLng(p.lat, p.lon))
                        .zoom(maxOf(cur.zoom, 13.0)).bearing(cur.bearing).tilt(cur.tilt).build()
                ), 600
            )
        }
        showPanel(
            p.name,
            emptyList(),
            listOf<Pair<String, () -> Unit>>(
                "Маршруты" to { requestRoutes() },
                "🏠" to {
                    prefs.setPlace("home", p)
                    toast("Сохранено как «Дом»")
                },
                "💼" to {
                    prefs.setPlace("work", p)
                    toast("Сохранено как «Работа»")
                },
                "✕" to { cancelPlanning() }
            )
        )
    }

    private fun requestRoutes() {
        val d = planDest ?: return
        val loc = lastLoc
        if (loc == null) {
            toast("Местоположение не найдено — маршрут строится от вашей позиции")
            return
        }
        toast("Строю маршруты…")
        val viaArr = vias.map { doubleArrayOf(it.lat, it.lon) }
        Thread {
            try {
                val rs = Net.routesMulti(loc.latitude, loc.longitude, d.lat, d.lon, viaArr)
                runOnUiThread {
                    candidates = rs
                    selectedRoute = 0
                    showRoutesPanel(true)
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Маршрут не построен (нужен интернет или дорога не найдена)") }
            }
        }.start()
    }

    private fun showRoutesPanel(fit: Boolean) {
        showRoutes(candidates, selectedRoute)
        updateMarkers()
        val chips = candidates.mapIndexed { i, r ->
            Chip(
                "${i + 1}. ${r.label}\n${fmtDist(r.distance)} · ${fmtTime(r.duration)}",
                Color.parseColor(ROUTE_COLORS[i % ROUTE_COLORS.size]),
                i == selectedRoute
            ) {
                selectedRoute = i
                showRoutesPanel(false)
            }
        }
        showPanel(
            "Выберите маршрут (цвет на карте). Для своей дороги добавьте точку.",
            chips,
            listOf<Pair<String, () -> Unit>>(
                "▶ Ехать" to {
                    if (selectedRoute < candidates.size) startNavigation(candidates[selectedRoute])
                },
                "＋ Точка" to { beginPick(true) },
                "✕" to { cancelPlanning() }
            )
        )
        if (fit) fitRoutes()
    }

    private fun fitRoutes() {
        val b = LatLngBounds.Builder()
        var count = 0
        for (r in candidates) {
            val a = r.pts
            val stepN = maxOf(1, a.size / 30)
            var i = 0
            while (i < a.size) {
                b.include(LatLng(a[i][0], a[i][1]))
                count++
                i += stepN
            }
            b.include(LatLng(a.last()[0], a.last()[1]))
        }
        if (count < 2) return
        following = false
        updateLocateButton()
        try {
            map?.easeCamera(
                CameraUpdateFactory.newLatLngBounds(b.build(), px(50), px(50), px(50), px(280)), 800
            )
        } catch (e: Exception) {
            // не удалось вписать — остаёмся как есть
        }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (panel.visibility == View.VISIBLE) cancelPlanning() else super.onBackPressed()
    }

    // ---------- Меню и настройки ----------

    private fun showMenu() {
        val navigating = navigator != null
        val items = arrayOf(
            "Музыка (YouTube Music)",
            if (navigating) "Отменить навигацию" else "Куда едем?",
            "Загрузка карт",
            "Настройки"
        )
        AlertDialog.Builder(this, R.style.BigDialog)
            .setItems(items) { _, i ->
                when (i) {
                    0 -> openYouTubeMusic()
                    1 -> if (navigating) cancelNavigation() else openDestinationDialog()
                    2 -> offline.show()
                    3 -> showSettings()
                }
            }
            .show()
    }

    private fun <T> next(cur: T, list: List<T>): T = list[(list.indexOf(cur) + 1) % list.size]

    private fun showSettings() {
        val o = mapOf("auto" to "авто (датчик)", "portrait" to "портретная", "landscape" to "альбомная")
        val t = mapOf("auto" to "авто (по времени)", "day" to "день", "night" to "ночь")
        val l = mapOf("ru" to "Русский", "uk" to "Українська")
        val items = arrayOf(
            "Ориентация: ${o[prefs.orientation]}",
            "Тема: ${t[prefs.theme]}",
            "Язык голоса: ${l[prefs.lang]}",
            "Проверить голос",
            "Моя машинка (тип и цвет)"
        )
        AlertDialog.Builder(this, R.style.BigDialog)
            .setTitle("Настройки")
            .setItems(items) { _, i ->
                if (i == 4) {
                    showCarDialog()
                } else {
                    when (i) {
                        0 -> {
                            prefs.orientation = next(prefs.orientation, listOf("auto", "portrait", "landscape"))
                            applyOrientation()
                        }
                        1 -> {
                            prefs.theme = next(prefs.theme, listOf("auto", "day", "night"))
                            applyTheme()
                        }
                        2 -> {
                            prefs.lang = next(prefs.lang, listOf("ru", "uk"))
                            voice.lang = prefs.lang
                        }
                        3 -> voice.speak(Phrases.test(prefs.lang))
                    }
                    showSettings()
                }
            }
            .setNegativeButton("Закрыть", null)
            .show()
    }

    private fun showCarDialog() {
        fun lp(w: Int, h: Int): LinearLayout.LayoutParams {
            val l = LinearLayout.LayoutParams(px(w), px(h))
            l.setMargins(px(4), px(4), px(4), px(4))
            return l
        }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setPadding(px(16), px(8), px(16), px(8))

        val preview = ImageView(this)
        root.addView(preview, lp(96, 96))

        val thumbs = ArrayList<Pair<String, ImageView>>()
        fun refresh() {
            preview.setImageBitmap(CarIcon.draw(prefs.carType, prefs.carColor, 192))
            for ((key, iv) in thumbs) {
                iv.setImageBitmap(CarIcon.draw(key, prefs.carColor, 96))
                iv.alpha = if (key == prefs.carType) 1f else 0.4f
            }
            refreshCar()
        }

        val typesRow = LinearLayout(this)
        typesRow.orientation = LinearLayout.HORIZONTAL
        for ((key, _) in CarIcon.TYPES) {
            val iv = ImageView(this)
            iv.setOnClickListener {
                prefs.carType = key
                refresh()
            }
            thumbs.add(key to iv)
            typesRow.addView(iv, lp(52, 52))
        }
        val scroll = HorizontalScrollView(this)
        scroll.addView(typesRow)
        root.addView(scroll)

        val rows = listOf(CarIcon.COLORS.subList(0, 4), CarIcon.COLORS.subList(4, 8))
        for (colors in rows) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (col in colors) {
                val v = View(this)
                val gd = GradientDrawable()
                gd.shape = GradientDrawable.OVAL
                gd.setColor(col)
                gd.setStroke(px(2), Color.GRAY)
                v.background = gd
                v.setOnClickListener {
                    prefs.carColor = col
                    refresh()
                }
                row.addView(v, lp(40, 40))
            }
            root.addView(row)
        }

        refresh()
        AlertDialog.Builder(this, R.style.BigDialog)
            .setTitle("Моя машинка")
            .setView(root)
            .setPositiveButton("Готово", null)
            .show()
    }

    private fun applyOrientation() {
        requestedOrientation = when (prefs.orientation) {
            "portrait" -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            "landscape" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        }
    }

    /** Ночью карта затемняется полупрозрачным слоем (отдельного тёмного стиля карты пока нет). */
    private fun applyTheme() {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val night = when (prefs.theme) {
            "night" -> true
            "day" -> false
            else -> hour < 6 || hour >= 20
        }
        nightDim.setBackgroundColor(Color.argb(0x99, 0, 0x08, 0x18))
        nightDim.visibility = if (night) View.VISIBLE else View.GONE
        bar.setBackgroundColor(if (night) Color.argb(0xEE, 0, 0, 0) else Color.argb(0xCC, 0, 0, 0))
    }

    private fun openYouTubeMusic() {
        val intent = packageManager.getLaunchIntentForPackage(YTM)
        if (intent == null) toast("YouTube Music не установлен") else startActivity(intent)
    }

    // ---------- Музыка через MediaSession ----------

    private fun controller(): MediaControllerCompat? {
        if (!NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)) {
            toast("Включите для DriveDeck «Доступ к уведомлениям», чтобы управлять музыкой")
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            return null
        }
        val msm = getSystemService(MediaSessionManager::class.java)
        val list = try {
            msm.getActiveSessions(ComponentName(this, MediaListener::class.java))
        } catch (e: SecurityException) {
            toast("Нет доступа к медиасессиям")
            return null
        }
        val c = list.firstOrNull { it.packageName == YTM }
        if (c == null) {
            toast("YouTube Music не играет. Запустите его через меню.")
            return null
        }
        return MediaControllerCompat(this, MediaSessionCompat.Token.fromToken(c.sessionToken))
    }

    // ---------- Прочее ----------

    private fun fmtDist(m: Double): String =
        if (m < 1000) "${((m / 10).roundToInt() * 10)} м" else String.format(Locale.US, "%.1f км", m / 1000)

    private fun fmtTime(sec: Double): String {
        val min = (sec / 60).roundToInt()
        return if (min >= 60) "${min / 60} ч ${min % 60} мин" else "$min мин"
    }

    private fun goFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.hide(WindowInsetsCompat.Type.systemBars())
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onStart() { super.onStart(); mapView.onStart() }
    override fun onResume() {
        super.onResume(); mapView.onResume(); goFullscreen()
        handler.removeCallbacks(themeTick); handler.post(themeTick)
        if (hasLocPermission()) startLocation()
    }
    override fun onPause() {
        saveCamera()
        handler.removeCallbacks(themeTick)
        mapView.onPause()
        super.onPause()
    }
    override fun onStop() { mapView.onStop(); super.onStop() }
    override fun onLowMemory() { super.onLowMemory(); mapView.onLowMemory() }
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState); mapView.onSaveInstanceState(outState)
    }
    override fun onDestroy() {
        try { getSystemService(LocationManager::class.java).removeUpdates(locationListener) } catch (_: Exception) {}
        try {
            val cb = netCallback
            if (cb != null) getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(cb)
        } catch (_: Exception) {}
        voice.shutdown()
        mapView.onDestroy()
        super.onDestroy()
    }
}
