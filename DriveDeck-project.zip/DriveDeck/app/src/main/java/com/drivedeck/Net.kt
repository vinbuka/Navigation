package com.drivedeck

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Place(val name: String, val lat: Double, val lon: Double)
data class Step(
    val lat: Double, val lon: Double,
    val type: String, val modifier: String,
    val street: String, val dist: Double
)
data class Route(
    val pts: List<DoubleArray>, // [lat, lon]
    val steps: List<Step>,
    val distance: Double,
    val duration: Double
)

/** ОНЛАЙН-сервисы (нужен интернет): Nominatim (поиск) и публичный сервер OSRM (маршруты). */
object Net {
    const val EMPTY_GEOJSON = "{\"type\":\"FeatureCollection\",\"features\":[]}"

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 20000
        c.setRequestProperty("User-Agent", "DriveDeck/0.2 (personal navigation app)")
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    fun geocode(q: String, lang: String): List<Place> {
        val url = "https://nominatim.openstreetmap.org/search?format=json&limit=6&countrycodes=ua" +
            "&accept-language=$lang&q=" + URLEncoder.encode(q, "UTF-8")
        val arr = JSONArray(get(url))
        val out = ArrayList<Place>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(Place(o.getString("display_name"), o.getString("lat").toDouble(), o.getString("lon").toDouble()))
        }
        return out
    }

    fun routes(fromLat: Double, fromLon: Double, toLat: Double, toLon: Double): List<Route> {
        val url = "https://router.project-osrm.org/route/v1/driving/$fromLon,$fromLat;$toLon,$toLat" +
            "?alternatives=true&steps=true&geometries=geojson&overview=full"
        val root = JSONObject(get(url))
        if (root.optString("code") != "Ok") throw Exception("route: " + root.optString("code"))
        val arr = root.getJSONArray("routes")
        val out = ArrayList<Route>()
        for (i in 0 until arr.length()) {
            val r = arr.getJSONObject(i)
            val coords = r.getJSONObject("geometry").getJSONArray("coordinates")
            val pts = ArrayList<DoubleArray>(coords.length())
            for (j in 0 until coords.length()) {
                val c = coords.getJSONArray(j)
                pts.add(doubleArrayOf(c.getDouble(1), c.getDouble(0)))
            }
            val steps = ArrayList<Step>()
            val legs = r.getJSONArray("legs")
            for (l in 0 until legs.length()) {
                val st = legs.getJSONObject(l).getJSONArray("steps")
                for (k in 0 until st.length()) {
                    val s = st.getJSONObject(k)
                    val m = s.getJSONObject("maneuver")
                    val loc = m.getJSONArray("location")
                    steps.add(
                        Step(
                            loc.getDouble(1), loc.getDouble(0),
                            m.optString("type"), m.optString("modifier"),
                            s.optString("name"), s.optDouble("distance", 0.0)
                        )
                    )
                }
            }
            if (steps.size >= 2) out.add(Route(pts, steps, r.getDouble("distance"), r.getDouble("duration")))
        }
        if (out.isEmpty()) throw Exception("no route")
        return out
    }

    fun routeJson(r: Route?): String {
        if (r == null) return EMPTY_GEOJSON
        val coords = JSONArray()
        for (p in r.pts) coords.put(JSONArray().put(p[1]).put(p[0]))
        val geom = JSONObject().put("type", "LineString").put("coordinates", coords)
        return JSONObject().put("type", "Feature").put("properties", JSONObject()).put("geometry", geom).toString()
    }
}
