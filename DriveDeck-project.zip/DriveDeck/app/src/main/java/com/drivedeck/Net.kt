package com.drivedeck

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sqrt

data class Place(val name: String, val lat: Double, val lon: Double)
data class Step(
    val lat: Double, val lon: Double,
    val type: String, val modifier: String,
    val street: String, val dist: Double
)
data class Route(
    val pts: List<DoubleArray>, // [lat, lon]
    val steps: List<Step>,
    val distance: Double,
    val duration: Double,
    val label: String = ""
)

/** ОНЛАЙН-сервисы (нужен интернет): Nominatim (поиск) и публичный сервер OSRM (маршруты). */
object Net {
    const val EMPTY_GEOJSON = "{\"type\":\"FeatureCollection\",\"features\":[]}"

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 20000
        c.setRequestProperty("User-Agent", "DriveDeck/0.5 (personal navigation app)")
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    fun geocode(q: String, lang: String): List<Place> {
        val url = "https://nominatim.openstreetmap.org/search?format=json&limit=6&countrycodes=ua" +
            "&accept-language=$lang&q=" + URLEncoder.encode(q, "UTF-8")
        val arr = JSONArray(get(url))
        val out = ArrayList<Place>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val name = o.getString("display_name").split(",").take(4).joinToString(",").trim()
            out.add(Place(name, o.getString("lat").toDouble(), o.getString("lon").toDouble()))
        }
        return out
    }

    /** Адрес по координатам (для точки, выбранной на карте). */
    fun reverse(lat: Double, lon: Double, lang: String): String? {
        val url = "https://nominatim.openstreetmap.org/reverse?format=json&zoom=18&lat=$lat&lon=$lon&accept-language=$lang"
        val o = JSONObject(get(url))
        val a = o.optJSONObject("address")
        if (a != null) {
            val road = a.optString("road", "")
            val house = a.optString("house_number", "")
            var place = ""
            for (k in listOf("city", "town", "village", "hamlet", "suburb")) {
                val v = a.optString(k, "")
                if (v.isNotEmpty()) { place = v; break }
            }
            val street = (road + " " + house).trim()
            val name = listOf(street, place).filter { it.isNotEmpty() }.joinToString(", ")
            if (name.isNotEmpty()) return name
        }
        val d = o.optString("display_name", "")
        return if (d.isEmpty()) null else d.split(",").take(3).joinToString(",").trim()
    }

    private fun osrm(
        fromLat: Double, fromLon: Double, toLat: Double, toLon: Double,
        vias: List<DoubleArray>, exclude: String?, alternatives: Boolean, label: String
    ): List<Route> {
        val sb = StringBuilder("https://router.project-osrm.org/route/v1/driving/")
        sb.append("$fromLon,$fromLat")
        for (v in vias) sb.append(";${v[1]},${v[0]}")
        sb.append(";$toLon,$toLat")
        sb.append("?steps=true&geometries=geojson&overview=full")
        sb.append(if (alternatives) "&alternatives=3" else "&alternatives=false")
        if (exclude != null) sb.append("&exclude=$exclude")
        val root = JSONObject(get(sb.toString()))
        if (root.optString("code") != "Ok") throw Exception("route: " + root.optString("code"))
        val arr = root.getJSONArray("routes")
        val out = ArrayList<Route>()
        for (i in 0 until arr.length()) {
            val r = arr.getJSONObject(i)
            val coords = r.getJSONObject("geometry").getJSONArray("coordinates")
            val pts = ArrayList<DoubleArray>(coords.length())
            for (j in 0 until coords.length()) {
                val c = coords.getJSONArray(j)
                pts.add(doubleArrayOf(c.getDouble(1), c.getDouble(0)))
            }
            val steps = ArrayList<Step>()
            val legs = r.getJSONArray("legs")
            for (l in 0 until legs.length()) {
                val st = legs.getJSONObject(l).getJSONArray("steps")
                for (k in 0 until st.length()) {
                    val s = st.getJSONObject(k)
                    val m = s.getJSONObject("maneuver")
                    val type = m.optString("type")
                    // промежуточные точки не должны звучать как «вы прибыли»
                    if (l < legs.length() - 1 && type == "arrive") continue
                    if (l > 0 && type == "depart") continue
                    val loc = m.getJSONArray("location")
                    steps.add(
                        Step(
                            loc.getDouble(1), loc.getDouble(0),
                            type, m.optString("modifier"),
                            s.optString("name"), s.optDouble("distance", 0.0)
                        )
                    )
                }
            }
            if (steps.size >= 2) {
                out.add(Route(pts, steps, r.getDouble("distance"), r.getDouble("duration"),
                    if (i == 0) label else "Альтернатива"))
            }
        }
        if (out.isEmpty()) throw Exception("no route")
        return out
    }

    /** Быстрый маршрут (для пересчёта при отклонении). */
    fun fastRoute(fromLat: Double, fromLon: Double, toLat: Double, toLon: Double): Route =
        osrm(fromLat, fromLon, toLat, toLon, emptyList(), null, false, "Быстрый")[0]

    private fun offsetVia(fromLat: Double, fromLon: Double, toLat: Double, toLon: Double, frac: Double): DoubleArray {
        val midLat = (fromLat + toLat) / 2
        val midLon = (fromLon + toLon) / 2
        val k = cos(Math.toRadians(midLat))
        val dx = (toLon - fromLon) * k
        val dy = toLat - fromLat
        val len = sqrt(dx * dx + dy * dy)
        if (len == 0.0) return doubleArrayOf(midLat, midLon)
        val off = min(len * abs(frac), 0.3) * (if (frac < 0) -1 else 1)
        val px = -dy / len
        val py = dx / len
        return doubleArrayOf(midLat + py * off, midLon + px * off / k)
    }

    private fun similar(a: Route, b: Route): Boolean {
        if (abs(a.distance - b.distance) > a.distance * 0.03) return false
        val n = 25
        var near = 0
        for (i in 0 until n) {
            val p = b.pts[(i * (b.pts.size - 1)) / (n - 1)]
            if (distToPts(a.pts, p[0], p[1]) < 60) near++
        }
        return near >= n - 1
    }

    /**
     * Несколько вариантов: быстрый + альтернативы OSRM, «без трасс» и два объезда через боковые точки.
     * Если пользователь задал свои промежуточные точки — строится маршрут через них.
     */
    fun routesMulti(
        fromLat: Double, fromLon: Double, toLat: Double, toLon: Double, manualVias: List<DoubleArray>
    ): List<Route> {
        val jobs = ArrayList<() -> List<Route>>()
        jobs.add { osrm(fromLat, fromLon, toLat, toLon, manualVias, null, manualVias.isEmpty(), "Быстрый") }
        if (manualVias.isEmpty()) {
            jobs.add { osrm(fromLat, fromLon, toLat, toLon, emptyList(), "motorway", false, "Без трасс") }
            val right = offsetVia(fromLat, fromLon, toLat, toLon, 0.22)
            val left = offsetVia(fromLat, fromLon, toLat, toLon, -0.22)
            jobs.add { osrm(fromLat, fromLon, toLat, toLon, listOf(right), null, false, "Объезд справа") }
            jobs.add { osrm(fromLat, fromLon, toLat, toLon, listOf(left), null, false, "Объезд слева") }
        }
        val results = arrayOfNulls<List<Route>>(jobs.size)
        val threads = ArrayList<Thread>()
        for (i in jobs.indices) {
            val t = Thread {
                try { results[i] = jobs[i]() } catch (e: Exception) { }
            }
            threads.add(t)
            t.start()
        }
        for (t in threads) t.join()
        val all = ArrayList<Route>()
        for (list in results) {
            if (list == null) continue
            for (r in list) if (all.none { similar(it, r) }) all.add(r)
        }
        if (all.isEmpty()) throw Exception("no route")
        all.sortBy { it.duration }
        return all.take(6)
    }

    fun routeJson(r: Route?): String {
        if (r == null) return EMPTY_GEOJSON
        val coords = JSONArray()
        for (p in r.pts) coords.put(JSONArray().put(p[1]).put(p[0]))
        val geom = JSONObject().put("type", "LineString").put("coordinates", coords)
        return JSONObject().put("type", "Feature").put("properties", JSONObject()).put("geometry", geom).toString()
    }

    fun pointsJson(list: List<Place>): String {
        val feats = JSONArray()
        for (p in list) {
            val geom = JSONObject().put("type", "Point").put("coordinates", JSONArray().put(p.lon).put(p.lat))
            feats.put(JSONObject().put("type", "Feature").put("properties", JSONObject()).put("geometry", geom))
        }
        return JSONObject().put("type", "FeatureCollection").put("features", feats).toString()
    }
}
