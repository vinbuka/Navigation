package com.drivedeck

import android.service.notification.NotificationListenerService

/** Пустой сервис: нужен только чтобы Android дал приложению доступ к активным медиасессиям. */
class MediaListener : NotificationListenerService()
