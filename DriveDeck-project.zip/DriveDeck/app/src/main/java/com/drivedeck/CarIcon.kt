package com.drivedeck

import android.graphics.BlurMaskFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader

/** Иконка автомобиля (вид сверху, передок вверх) с объёмной подсветкой: градиенты, блики, тень. */
object CarIcon {
    val TYPES = listOf(
        "sedan" to "Легковой",
        "suv" to "Внедорожник",
        "truck" to "Грузовик",
        "moto" to "Мотоцикл",
        "arrow" to "Стрелка"
    )
    val COLORS: List<Int> = listOf(
        "#E53935", "#1E88E5", "#FFFFFF", "#212121",
        "#FDD835", "#43A047", "#FB8C00", "#9E9E9E"
    ).map { Color.parseColor(it) }

    private val TIRE = Color.parseColor("#151515")
    private val GLASS_TOP = Color.parseColor("#607D8B")
    private val GLASS_BOTTOM = Color.parseColor("#0B1519")

    private fun shade(c: Int, f: Float) =
        Color.rgb((Color.red(c) * f).toInt(), (Color.green(c) * f).toInt(), (Color.blue(c) * f).toInt())

    private fun mix(c: Int, w: Float) = Color.rgb(
        (Color.red(c) + (255 - Color.red(c)) * w).toInt(),
        (Color.green(c) + (255 - Color.green(c)) * w).toInt(),
        (Color.blue(c) + (255 - Color.blue(c)) * w).toInt()
    )

    fun draw(type: String, color: Int, size: Int): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val k = size / 100f

        fun paint() = Paint(Paint.ANTI_ALIAS_FLAG)
        fun rf(l: Float, t: Float, r: Float, b: Float) = RectF(l * k, t * k, r * k, b * k)

        fun flat(l: Float, t: Float, r: Float, b: Float, rad: Float, col: Int) {
            val pt = paint()
            pt.color = col
            c.drawRoundRect(rf(l, t, r, b), rad * k, rad * k, pt)
        }

        fun shadow(l: Float, t: Float, r: Float, b: Float, rad: Float) {
            val pt = paint()
            pt.color = Color.argb(110, 0, 0, 0)
            pt.maskFilter = BlurMaskFilter(3f * k, BlurMaskFilter.Blur.NORMAL)
            c.drawRoundRect(rf(l + 2f, t + 4f, r + 2f, b + 4f), rad * k, rad * k, pt)
        }

        // кузов: тень, «борт» тёмного цвета (толщина), белый контур, цилиндрический градиент, глянец
        fun body(l: Float, t: Float, r: Float, b: Float, rad: Float, col: Int) {
            shadow(l, t, r, b, rad)
            val ext = rf(l, t + 2.5f, r, b + 2.5f)
            val pt = paint()
            pt.style = Paint.Style.STROKE
            pt.strokeWidth = 4.5f * k
            pt.color = Color.WHITE
            c.drawRoundRect(ext, rad * k, rad * k, pt)
            pt.style = Paint.Style.FILL
            pt.color = shade(col, 0.5f)
            c.drawRoundRect(ext, rad * k, rad * k, pt)
            pt.shader = LinearGradient(
                l * k, 0f, r * k, 0f,
                intArrayOf(shade(col, 0.62f), mix(col, 0.28f), shade(col, 0.62f)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
            c.drawRoundRect(rf(l, t, r, b), rad * k, rad * k, pt)
            val g = paint()
            val midY = t + (b - t) * 0.5f
            g.shader = LinearGradient(
                0f, t * k, 0f, midY * k,
                Color.argb(130, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP
            )
            c.drawRoundRect(rf(l + 3f, t + 2f, r - 3f, midY), rad * k * 0.8f, rad * k * 0.8f, g)
        }

        fun glass(l: Float, t: Float, r: Float, b: Float, rad: Float) {
            val pt = paint()
            pt.shader = LinearGradient(0f, t * k, 0f, b * k, GLASS_TOP, GLASS_BOTTOM, Shader.TileMode.CLAMP)
            c.drawRoundRect(rf(l, t, r, b), rad * k, rad * k, pt)
            val w = r - l
            val ref = Path()
            ref.moveTo((l + w * 0.12f) * k, b * k)
            ref.lineTo((l + w * 0.32f) * k, t * k)
            ref.lineTo((l + w * 0.47f) * k, t * k)
            ref.lineTo((l + w * 0.27f) * k, b * k)
            ref.close()
            val rp = paint()
            rp.color = Color.argb(55, 255, 255, 255)
            c.drawPath(ref, rp)
        }

        fun wheel(l: Float, t: Float, r: Float, b: Float) {
            flat(l, t, r, b, 2.5f, TIRE)
            flat(l + 1.5f, t + 2f, l + 3f, b - 2f, 1f, Color.argb(70, 255, 255, 255))
        }

        fun light(x: Float, y: Float, r: Float, col: Int) {
            val glow = paint()
            glow.shader = RadialGradient(
                x * k, y * k, r * 2.4f * k,
                col, Color.argb(0, Color.red(col), Color.green(col), Color.blue(col)),
                Shader.TileMode.CLAMP
            )
            c.drawCircle(x * k, y * k, r * 2.4f * k, glow)
            val dot = paint()
            dot.color = mix(col, 0.6f)
            c.drawCircle(x * k, y * k, r * k, dot)
        }

        fun sphere(x: Float, y: Float, r: Float, col: Int) {
            val pt = paint()
            pt.shader = RadialGradient(
                (x - r * 0.35f) * k, (y - r * 0.35f) * k, r * 1.5f * k,
                intArrayOf(mix(col, 0.7f), col, shade(col, 0.55f)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
            c.drawCircle(x * k, y * k, r * k, pt)
        }

        val head = Color.parseColor("#FFF59D")
        val tail = Color.parseColor("#FF5252")

        when (type) {
            "arrow" -> {
                fun arrowPath(dy: Float): Path {
                    val a = Path()
                    a.moveTo(50f * k, (6f + dy) * k)
                    a.lineTo(82f * k, (90f + dy) * k)
                    a.lineTo(50f * k, (72f + dy) * k)
                    a.lineTo(18f * k, (90f + dy) * k)
                    a.close()
                    return a
                }
                val sh = paint()
                sh.color = Color.argb(110, 0, 0, 0)
                sh.maskFilter = BlurMaskFilter(3f * k, BlurMaskFilter.Blur.NORMAL)
                c.drawPath(arrowPath(5f), sh)
                val pt = paint()
                pt.style = Paint.Style.STROKE
                pt.strokeWidth = 5f * k
                pt.color = Color.WHITE
                pt.strokeJoin = Paint.Join.ROUND
                c.drawPath(arrowPath(2.5f), pt)
                pt.style = Paint.Style.FILL
                pt.color = shade(color, 0.45f)
                c.drawPath(arrowPath(2.5f), pt)
                val left = Path()
                left.moveTo(50f * k, 6f * k)
                left.lineTo(18f * k, 90f * k)
                left.lineTo(50f * k, 72f * k)
                left.close()
                pt.color = mix(color, 0.25f)
                c.drawPath(left, pt)
                val right = Path()
                right.moveTo(50f * k, 6f * k)
                right.lineTo(82f * k, 90f * k)
                right.lineTo(50f * k, 72f * k)
                right.close()
                pt.color = shade(color, 0.7f)
                c.drawPath(right, pt)
            }
            "moto" -> {
                wheel(46f, 4f, 54f, 24f)
                wheel(45f, 76f, 55f, 96f)
                body(42f, 24f, 58f, 80f, 8f, color)
                flat(27f, 30f, 73f, 35.5f, 2.7f, Color.parseColor("#1C1C1C"))
                flat(24f, 28.5f, 29f, 37f, 2f, Color.parseColor("#3A3A3A"))
                flat(71f, 28.5f, 76f, 37f, 2f, Color.parseColor("#3A3A3A"))
                flat(36f, 46f, 64f, 64f, 8f, Color.parseColor("#37474F"))
                sphere(50f, 52f, 8f, color)
                light(50f, 12f, 2.6f, head)
                light(50f, 90f, 2.2f, tail)
            }
            "truck" -> {
                wheel(23f, 10f, 30f, 32f)
                wheel(70f, 10f, 77f, 32f)
                wheel(23f, 64f, 30f, 92f)
                wheel(70f, 64f, 77f, 92f)
                body(29f, 40f, 71f, 96f, 4f, shade(color, 0.85f))
                flat(39f, 45f, 40.8f, 91f, 0.6f, shade(color, 0.45f))
                flat(49.1f, 45f, 50.9f, 91f, 0.6f, shade(color, 0.45f))
                flat(59.2f, 45f, 61f, 91f, 0.6f, shade(color, 0.45f))
                body(30f, 5f, 70f, 37f, 10f, color)
                glass(34f, 14f, 66f, 26f, 4f)
                flat(24f, 17f, 29f, 24f, 2f, shade(color, 0.7f))
                flat(71f, 17f, 76f, 24f, 2f, shade(color, 0.7f))
                light(37f, 9f, 2.8f, head)
                light(63f, 9f, 2.8f, head)
                light(36f, 94f, 2.2f, tail)
                light(64f, 94f, 2.2f, tail)
            }
            "suv" -> {
                wheel(21f, 14f, 29f, 35f)
                wheel(71f, 14f, 79f, 35f)
                wheel(21f, 65f, 29f, 86f)
                wheel(71f, 65f, 79f, 86f)
                body(27f, 5f, 73f, 95f, 13f, color)
                glass(31f, 24f, 69f, 39f, 5f)
                flat(38f, 44f, 62f, 70f, 3f, mix(color, 0.18f))
                flat(33.5f, 44f, 37.5f, 70f, 1.5f, shade(color, 0.4f))
                flat(62.5f, 44f, 66.5f, 70f, 1.5f, shade(color, 0.4f))
                glass(31f, 72f, 69f, 85f, 5f)
                flat(22f, 28f, 27f, 35f, 2f, shade(color, 0.7f))
                flat(73f, 28f, 78f, 35f, 2f, shade(color, 0.7f))
                light(35f, 10f, 3f, head)
                light(65f, 10f, 3f, head)
                light(35f, 91f, 2.4f, tail)
                light(65f, 91f, 2.4f, tail)
            }
            else -> { // sedan
                wheel(24f, 15f, 31f, 34f)
                wheel(69f, 15f, 76f, 34f)
                wheel(24f, 66f, 31f, 85f)
                wheel(69f, 66f, 76f, 85f)
                body(30f, 7f, 70f, 93f, 15f, color)
                glass(34f, 27f, 66f, 41f, 5f)
                flat(36f, 43f, 64f, 62f, 4f, mix(color, 0.2f))
                glass(35f, 63f, 65f, 75f, 5f)
                flat(25f, 30f, 30f, 37f, 2f, shade(color, 0.7f))
                flat(70f, 30f, 75f, 37f, 2f, shade(color, 0.7f))
                light(36f, 11f, 3f, head)
                light(64f, 11f, 3f, head)
                light(37f, 89f, 2.4f, tail)
                light(63f, 89f, 2.4f, tail)
            }
        }
        return bmp
    }
}
