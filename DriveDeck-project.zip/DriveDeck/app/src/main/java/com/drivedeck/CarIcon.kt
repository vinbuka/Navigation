package com.drivedeck

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF

/** Рисует иконку автомобиля (вид сверху, передок вверх) выбранного типа и цвета. */
object CarIcon {
    val TYPES = listOf(
        "sedan" to "Легковой",
        "suv" to "Внедорожник",
        "truck" to "Грузовик",
        "moto" to "Мотоцикл",
        "arrow" to "Стрелка"
    )
    val COLORS: List<Int> = listOf(
        "#E53935", "#1E88E5", "#FFFFFF", "#212121",
        "#FDD835", "#43A047", "#FB8C00", "#9E9E9E"
    ).map { Color.parseColor(it) }

    private val GLASS = Color.parseColor("#263238")
    private val TIRE = Color.parseColor("#111111")

    private fun shade(c: Int, f: Float) =
        Color.rgb((Color.red(c) * f).toInt(), (Color.green(c) * f).toInt(), (Color.blue(c) * f).toInt())

    fun draw(type: String, color: Int, size: Int): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val k = size / 100f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        fun rect(l: Float, t: Float, r: Float, b: Float, rad: Float, fill: Int, outline: Boolean) {
            val rf = RectF(l * k, t * k, r * k, b * k)
            if (outline) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 5f * k
                p.color = Color.WHITE
                c.drawRoundRect(rf, rad * k, rad * k, p)
            }
            p.style = Paint.Style.FILL
            p.color = fill
            c.drawRoundRect(rf, rad * k, rad * k, p)
        }
        fun dot(x: Float, y: Float, r: Float, fill: Int) {
            p.style = Paint.Style.FILL
            p.color = fill
            c.drawCircle(x * k, y * k, r * k, p)
        }

        when (type) {
            "arrow" -> {
                val path = Path()
                path.moveTo(50f * k, 6f * k)
                path.lineTo(82f * k, 90f * k)
                path.lineTo(50f * k, 72f * k)
                path.lineTo(18f * k, 90f * k)
                path.close()
                p.style = Paint.Style.STROKE
                p.strokeWidth = 5f * k
                p.color = Color.WHITE
                c.drawPath(path, p)
                p.style = Paint.Style.FILL
                p.color = color
                c.drawPath(path, p)
            }
            "moto" -> {
                rect(46f, 6f, 54f, 24f, 3f, TIRE, false)
                rect(46f, 76f, 54f, 94f, 3f, TIRE, false)
                rect(42f, 24f, 58f, 78f, 8f, color, true)
                rect(28f, 30f, 72f, 36f, 3f, GLASS, false)
                dot(50f, 56f, 9f, Color.parseColor("#37474F"))
                dot(50f, 50f, 6f, shade(color, 0.8f))
            }
            "truck" -> {
                rect(24f, 14f, 30f, 34f, 2f, TIRE, false)
                rect(70f, 14f, 76f, 34f, 2f, TIRE, false)
                rect(24f, 66f, 30f, 90f, 2f, TIRE, false)
                rect(70f, 66f, 76f, 90f, 2f, TIRE, false)
                rect(29f, 40f, 71f, 96f, 4f, shade(color, 0.75f), true)
                rect(30f, 5f, 70f, 36f, 9f, color, true)
                rect(34f, 15f, 66f, 25f, 3f, GLASS, false)
                dot(37f, 9f, 3.5f, Color.parseColor("#FFEB3B"))
                dot(63f, 9f, 3.5f, Color.parseColor("#FFEB3B"))
            }
            "suv" -> {
                rect(22f, 16f, 29f, 34f, 3f, TIRE, false)
                rect(71f, 16f, 78f, 34f, 3f, TIRE, false)
                rect(22f, 66f, 29f, 84f, 3f, TIRE, false)
                rect(71f, 66f, 78f, 84f, 3f, TIRE, false)
                rect(27f, 5f, 73f, 95f, 12f, color, true)
                rect(31f, 25f, 69f, 39f, 4f, GLASS, false)
                rect(31f, 71f, 69f, 83f, 4f, GLASS, false)
                rect(35f, 44f, 38f, 68f, 1.5f, shade(color, 0.6f), false)
                rect(62f, 44f, 65f, 68f, 1.5f, shade(color, 0.6f), false)
                dot(35f, 10f, 3.5f, Color.parseColor("#FFEB3B"))
                dot(65f, 10f, 3.5f, Color.parseColor("#FFEB3B"))
                dot(35f, 91f, 3f, Color.parseColor("#E53935"))
                dot(65f, 91f, 3f, Color.parseColor("#E53935"))
            }
            else -> { // sedan
                rect(25f, 18f, 31f, 33f, 2f, TIRE, false)
                rect(69f, 18f, 75f, 33f, 2f, TIRE, false)
                rect(25f, 67f, 31f, 82f, 2f, TIRE, false)
                rect(69f, 67f, 75f, 82f, 2f, TIRE, false)
                rect(30f, 7f, 70f, 93f, 14f, color, true)
                rect(34f, 27f, 66f, 41f, 4f, GLASS, false)
                rect(34f, 63f, 66f, 75f, 4f, GLASS, false)
                rect(35f, 43f, 65f, 61f, 3f, shade(color, 0.85f), false)
                dot(37f, 12f, 3.5f, Color.parseColor("#FFEB3B"))
                dot(63f, 12f, 3.5f, Color.parseColor("#FFEB3B"))
                dot(37f, 88f, 3f, Color.parseColor("#E53935"))
                dot(63f, 88f, 3f, Color.parseColor("#E53935"))
            }
        }
        return bmp
    }
}
