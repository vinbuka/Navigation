package com.drivedeck

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader

/** Иконки машинок (вид сверху, передок вверх) с объёмной подсветкой: градиенты, блики, тени. */
object CarIcon {
    val TYPES = listOf(
        "sedan" to "Легковой",
        "suv" to "Внедорожник",
        "truck" to "Грузовик",
        "moto" to "Мотоцикл",
        "bears" to "Мишки в кабриолете",
        "arrow" to "Стрелка"
    )
    val COLORS: List<Int> = listOf(
        "#E53935", "#1E88E5", "#FFFFFF", "#212121",
        "#FDD835", "#43A047", "#FB8C00", "#9E9E9E"
    ).map { Color.parseColor(it) }

    private val TIRE = Color.parseColor("#151515")
    private val GLASS_TOP = Color.parseColor("#78909C")
    private val GLASS_BOTTOM = Color.parseColor("#0A1418")

    private fun shade(c: Int, f: Float) =
        Color.rgb((Color.red(c) * f).toInt(), (Color.green(c) * f).toInt(), (Color.blue(c) * f).toInt())

    private fun mix(c: Int, w: Float) = Color.rgb(
        (Color.red(c) + (255 - Color.red(c)) * w).toInt(),
        (Color.green(c) + (255 - Color.green(c)) * w).toInt(),
        (Color.blue(c) + (255 - Color.blue(c)) * w).toInt()
    )

    private fun pnt() = Paint(Paint.ANTI_ALIAS_FLAG)

    // ---------- мишки (мультяшные, лицом к зрителю) ----------
    private fun drawBear(c: Canvas, k: Float, cx: Float, cy: Float, r: Float, white: Boolean) {
        val fur = Color.parseColor(if (white) "#F7F4EF" else "#B58455")
        val furDark = Color.parseColor(if (white) "#C9C4BB" else "#7A5233")
        val ear = Color.parseColor(if (white) "#262626" else "#8A5E3C")
        val line = Color.parseColor("#3A2A22")

        val sh = pnt()
        sh.color = Color.argb(90, 0, 0, 0)
        sh.maskFilter = BlurMaskFilter(r * 0.25f * k, BlurMaskFilter.Blur.NORMAL)
        c.drawOval(RectF((cx - r) * k, (cy + r * 0.6f) * k, (cx + r) * k, (cy + r * 1.3f) * k), sh)

        val bp = pnt()
        bp.shader = RadialGradient(cx * k, (cy + r * 0.95f) * k, r * k, fur, furDark, Shader.TileMode.CLAMP)
        c.drawOval(RectF((cx - r * 0.85f) * k, (cy + r * 0.55f) * k, (cx + r * 0.85f) * k, (cy + r * 1.35f) * k), bp)
        if (white) {
            val cp = pnt()
            cp.color = Color.parseColor("#1E1E1E")
            c.drawOval(RectF((cx - r * 0.62f) * k, (cy + r * 0.8f) * k, (cx + r * 0.62f) * k, (cy + r * 1.12f) * k), cp)
        }

        for (sx in floatArrayOf(-1f, 1f)) {
            val ex = cx + sx * r * 0.72f
            val ey = cy - r * 0.72f
            val er = r * 0.36f
            val e = pnt()
            e.shader = RadialGradient(
                (ex - er * 0.3f) * k, (ey - er * 0.3f) * k, er * 1.5f * k,
                mix(ear, 0.35f), ear, Shader.TileMode.CLAMP
            )
            c.drawCircle(ex * k, ey * k, er * k, e)
            val o = pnt()
            o.style = Paint.Style.STROKE
            o.strokeWidth = r * 0.05f * k
            o.color = line
            c.drawCircle(ex * k, ey * k, er * k, o)
        }

        val hp = pnt()
        hp.shader = RadialGradient(
            (cx - r * 0.35f) * k, (cy - r * 0.4f) * k, r * 1.7f * k,
            intArrayOf(mix(fur, 0.5f), fur, furDark), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx * k, cy * k, r * k, hp)
        val ho = pnt()
        ho.style = Paint.Style.STROKE
        ho.strokeWidth = r * 0.05f * k
        ho.color = line
        c.drawCircle(cx * k, cy * k, r * k, ho)

        val gl = pnt()
        gl.color = Color.argb(70, 255, 255, 255)
        c.drawOval(RectF((cx - r * 0.7f) * k, (cy - r * 0.8f) * k, (cx - r * 0.1f) * k, (cy - r * 0.45f) * k), gl)

        val ch = pnt()
        ch.color = Color.argb(190, 244, 143, 177)
        c.drawCircle((cx - r * 0.62f) * k, (cy + r * 0.3f) * k, r * 0.2f * k, ch)
        c.drawCircle((cx + r * 0.62f) * k, (cy + r * 0.3f) * k, r * 0.2f * k, ch)

        val eye = pnt()
        eye.color = Color.parseColor("#1B1B1B")
        val glint = pnt()
        glint.color = Color.WHITE
        for (sx in floatArrayOf(-1f, 1f)) {
            val x = cx + sx * r * 0.36f
            c.drawCircle(x * k, (cy + r * 0.02f) * k, r * 0.11f * k, eye)
            c.drawCircle((x - r * 0.03f) * k, (cy - r * 0.02f) * k, r * 0.04f * k, glint)
        }

        val np = pnt()
        np.color = line
        c.drawCircle(cx * k, (cy + r * 0.17f) * k, r * 0.045f * k, np)
        val mp = pnt()
        mp.color = Color.parseColor("#E96A7A")
        c.drawOval(RectF((cx - r * 0.13f) * k, (cy + r * 0.22f) * k, (cx + r * 0.13f) * k, (cy + r * 0.4f) * k), mp)
    }

    /** Мишки лицом к зрителю над бортиком кабриолета — для наклонной (3D) карты. */
    fun drawBearsFront(color: Int, size: Int): Bitmap {
        val h = (size * 0.8f).toInt()
        val bmp = Bitmap.createBitmap(size, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val k = size / 100f
        drawBear(c, k, 31f, 36f, 22f, true)
        drawBear(c, k, 69f, 36f, 22f, false)
        val rect = RectF(10f * k, 62f * k, 90f * k, 78f * k)
        val st = pnt()
        st.style = Paint.Style.STROKE
        st.strokeWidth = 4f * k
        st.color = Color.WHITE
        c.drawRoundRect(rect, 8f * k, 8f * k, st)
        val rp = pnt()
        rp.shader = LinearGradient(0f, 62f * k, 0f, 78f * k, mix(color, 0.35f), shade(color, 0.6f), Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, 8f * k, 8f * k, rp)
        return bmp
    }

    fun draw(type: String, color: Int, size: Int): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val k = size / 100f

        fun rf(l: Float, t: Float, r: Float, b: Float) = RectF(l * k, t * k, r * k, b * k)

        fun poly(vararg v: Float): Path {
            val p = Path()
            p.moveTo(v[0] * k, v[1] * k)
            var i = 2
            while (i < v.size) {
                p.lineTo(v[i] * k, v[i + 1] * k)
                i += 2
            }
            p.close()
            return p
        }

        fun flat(l: Float, t: Float, r: Float, b: Float, rad: Float, col: Int) {
            val pt = pnt()
            pt.color = col
            c.drawRoundRect(rf(l, t, r, b), rad * k, rad * k, pt)
        }

        fun shadow(l: Float, t: Float, r: Float, b: Float, rad: Float) {
            val pt = pnt()
            pt.color = Color.argb(115, 0, 0, 0)
            pt.maskFilter = BlurMaskFilter(3.2f * k, BlurMaskFilter.Blur.NORMAL)
            c.drawRoundRect(rf(l + 2f, t + 4f, r + 2f, b + 4f), rad * k, rad * k, pt)
        }

        // кузов: тень, «борт» (толщина), белый контур, цилиндрический градиент, глянец
        fun body(l: Float, t: Float, r: Float, b: Float, rad: Float, col: Int) {
            shadow(l, t, r, b, rad)
            val ext = rf(l, t + 2.5f, r, b + 2.5f)
            val pt = pnt()
            pt.style = Paint.Style.STROKE
            pt.strokeWidth = 4.5f * k
            pt.color = Color.WHITE
            c.drawRoundRect(ext, rad * k, rad * k, pt)
            pt.style = Paint.Style.FILL
            pt.color = shade(col, 0.45f)
            c.drawRoundRect(ext, rad * k, rad * k, pt)
            pt.shader = LinearGradient(
                l * k, 0f, r * k, 0f,
                intArrayOf(shade(col, 0.6f), mix(col, 0.3f), shade(col, 0.6f)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
            c.drawRoundRect(rf(l, t, r, b), rad * k, rad * k, pt)
            val g = pnt()
            val midY = t + (b - t) * 0.5f
            g.shader = LinearGradient(
                0f, t * k, 0f, midY * k,
                Color.argb(140, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP
            )
            c.drawRoundRect(rf(l + 3f, t + 2f, r - 3f, midY), rad * k * 0.8f, rad * k * 0.8f, g)
        }

        // стекло-трапеция с градиентом и бликом
        fun glassPoly(path: Path, t: Float, b: Float) {
            val pt = pnt()
            pt.shader = LinearGradient(0f, t * k, 0f, b * k, GLASS_TOP, GLASS_BOTTOM, Shader.TileMode.CLAMP)
            c.drawPath(path, pt)
            val rb = RectF()
            path.computeBounds(rb, true)
            val w = rb.width()
            val ref = Path()
            ref.moveTo(rb.left + w * 0.15f, rb.bottom)
            ref.lineTo(rb.left + w * 0.38f, rb.top)
            ref.lineTo(rb.left + w * 0.52f, rb.top)
            ref.lineTo(rb.left + w * 0.29f, rb.bottom)
            ref.close()
            c.save()
            c.clipPath(path)
            val rp = pnt()
            rp.color = Color.argb(60, 255, 255, 255)
            c.drawPath(ref, rp)
            c.restore()
        }

        // крыша: выпуклая, с бликом
        fun roofRect(l: Float, t: Float, r: Float, b: Float, rad: Float, col: Int) {
            val pt = pnt()
            pt.shader = LinearGradient(
                l * k, 0f, r * k, 0f,
                intArrayOf(shade(col, 0.7f), mix(col, 0.35f), shade(col, 0.7f)),
                floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
            )
            c.drawRoundRect(rf(l, t, r, b), rad * k, rad * k, pt)
            val g = pnt()
            g.shader = LinearGradient(
                0f, t * k, 0f, (t + (b - t) * 0.5f) * k,
                Color.argb(110, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP
            )
            c.drawRoundRect(rf(l + 2f, t + 1.5f, r - 2f, t + (b - t) * 0.5f), rad * k * 0.7f, rad * k * 0.7f, g)
        }

        fun wheel(l: Float, t: Float, r: Float, b: Float) {
            flat(l, t, r, b, 2.5f, TIRE)
            flat(l + 1.5f, t + 2f, l + 3f, b - 2f, 1f, Color.argb(80, 255, 255, 255))
        }

        fun light(x: Float, y: Float, r: Float, col: Int) {
            val glow = pnt()
            glow.shader = RadialGradient(
                x * k, y * k, r * 2.4f * k,
                col, Color.argb(0, Color.red(col), Color.green(col), Color.blue(col)),
                Shader.TileMode.CLAMP
            )
            c.drawCircle(x * k, y * k, r * 2.4f * k, glow)
            val dot = pnt()
            dot.color = mix(col, 0.6f)
            c.drawCircle(x * k, y * k, r * k, dot)
        }

        fun sphere(x: Float, y: Float, r: Float, col: Int) {
            val pt = pnt()
            pt.shader = RadialGradient(
                (x - r * 0.35f) * k, (y - r * 0.35f) * k, r * 1.5f * k,
                intArrayOf(mix(col, 0.7f), col, shade(col, 0.5f)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
            c.drawCircle(x * k, y * k, r * k, pt)
        }

        val head = Color.parseColor("#FFF59D")
        val tail = Color.parseColor("#FF5252")
        val crease = Color.argb(70, 0, 0, 0)

        when (type) {
            "bears" -> {
                wheel(7f, 22f, 15f, 42f)
                wheel(85f, 22f, 93f, 42f)
                wheel(7f, 62f, 15f, 82f)
                wheel(85f, 62f, 93f, 82f)
                body(14f, 10f, 86f, 92f, 16f, color)
                flat(19f, 28f, 81f, 85f, 12f, Color.parseColor("#2E2420"))
                glassPoly(poly(21f, 25f, 79f, 25f, 77f, 29.5f, 23f, 29.5f), 25f, 29.5f)
                flat(21f, 36f, 49f, 83f, 8f, Color.parseColor("#4A3A30"))
                flat(51f, 36f, 79f, 83f, 8f, Color.parseColor("#4A3A30"))
                drawBear(c, k, 35f, 55f, 17f, true)
                drawBear(c, k, 65f, 55f, 17f, false)
                light(27f, 14f, 3f, head)
                light(73f, 14f, 3f, head)
                light(27f, 88.5f, 2.5f, tail)
                light(73f, 88.5f, 2.5f, tail)
            }
            "arrow" -> {
                fun arrowPath(dy: Float, s: Float): Path {
                    val a = Path()
                    a.moveTo(50f * k, (50f - 44f * s + dy) * k)
                    a.lineTo((50f + 32f * s) * k, (50f + 40f * s + dy) * k)
                    a.lineTo(50f * k, (50f + 22f * s + dy) * k)
                    a.lineTo((50f - 32f * s) * k, (50f + 40f * s + dy) * k)
                    a.close()
                    return a
                }
                val sh = pnt()
                sh.color = Color.argb(115, 0, 0, 0)
                sh.maskFilter = BlurMaskFilter(3.2f * k, BlurMaskFilter.Blur.NORMAL)
                c.drawPath(arrowPath(5f, 1f), sh)
                val pt = pnt()
                pt.style = Paint.Style.STROKE
                pt.strokeWidth = 5f * k
                pt.strokeJoin = Paint.Join.ROUND
                pt.color = Color.WHITE
                c.drawPath(arrowPath(2.5f, 1f), pt)
                pt.style = Paint.Style.FILL
                pt.color = shade(color, 0.4f)
                c.drawPath(arrowPath(2.5f, 1f), pt)

                fun half(s: Float, left: Boolean, col: Int) {
                    val h = Path()
                    h.moveTo(50f * k, (50f - 44f * s) * k)
                    val sx = if (left) -1f else 1f
                    h.lineTo((50f + sx * 32f * s) * k, (50f + 40f * s) * k)
                    h.lineTo(50f * k, (50f + 22f * s) * k)
                    h.close()
                    val hp = pnt()
                    hp.color = col
                    c.drawPath(h, hp)
                }
                half(1f, true, mix(color, 0.3f))
                half(1f, false, shade(color, 0.65f))
                // приподнятая площадка
                half(0.6f, true, mix(color, 0.6f))
                half(0.6f, false, mix(color, 0.12f))
                val rl = pnt()
                rl.style = Paint.Style.STROKE
                rl.strokeWidth = 1.6f * k
                rl.color = Color.argb(150, 255, 255, 255)
                c.drawLine(50f * k, 9f * k, 50f * k, 66f * k, rl)
            }
            "moto" -> {
                wheel(46f, 4f, 54f, 24f)
                wheel(45f, 76f, 55f, 96f)
                body(42f, 24f, 58f, 80f, 8f, color)
                flat(26f, 30f, 74f, 35.5f, 2.7f, Color.parseColor("#1C1C1C"))
                flat(23f, 28.5f, 29f, 37f, 2f, Color.parseColor("#3A3A3A"))
                flat(71f, 28.5f, 77f, 37f, 2f, Color.parseColor("#3A3A3A"))
                flat(28f, 24f, 33f, 28.5f, 2f, shade(color, 0.7f))
                flat(67f, 24f, 72f, 28.5f, 2f, shade(color, 0.7f))
                flat(31f, 36f, 38.5f, 52f, 3.5f, Color.parseColor("#37474F"))
                flat(61.5f, 36f, 69f, 52f, 3.5f, Color.parseColor("#37474F"))
                body(36f, 44f, 64f, 67f, 9f, Color.parseColor("#455A64"))
                sphere(50f, 52f, 8.5f, color)
                flat(45.5f, 45.5f, 54.5f, 48.5f, 1.4f, GLASS_BOTTOM)
                light(50f, 12f, 2.6f, head)
                light(50f, 91f, 2.2f, tail)
            }
            "truck" -> {
                wheel(23f, 10f, 30f, 32f)
                wheel(70f, 10f, 77f, 32f)
                wheel(23f, 64f, 30f, 92f)
                wheel(70f, 64f, 77f, 92f)
                body(29f, 40f, 71f, 96f, 4f, shade(color, 0.85f))
                roofRect(31f, 43f, 69f, 93f, 3f, mix(color, 0.08f))
                flat(31f, 55f, 69f, 56.4f, 0.5f, crease)
                flat(31f, 68f, 69f, 69.4f, 0.5f, crease)
                flat(31f, 81f, 69f, 82.4f, 0.5f, crease)
                body(30f, 5f, 70f, 37f, 10f, color)
                glassPoly(poly(33.5f, 13f, 66.5f, 13f, 64f, 26f, 36f, 26f), 13f, 26f)
                roofRect(36f, 26f, 64f, 34f, 3f, color)
                flat(23.5f, 16f, 29f, 24f, 2f, shade(color, 0.7f))
                flat(71f, 16f, 76.5f, 24f, 2f, shade(color, 0.7f))
                light(37f, 9f, 2.8f, head)
                light(63f, 9f, 2.8f, head)
                light(36f, 94f, 2.2f, tail)
                light(64f, 94f, 2.2f, tail)
            }
            "suv" -> {
                wheel(21f, 14f, 29f, 35f)
                wheel(71f, 14f, 79f, 35f)
                wheel(21f, 65f, 29f, 86f)
                wheel(71f, 65f, 79f, 86f)
                body(27f, 5f, 73f, 95f, 13f, color)
                flat(31f, 22.5f, 69f, 24f, 0.7f, crease)
                glassPoly(poly(30.5f, 26f, 69.5f, 26f, 66f, 41f, 34f, 41f), 26f, 41f)
                roofRect(34f, 41f, 66f, 71f, 5f, color)
                flat(36f, 43f, 38.8f, 69f, 1.2f, shade(color, 0.35f))
                flat(61.2f, 43f, 64f, 69f, 1.2f, shade(color, 0.35f))
                glassPoly(poly(34f, 71f, 66f, 71f, 69.5f, 85f, 30.5f, 85f), 71f, 85f)
                flat(21.5f, 28f, 27f, 35f, 2f, shade(color, 0.7f))
                flat(73f, 28f, 78.5f, 35f, 2f, shade(color, 0.7f))
                light(35f, 10f, 3f, head)
                light(65f, 10f, 3f, head)
                light(35f, 91f, 2.4f, tail)
                light(65f, 91f, 2.4f, tail)
            }
            else -> { // sedan
                wheel(24f, 15f, 31f, 34f)
                wheel(69f, 15f, 76f, 34f)
                wheel(24f, 66f, 31f, 85f)
                wheel(69f, 66f, 76f, 85f)
                body(30f, 7f, 70f, 93f, 15f, color)
                flat(33f, 25f, 67f, 26.6f, 0.8f, crease)
                flat(33f, 74.5f, 67f, 76f, 0.8f, crease)
                glassPoly(poly(33f, 28f, 67f, 28f, 63.5f, 42f, 36.5f, 42f), 28f, 42f)
                roofRect(36.5f, 42f, 63.5f, 62f, 5f, color)
                glassPoly(poly(36.5f, 62f, 63.5f, 62f, 67f, 74f, 33f, 74f), 62f, 74f)
                flat(24.5f, 31f, 30.5f, 38f, 2.5f, shade(color, 0.75f))
                flat(69.5f, 31f, 75.5f, 38f, 2.5f, shade(color, 0.75f))
                light(36f, 11f, 3f, head)
                light(64f, 11f, 3f, head)
                light(37f, 89f, 2.4f, tail)
                light(63f, 89f, 2.4f, tail)
            }
        }
        return bmp
    }
}
