package com.drivedeck

/** Язык интерфейса: ru (по умолчанию) или uk. */
object Tr {
    @JvmField var uk: Boolean = false
}

fun tr(ru: String, ukr: String): String = if (Tr.uk) ukr else ru
