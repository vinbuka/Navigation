package com.drivedeck

import android.app.Activity
import android.app.AlertDialog
import android.os.StatFs
import android.widget.Toast
import org.json.JSONObject
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.offline.OfflineManager
import org.maplibre.android.offline.OfflineRegion
import org.maplibre.android.offline.OfflineRegionError
import org.maplibre.android.offline.OfflineRegionStatus
import org.maplibre.android.offline.OfflineTilePyramidRegionDefinition
import java.util.Locale

/**
 * Загрузка ОФЛАЙН-ТАЙЛОВ для отображения карты (кэш MapLibre): вся Украина, области, районы.
 * Это НЕ офлайн-навигация: маршруты и поиск адресов по-прежнему требуют интернета.
 * Границы областей и зоны районов приблизительные.
 */
class OfflineMaps(private val act: Activity, private val styleUrl: String) {

    class Region(
        val key: String, val ru: String, val uk: String,
        val n: Double, val s: Double, val e: Double, val w: Double,
        val minZ: Double, val maxZ: Double
    ) {
        val title: String get() = tr(ru, uk)
        val estMb: Int
            get() = maxOf(1, ((n - s) * (e - w) * 60.0 / Math.pow(4.0, 14.0 - maxZ)).toInt())
    }

    private class Oblast(val ru: String, val uk: String, val regions: List<Region>) {
        val title: String get() = tr(ru, uk)
    }

    private class Info(val region: OfflineRegion, val size: Long, val complete: Boolean)

    private class Rn(val ru: String, val uk: String, val lat: Double, val lon: Double)

    private fun ob(key: String, ru: String, uk: String, s: Double, n: Double, w: Double, e: Double, rs: List<Rn>): Oblast {
        val list = ArrayList<Region>()
        list.add(Region("o:$key:ov", "$ru — обзор", "$uk — огляд", n, s, e, w, 5.0, 12.0))
        list.add(Region("o:$key:full", "$ru — подробно", "$uk — детально", n, s, e, w, 8.0, 14.0))
        for ((i, r) in rs.withIndex()) {
            // зона ~66x66 км вокруг районного центра
            list.add(
                Region(
                    "r:$key:$i", "${r.ru} район", "${r.uk} район",
                    r.lat + 0.30, r.lat - 0.30, r.lon + 0.45, r.lon - 0.45, 8.0, 14.0
                )
            )
        }
        return Oblast(ru, uk, list)
    }

    private val ukraine = listOf(
        Region("ua:ov", "Вся Украина — обзор", "Уся Україна — огляд", 52.4, 44.3, 40.2, 22.1, 5.0, 11.0),
        Region("ua:mid", "Вся Украина — подробнее", "Уся Україна — детальніше", 52.4, 44.3, 40.2, 22.1, 5.0, 13.0)
    )

    private val oblasts: List<Oblast> by lazy {
        listOf(
            ob("vinnytsia", "Винницкая область", "Вінницька область", 48.05, 49.60, 27.20, 29.99, listOf(
                Rn("Винницкий", "Вінницький", 49.23, 28.47), Rn("Гайсинский", "Гайсинський", 48.81, 29.39),
                Rn("Жмеринский", "Жмеринський", 49.04, 28.11), Rn("Могилёв-Подольский", "Могилів-Подільський", 48.45, 27.80),
                Rn("Тульчинский", "Тульчинський", 48.68, 28.85), Rn("Хмельникский", "Хмільницький", 49.55, 27.96))),
            ob("volyn", "Волынская область", "Волинська область", 50.30, 51.95, 23.55, 25.75, listOf(
                Rn("Ковельский", "Ковельський", 51.22, 24.71), Rn("Луцкий", "Луцький", 50.75, 25.34),
                Rn("Владимир-Волынский", "Володимир-Волинський", 50.85, 24.32), Rn("Камень-Каширский", "Камінь-Каширський", 51.62, 24.97))),
            ob("dnipro", "Днепропетровская область", "Дніпропетровська область", 47.00, 49.15, 33.30, 36.70, listOf(
                Rn("Днепровский", "Дніпровський", 48.46, 35.05), Rn("Каменский", "Кам'янський", 48.51, 34.60),
                Rn("Криворожский", "Криворізький", 47.91, 33.39), Rn("Никопольский", "Нікопольський", 47.57, 34.40),
                Rn("Павлоградский", "Павлоградський", 48.53, 35.87), Rn("Самарский", "Самарівський", 48.63, 35.26),
                Rn("Синельниковский", "Синельниківський", 47.96, 35.51))),
            ob("donetsk", "Донецкая область", "Донецька область", 47.05, 49.30, 36.55, 39.10, emptyList()),
            ob("zhytomyr", "Житомирская область", "Житомирська область", 49.90, 51.75, 27.05, 29.95, listOf(
                Rn("Бердичевский", "Бердичівський", 49.90, 28.60), Rn("Житомирский", "Житомирський", 50.25, 28.66),
                Rn("Коростенский", "Коростенський", 50.95, 28.64), Rn("Новоград-Волынский", "Новоград-Волинський", 50.59, 27.62))),
            ob("zakarpattia", "Закарпатская область", "Закарпатська область", 47.90, 49.10, 22.10, 24.65, listOf(
                Rn("Берегский", "Берегівський", 48.20, 22.65), Rn("Мукачевский", "Мукачівський", 48.44, 22.72),
                Rn("Раховский", "Рахівський", 48.05, 24.20), Rn("Тячевский", "Тячівський", 47.91, 23.57),
                Rn("Ужгородский", "Ужгородський", 48.62, 22.30), Rn("Хустский", "Хустський", 48.17, 23.30))),
            ob("zaporizhzhia", "Запорожская область", "Запорізька область", 46.45, 48.20, 34.20, 37.30, listOf(
                Rn("Бердянский", "Бердянський", 46.76, 36.80), Rn("Васильевский", "Василівський", 47.44, 35.28),
                Rn("Запорожский", "Запорізький", 47.84, 35.14), Rn("Мелитопольский", "Мелітопольський", 46.84, 35.37),
                Rn("Пологовский", "Пологівський", 47.48, 36.25))),
            ob("ivano-frankivsk", "Ивано-Франковская область", "Івано-Франківська область", 48.30, 49.45, 23.70, 25.70, listOf(
                Rn("Верховинский", "Верховинський", 48.15, 24.82), Rn("Ивано-Франковский", "Івано-Франківський", 48.92, 24.71),
                Rn("Калушский", "Калуський", 49.05, 24.37), Rn("Коломыйский", "Коломийський", 48.53, 25.04),
                Rn("Косовский", "Косівський", 48.31, 25.09), Rn("Надворнянский", "Надвірнянський", 48.63, 24.57))),
            ob("kyiv", "Киевская область", "Київська область", 49.05, 51.50, 29.15, 32.25, listOf(
                Rn("Белоцерковский", "Білоцерківський", 49.80, 30.12), Rn("Бориспольский", "Бориспільський", 50.35, 30.95),
                Rn("Броварской", "Броварський", 50.51, 30.79), Rn("Бучанский", "Бучанський", 50.55, 30.22),
                Rn("Вышгородский", "Вишгородський", 50.58, 30.49), Rn("Обуховский", "Обухівський", 50.11, 30.62),
                Rn("Фастовский", "Фастівський", 50.08, 29.92))),
            ob("kyiv-city", "Киев (город)", "Київ (місто)", 50.20, 50.65, 30.20, 30.85, emptyList()),
            ob("kirovohrad", "Кировоградская область", "Кіровоградська область", 47.75, 49.35, 30.80, 33.60, listOf(
                Rn("Александрийский", "Олександрійський", 48.67, 33.12), Rn("Голованевский", "Голованівський", 48.38, 30.52),
                Rn("Кропивницкий", "Кропивницький", 48.51, 32.26), Rn("Новоукраинский", "Новоукраїнський", 48.31, 31.52))),
            ob("luhansk", "Луганская область", "Луганська область", 48.05, 50.15, 37.75, 40.20, emptyList()),
            ob("lviv", "Львовская область", "Львівська область", 48.85, 50.45, 22.80, 25.25, listOf(
                Rn("Дрогобычский", "Дрогобицький", 49.35, 23.51), Rn("Золочевский", "Золочівський", 49.80, 24.90),
                Rn("Львовский", "Львівський", 49.84, 24.03), Rn("Самборский", "Самбірський", 49.52, 23.20),
                Rn("Стрыйский", "Стрийський", 49.26, 23.85), Rn("Червоноградский", "Червоноградський", 50.38, 24.23),
                Rn("Яворовский", "Яворівський", 49.94, 23.38))),
            ob("mykolaiv", "Николаевская область", "Миколаївська область", 46.30, 48.20, 30.60, 33.30, listOf(
                Rn("Баштанский", "Баштанський", 47.40, 32.44), Rn("Вознесенский", "Вознесенський", 47.57, 31.33),
                Rn("Николаевский", "Миколаївський", 46.97, 32.00), Rn("Первомайский", "Первомайський", 48.04, 30.85))),
            ob("odesa", "Одесская область", "Одеська область", 45.20, 48.25, 28.60, 31.85, listOf(
                Rn("Белгород-Днестровский", "Білгород-Дністровський", 46.19, 30.34), Rn("Березовский", "Березівський", 47.21, 30.91),
                Rn("Болградский", "Болградський", 45.69, 28.61), Rn("Измаильский", "Ізмаїльський", 45.35, 28.84),
                Rn("Одесский", "Одеський", 46.48, 30.73), Rn("Подольский", "Подільський", 47.75, 29.53),
                Rn("Раздельнянский", "Роздільнянський", 46.84, 30.08))),
            ob("poltava", "Полтавская область", "Полтавська область", 48.65, 50.70, 31.35, 35.35, listOf(
                Rn("Кременчугский", "Кременчуцький", 49.07, 33.42), Rn("Лубенский", "Лубенський", 50.02, 32.99),
                Rn("Миргородский", "Миргородський", 49.97, 33.61), Rn("Полтавский", "Полтавський", 49.59, 34.55))),
            ob("rivne", "Ровенская область", "Рівненська область", 50.15, 51.95, 25.30, 27.95, listOf(
                Rn("Дубенский", "Дубенський", 50.40, 25.75), Rn("Ровенский", "Рівненський", 50.62, 26.25),
                Rn("Сарненский", "Сарненський", 51.34, 26.60), Rn("Вараш", "Вараський", 51.35, 25.85))),
            ob("sumy", "Сумская область", "Сумська область", 50.10, 52.35, 32.65, 35.55, listOf(
                Rn("Конотопский", "Конотопський", 51.24, 33.20), Rn("Роменский", "Роменський", 50.75, 33.47),
                Rn("Сумский", "Сумський", 50.91, 34.80), Rn("Шосткинский", "Шосткинський", 51.87, 33.48),
                Rn("Ахтырский", "Охтирський", 50.31, 34.90))),
            ob("ternopil", "Тернопольская область", "Тернопільська область", 48.50, 50.30, 24.60, 26.60, listOf(
                Rn("Кременецкий", "Кременецький", 50.10, 25.73), Rn("Тернопольский", "Тернопільський", 49.55, 25.59),
                Rn("Чортковский", "Чортківський", 49.02, 25.80))),
            ob("kharkiv", "Харьковская область", "Харківська область", 48.60, 50.50, 34.85, 38.15, listOf(
                Rn("Берестинский", "Берестинський", 49.37, 35.45), Rn("Богодуховский", "Богодухівський", 50.16, 35.52),
                Rn("Изюмский", "Ізюмський", 49.21, 37.27), Rn("Купянский", "Куп'янський", 49.71, 37.62),
                Rn("Лозовской", "Лозівський", 48.89, 36.32), Rn("Харьковский", "Харківський", 49.99, 36.23),
                Rn("Чугуевский", "Чугуївський", 49.84, 36.69))),
            ob("kherson", "Херсонская область", "Херсонська область", 45.35, 47.35, 32.15, 35.20, listOf(
                Rn("Бериславский", "Бериславський", 46.84, 33.43), Rn("Геническский", "Генічеський", 46.17, 34.80),
                Rn("Каховский", "Каховський", 46.81, 33.49), Rn("Скадовский", "Скадовський", 46.12, 32.91),
                Rn("Херсонский", "Херсонський", 46.64, 32.62))),
            ob("khmelnytskyi", "Хмельницкая область", "Хмельницька область", 48.40, 50.65, 25.90, 27.95, listOf(
                Rn("Каменец-Подольский", "Кам'янець-Подільський", 48.68, 26.58), Rn("Хмельницкий", "Хмельницький", 49.42, 26.98),
                Rn("Шепетовский", "Шепетівський", 50.18, 27.06))),
            ob("cherkasy", "Черкасская область", "Черкаська область", 48.55, 50.10, 29.25, 32.50, listOf(
                Rn("Звенигородский", "Звенигородський", 49.08, 30.96), Rn("Каневский", "Канівський", 49.75, 31.47),
                Rn("Уманский", "Уманський", 48.75, 30.22), Rn("Черкасский", "Черкаський", 49.44, 32.06))),
            ob("chernivtsi", "Черновицкая область", "Чернівецька область", 47.70, 48.65, 24.60, 27.55, listOf(
                Rn("Вижницкий", "Вижницький", 48.25, 25.19), Rn("Днестровский", "Дністровський", 48.58, 27.43),
                Rn("Черновицкий", "Чернівецький", 48.29, 25.94))),
            ob("chernihiv", "Черниговская область", "Чернігівська область", 50.25, 52.40, 30.20, 33.55, listOf(
                Rn("Корюковский", "Корюківський", 51.77, 32.25), Rn("Нежинский", "Ніжинський", 51.05, 31.89),
                Rn("Новгород-Северский", "Новгород-Сіверський", 51.99, 33.26), Rn("Прилукский", "Прилуцький", 50.59, 32.39),
                Rn("Черниговский", "Чернігівський", 51.50, 31.30))),
            ob("crimea", "Автономная Республика Крым", "Автономна Республіка Крим", 44.35, 46.20, 32.45, 36.65, emptyList())
        )
    }

    private val mgr: OfflineManager by lazy { OfflineManager.getInstance(act) }

    private fun toast(s: String) = Toast.makeText(act, s, Toast.LENGTH_LONG).show()
    private fun mb(bytes: Long) = String.format(Locale.US, "%.0f МБ", bytes / 1048576.0)

    private fun keyOf(r: OfflineRegion): String =
        try { JSONObject(String(r.metadata)).optString("key") } catch (e: Exception) { "" }

    fun show() {
        mgr.listOfflineRegions(object : OfflineManager.ListOfflineRegionsCallback {
            override fun onList(offlineRegions: Array<OfflineRegion>?) {
                loadInfo(offlineRegions?.toList() ?: emptyList())
            }
            override fun onError(error: String) {
                toast(tr("Ошибка списка карт: ", "Помилка списку карт: ") + error)
            }
        })
    }

    private fun loadInfo(list: List<OfflineRegion>) {
        val infos = HashMap<String, Info>()
        if (list.isEmpty()) {
            showTop(infos)
            return
        }
        var left = list.size
        for (r in list) {
            r.getStatus(object : OfflineRegion.OfflineRegionStatusCallback {
                override fun onStatus(status: OfflineRegionStatus?) {
                    infos[keyOf(r)] = Info(r, status?.completedResourceSize ?: 0L, status?.isComplete ?: false)
                    if (--left == 0) showTop(infos)
                }
                override fun onError(error: String?) {
                    if (--left == 0) showTop(infos)
                }
            })
        }
    }

    private fun showTop(infos: Map<String, Info>) {
        val labels = ArrayList<String>()
        labels.add("🇺🇦  " + tr("Вся Украина", "Уся Україна"))
        for (o in oblasts) {
            val cnt = o.regions.count { infos[it.key]?.complete == true }
            labels.add(o.title + if (cnt > 0) "   ✓ $cnt" else "")
        }
        AlertDialog.Builder(act)
            .setTitle(tr("Карты для офлайна", "Карти для офлайну"))
            .setItems(labels.toTypedArray()) { _, i ->
                if (i == 0) {
                    showRegions(tr("Вся Украина", "Уся Україна"), ukraine, infos)
                } else {
                    val o = oblasts[i - 1]
                    showRegions(o.title, o.regions, infos)
                }
            }
            .setNegativeButton(tr("Закрыть", "Закрити"), null)
            .show()
    }

    private fun showRegions(title: String, regions: List<Region>, infos: Map<String, Info>) {
        val items = regions.map { reg ->
            val i = infos[reg.key]
            val st = when {
                i == null -> tr("не загружена · ≈", "не завантажена · ≈") + reg.estMb + " " + tr("МБ (оценка)", "МБ (оцінка)")
                i.complete -> tr("загружена · ", "завантажена · ") + mb(i.size)
                else -> tr("не завершена · ", "не завершена · ") + mb(i.size)
            }
            reg.title + "\n" + st
        }.toTypedArray()
        AlertDialog.Builder(act)
            .setTitle(title)
            .setItems(items) { _, idx ->
                val reg = regions[idx]
                val info = infos[reg.key]
                if (info == null) confirmDownload(reg) else actions(reg, info)
            }
            .setNegativeButton(tr("Назад", "Назад")) { _, _ -> show() }
            .show()
    }

    private fun actions(reg: Region, info: Info) {
        val items = if (info.complete) {
            arrayOf(tr("Обновить (скачать заново)", "Оновити (завантажити знову)"), tr("Удалить", "Видалити"))
        } else {
            arrayOf(tr("Продолжить загрузку", "Продовжити завантаження"), tr("Удалить", "Видалити"))
        }
        AlertDialog.Builder(act)
            .setTitle(reg.title)
            .setItems(items) { _, i ->
                if (i == 0) {
                    if (info.complete) delete(info.region) { doDownload(reg) } else observe(info.region, reg)
                } else {
                    delete(info.region) { toast(tr("Карта удалена", "Карту видалено")) }
                }
            }
            .show()
    }

    private fun delete(r: OfflineRegion, then: () -> Unit) {
        r.delete(object : OfflineRegion.OfflineRegionDeleteCallback {
            override fun onDelete() { then() }
            override fun onError(error: String) {
                toast(tr("Не удалось удалить: ", "Не вдалося видалити: ") + error)
            }
        })
    }

    private fun confirmDownload(reg: Region) {
        val free = StatFs(act.filesDir.path).availableBytes
        val need = reg.estMb.toLong() * 1048576L * 3 / 2
        if (free < need) {
            toast(
                tr("Недостаточно места: свободно ", "Недостатньо місця: вільно ") + mb(free) +
                    tr(", нужно примерно ", ", потрібно приблизно ") + mb(need)
            )
            return
        }
        AlertDialog.Builder(act)
            .setTitle(reg.title)
            .setMessage(
                tr("Размер ≈", "Розмір ≈") + reg.estMb + " " +
                    tr("МБ (оценка, точный размер будет виден после загрузки).\nСвободно: ",
                        "МБ (оцінка, точний розмір буде видно після завантаження).\nВільно: ") +
                    mb(free) + tr(".\nСкачать?", ".\nЗавантажити?")
            )
            .setPositiveButton(tr("Скачать", "Завантажити")) { _, _ -> doDownload(reg) }
            .setNegativeButton(tr("Отмена", "Скасувати"), null)
            .show()
    }

    private fun doDownload(reg: Region) {
        val def = OfflineTilePyramidRegionDefinition(
            styleUrl,
            LatLngBounds.from(reg.n, reg.e, reg.s, reg.w),
            reg.minZ, reg.maxZ,
            act.resources.displayMetrics.density
        )
        val meta = JSONObject().put("key", reg.key).toString().toByteArray()
        mgr.createOfflineRegion(def, meta, object : OfflineManager.CreateOfflineRegionCallback {
            override fun onCreate(offlineRegion: OfflineRegion) {
                observe(offlineRegion, reg)
            }
            override fun onError(error: String) {
                toast(tr("Не удалось начать загрузку: ", "Не вдалося почати завантаження: ") + error)
            }
        })
    }

    private fun observe(region: OfflineRegion, reg: Region) {
        val dlg = AlertDialog.Builder(act)
            .setTitle(reg.title)
            .setMessage(tr("Подготовка…", "Підготовка…"))
            .setCancelable(false)
            .setNegativeButton(tr("Пауза", "Пауза")) { _, _ -> region.setDownloadState(OfflineRegion.STATE_INACTIVE) }
            .create()
        dlg.show()
        region.setObserver(object : OfflineRegion.OfflineRegionObserver {
            override fun onStatusChanged(status: OfflineRegionStatus) {
                val st = status
                val total = st.requiredResourceCount
                val done = st.completedResourceCount
                val pct = if (total > 0) (done * 100 / total).toInt() else 0
                dlg.setMessage("$pct% · ${mb(st.completedResourceSize)}\n" + tr("файлов: ", "файлів: ") + "$done / $total")
                if (st.isComplete) {
                    dlg.dismiss()
                    region.setDownloadState(OfflineRegion.STATE_INACTIVE)
                    toast(tr("Карта загружена: ", "Карту завантажено: ") + mb(st.completedResourceSize))
                }
            }
            override fun onError(error: OfflineRegionError) {
                dlg.setMessage(tr("Ошибка загрузки: ", "Помилка завантаження: ") + error.message)
            }
            override fun mapboxTileCountLimitExceeded(limit: Long) {
                dlg.setMessage(tr("Превышен лимит тайлов: ", "Перевищено ліміт тайлів: ") + limit)
            }
        })
        region.setDownloadState(OfflineRegion.STATE_ACTIVE)
    }
}
