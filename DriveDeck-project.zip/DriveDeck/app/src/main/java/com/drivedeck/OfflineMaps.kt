package com.drivedeck

import android.app.Activity
import android.app.AlertDialog
import android.os.StatFs
import android.widget.Toast
import org.json.JSONObject
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.offline.OfflineManager
import org.maplibre.android.offline.OfflineRegion
import org.maplibre.android.offline.OfflineRegionError
import org.maplibre.android.offline.OfflineRegionStatus
import org.maplibre.android.offline.OfflineTilePyramidRegionDefinition
import java.util.Locale

/**
 * Загрузка ОФЛАЙН-ТАЙЛОВ для отображения карты (кэш MapLibre).
 * Это НЕ офлайн-навигация: маршруты и поиск по-прежнему требуют интернета.
 */
class OfflineMaps(private val act: Activity, private val styleUrl: String) {

    /** Зона ~66x66 км вокруг центра района (границы приблизительные). */
    class Region(val key: String, val title: String, lat: Double, lon: Double) {
        val n = lat + 0.30
        val s = lat - 0.30
        val e = lon + 0.45
        val w = lon - 0.45
        val estMb: Int get() = ((n - s) * (e - w) * 60).toInt()
    }

    private class Info(val region: OfflineRegion, val size: Long, val complete: Boolean)

    private val regions = listOf(
        Region("vinnytsia", "Винницкий район (с Винницей)", 49.23, 28.47),
        Region("zhmerynka", "Жмеринский район", 49.04, 28.11),
        Region("haisyn", "Гайсинский район", 48.81, 29.39),
        Region("tulchyn", "Тульчинский район", 48.68, 28.85),
        Region("mohyliv", "Могилёв-Подольский район", 48.45, 27.80),
        Region("khmilnyk", "Хмельникский район", 49.55, 27.96),
        Region("kyiv", "Киев и окрестности", 50.45, 30.52),
        Region("lviv", "Львов и окрестности", 49.84, 24.03),
        Region("odesa", "Одесса и окрестности", 46.48, 30.73)
    )

    private val mgr: OfflineManager by lazy { OfflineManager.getInstance(act) }

    private fun toast(s: String) = Toast.makeText(act, s, Toast.LENGTH_LONG).show()
    private fun mb(bytes: Long) = String.format(Locale.US, "%.0f МБ", bytes / 1048576.0)

    private fun keyOf(r: OfflineRegion): String =
        try { JSONObject(String(r.metadata)).optString("key") } catch (e: Exception) { "" }

    fun show() {
        mgr.listOfflineRegions(object : OfflineManager.ListOfflineRegionsCallback {
            override fun onList(offlineRegions: Array<OfflineRegion>?) {
                loadInfo(offlineRegions?.toList() ?: emptyList())
            }
            override fun onError(error: String) {
                toast("Ошибка списка карт: $error")
            }
        })
    }

    private fun loadInfo(list: List<OfflineRegion>) {
        val infos = HashMap<String, Info>()
        if (list.isEmpty()) {
            showList(infos)
            return
        }
        var left = list.size
        for (r in list) {
            r.getStatus(object : OfflineRegion.OfflineRegionStatusCallback {
                override fun onStatus(status: OfflineRegionStatus?) {
                    infos[keyOf(r)] = Info(r, status?.completedResourceSize ?: 0L, status?.isComplete ?: false)
                    if (--left == 0) showList(infos)
                }
                override fun onError(error: String?) {
                    if (--left == 0) showList(infos)
                }
            })
        }
    }

    private fun showList(infos: Map<String, Info>) {
        val items = regions.map { reg ->
            val i = infos[reg.key]
            val st = when {
                i == null -> "не загружена · ≈${reg.estMb} МБ (оценка)"
                i.complete -> "загружена · ${mb(i.size)}"
                else -> "не завершена · ${mb(i.size)}"
            }
            reg.title + "\n" + st
        }.toTypedArray()
        AlertDialog.Builder(act, R.style.BigDialog)
            .setTitle("Карты для офлайна")
            .setItems(items) { _, idx ->
                val reg = regions[idx]
                val info = infos[reg.key]
                if (info == null) confirmDownload(reg) else actions(reg, info)
            }
            .setNegativeButton("Закрыть", null)
            .show()
    }

    private fun actions(reg: Region, info: Info) {
        val items = if (info.complete) arrayOf("Обновить (скачать заново)", "Удалить")
        else arrayOf("Продолжить загрузку", "Удалить")
        AlertDialog.Builder(act, R.style.BigDialog)
            .setTitle(reg.title)
            .setItems(items) { _, i ->
                if (i == 0) {
                    if (info.complete) delete(info.region) { doDownload(reg) } else observe(info.region, reg)
                } else {
                    delete(info.region) { toast("Карта удалена") }
                }
            }
            .show()
    }

    private fun delete(r: OfflineRegion, then: () -> Unit) {
        r.delete(object : OfflineRegion.OfflineRegionDeleteCallback {
            override fun onDelete() { then() }
            override fun onError(error: String) { toast("Не удалось удалить: $error") }
        })
    }

    private fun confirmDownload(reg: Region) {
        val free = StatFs(act.filesDir.path).availableBytes
        val need = reg.estMb.toLong() * 1048576L * 3 / 2
        if (free < need) {
            toast("Недостаточно места: свободно ${mb(free)}, нужно примерно ${mb(need)}")
            return
        }
        AlertDialog.Builder(act, R.style.BigDialog)
            .setTitle(reg.title)
            .setMessage("Размер ≈${reg.estMb} МБ (оценка, точный размер будет виден после загрузки).\nСвободно: ${mb(free)}.\nСкачать?")
            .setPositiveButton("Скачать") { _, _ -> doDownload(reg) }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun doDownload(reg: Region) {
        val def = OfflineTilePyramidRegionDefinition(
            styleUrl,
            LatLngBounds.from(reg.n, reg.e, reg.s, reg.w),
            8.0, 14.0,
            act.resources.displayMetrics.density
        )
        val meta = JSONObject().put("key", reg.key).toString().toByteArray()
        mgr.createOfflineRegion(def, meta, object : OfflineManager.CreateOfflineRegionCallback {
            override fun onCreate(offlineRegion: OfflineRegion) {
                observe(offlineRegion, reg)
            }
            override fun onError(error: String) {
                toast("Не удалось начать загрузку: $error")
            }
        })
    }

    private fun observe(region: OfflineRegion, reg: Region) {
        val dlg = AlertDialog.Builder(act, R.style.BigDialog)
            .setTitle(reg.title)
            .setMessage("Подготовка…")
            .setCancelable(false)
            .setNegativeButton("Пауза") { _, _ -> region.setDownloadState(OfflineRegion.STATE_INACTIVE) }
            .create()
        dlg.show()
        region.setObserver(object : OfflineRegion.OfflineRegionObserver {
            override fun onStatusChanged(status: OfflineRegionStatus) {
                val st = status
                val total = st.requiredResourceCount
                val done = st.completedResourceCount
                val pct = if (total > 0) (done * 100 / total).toInt() else 0
                dlg.setMessage("$pct% · ${mb(st.completedResourceSize)}\nфайлов: $done из $total")
                if (st.isComplete) {
                    dlg.dismiss()
                    region.setDownloadState(OfflineRegion.STATE_INACTIVE)
                    toast("Карта загружена: ${mb(st.completedResourceSize)}")
                }
            }
            override fun onError(error: OfflineRegionError) {
                dlg.setMessage("Ошибка загрузки: ${error.message}")
            }
            override fun mapboxTileCountLimitExceeded(limit: Long) {
                dlg.setMessage("Превышен лимит тайлов: $limit")
            }
        })
        region.setDownloadState(OfflineRegion.STATE_ACTIVE)
    }
}
