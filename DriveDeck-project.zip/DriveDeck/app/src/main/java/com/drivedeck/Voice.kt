package com.drivedeck

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Голос: сначала Google TTS, если его нет — системный движок по умолчанию. */
class Voice(private val ctx: Context, initialLang: String, private val onProblem: (String) -> Unit) {
    private var tts: TextToSpeech? = null
    private var ready = false

    var lang: String = initialLang
        set(v) {
            field = v
            if (ready) applyLang()
        }

    init {
        create("com.google.android.tts")
    }

    private fun create(engine: String?) {
        tts = TextToSpeech(ctx, TextToSpeech.OnInitListener { status ->
            if (status == TextToSpeech.SUCCESS) {
                ready = true
                applyLang()
            } else if (engine != null) {
                tts?.shutdown()
                create(null)
            } else {
                onProblem("Не найден системный движок синтеза речи")
            }
        }, engine)
    }

    private fun applyLang() {
        val loc = if (lang == "uk") Locale("uk", "UA") else Locale("ru", "RU")
        val r = tts?.setLanguage(loc)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            onProblem("Голос для выбранного языка не установлен в Google TTS")
        }
    }

    fun speak(text: String) {
        if (ready) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "drivedeck")
    }

    fun shutdown() {
        tts?.shutdown()
    }
}
