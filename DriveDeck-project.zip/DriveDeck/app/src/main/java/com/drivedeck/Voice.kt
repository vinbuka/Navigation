package com.drivedeck

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Голос: сначала Google TTS, если его нет — системный движок.
 * Пока звучит подсказка, запрашивается аудиофокус с приглушением (ducking):
 * музыка становится тише, затем громкость возвращается.
 */
class Voice(private val ctx: Context, initialLang: String, private val onProblem: (String) -> Unit) {
    private var tts: TextToSpeech? = null
    private var ready = false

    private val audio: AudioManager = ctx.getSystemService(AudioManager::class.java)
    private val attrs: AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
        .build()
    private val focusRequest: AudioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
        .setAudioAttributes(attrs)
        .setOnAudioFocusChangeListener { }
        .build()

    var lang: String = initialLang
        set(v) {
            field = v
            if (ready) applyLang()
        }

    init {
        create("com.google.android.tts")
    }

    private fun create(engine: String?) {
        tts = TextToSpeech(ctx, TextToSpeech.OnInitListener { status ->
            if (status == TextToSpeech.SUCCESS) {
                ready = true
                tts?.setAudioAttributes(attrs)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { releaseFocus() }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { releaseFocus() }
                })
                applyLang()
            } else if (engine != null) {
                tts?.shutdown()
                create(null)
            } else {
                onProblem(tr("Не найден системный движок синтеза речи", "Не знайдено системний рушій синтезу мовлення"))
            }
        }, engine)
    }

    private fun applyLang() {
        val loc = if (lang == "uk") Locale("uk", "UA") else Locale("ru", "RU")
        val r = tts?.setLanguage(loc)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            onProblem(tr("Голос для выбранного языка не установлен в Google TTS", "Голос для вибраної мови не встановлено в Google TTS"))
        }
    }

    private fun releaseFocus() {
        try { audio.abandonAudioFocusRequest(focusRequest) } catch (_: Exception) {}
    }

    fun speak(text: String) {
        if (!ready) return
        try { audio.requestAudioFocus(focusRequest) } catch (_: Exception) {}
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "drivedeck")
    }

    fun shutdown() {
        releaseFocus()
        tts?.shutdown()
    }
}
