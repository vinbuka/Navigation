package com.drivedeck

import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.cos
import kotlin.math.sin

/**
 * Объёмная машинка для наклонной карты: набор «коробок» (fill-extrusion) с высотой.
 * Единицы деталей — доли длины машины; y вперёд, x вправо.
 */
object Car3D {
    private class Part(
        val pts: List<DoubleArray>, val base: Double, val h: Double, val kind: Int,
        val hole: List<DoubleArray>? = null
    )

    // kind: 0 цвет кузова, 1 тёмный кузов, 2 стекло, 3 шины, 4 светлая крыша, 5 чёрный,
    //       8 фара, 9 задний фонарь, 10 салон
    private fun rect(x1: Double, y1: Double, x2: Double, y2: Double) = listOf(
        doubleArrayOf(x1, y1), doubleArrayOf(x2, y1), doubleArrayOf(x2, y2), doubleArrayOf(x1, y2)
    )

    private fun body(hw: Double, hl: Double, c: Double) = listOf(
        doubleArrayOf(-hw + c, -hl), doubleArrayOf(hw - c, -hl), doubleArrayOf(hw, -hl + c),
        doubleArrayOf(hw, hl - c), doubleArrayOf(hw - c, hl), doubleArrayOf(-hw + c, hl),
        doubleArrayOf(-hw, hl - c), doubleArrayOf(-hw, -hl + c)
    )

    private fun wheels(x1: Double, x2: Double, yFront: Double, yRear: Double, len: Double): List<Part> = listOf(
        Part(rect(x1, yFront, x2, yFront + len), 0.0, 0.07, 3),
        Part(rect(-x2, yFront, -x1, yFront + len), 0.0, 0.07, 3),
        Part(rect(x1, yRear, x2, yRear + len), 0.0, 0.07, 3),
        Part(rect(-x2, yRear, -x1, yRear + len), 0.0, 0.07, 3)
    )

    private fun lights(hw: Double, hl: Double, w: Double, base: Double, top: Double): List<Part> = listOf(
        Part(rect(-hw, hl - 0.03, -hw + w, hl), base, top, 8),
        Part(rect(hw - w, hl - 0.03, hw, hl), base, top, 8),
        Part(rect(-hw, -hl, -hw + w, -hl + 0.03), base, top, 9),
        Part(rect(hw - w, -hl, hw, -hl + 0.03), base, top, 9)
    )

    private fun arrow(s: Double) = listOf(
        doubleArrayOf(0.0, 0.5 * s), doubleArrayOf(0.3 * s, -0.5 * s),
        doubleArrayOf(0.0, -0.3 * s), doubleArrayOf(-0.3 * s, -0.5 * s)
    )

    private fun parts(type: String): List<Part> = when (type) {
        "suv" -> wheels(0.19, 0.25, 0.2, -0.36, 0.16) + listOf(
            Part(body(0.22, 0.5, 0.08), 0.05, 0.19, 0),
            Part(rect(-0.18, -0.36, 0.18, 0.16), 0.19, 0.32, 2),
            Part(rect(-0.17, -0.32, 0.17, 0.12), 0.32, 0.35, 4),
            Part(rect(-0.16, -0.3, -0.13, 0.08), 0.35, 0.37, 1),
            Part(rect(0.13, -0.3, 0.16, 0.08), 0.35, 0.37, 1),
            Part(rect(-0.26, 0.1, -0.22, 0.16), 0.2, 0.25, 0),
            Part(rect(0.22, 0.1, 0.26, 0.16), 0.2, 0.25, 0)
        ) + lights(0.2, 0.5, 0.09, 0.1, 0.16)
        "truck" -> wheels(0.17, 0.23, 0.28, -0.42, 0.14) + listOf(
            Part(rect(-0.19, -0.5, 0.19, 0.5), 0.05, 0.1, 1),
            Part(rect(-0.2, -0.5, 0.2, 0.08), 0.1, 0.38, 1),
            Part(rect(-0.18, -0.47, 0.18, 0.05), 0.38, 0.4, 4),
            Part(rect(-0.19, 0.12, 0.19, 0.5), 0.1, 0.2, 0),
            Part(rect(-0.17, 0.14, 0.17, 0.46), 0.2, 0.31, 2),
            Part(rect(-0.16, 0.16, 0.16, 0.3), 0.31, 0.335, 4),
            Part(rect(-0.23, 0.3, -0.19, 0.36), 0.2, 0.25, 0),
            Part(rect(0.19, 0.3, 0.23, 0.36), 0.2, 0.25, 0)
        ) + lights(0.19, 0.5, 0.08, 0.12, 0.17)
        "moto" -> listOf(
            Part(rect(-0.025, 0.3, 0.025, 0.5), 0.0, 0.1, 3),
            Part(rect(-0.03, -0.5, 0.03, -0.3), 0.0, 0.1, 3),
            Part(rect(-0.05, -0.3, 0.05, 0.3), 0.08, 0.2, 0),
            Part(rect(-0.045, -0.25, 0.045, -0.05), 0.2, 0.24, 5),
            Part(rect(-0.075, -0.12, 0.075, 0.08), 0.2, 0.38, 1),
            Part(rect(-0.05, -0.02, 0.05, 0.1), 0.38, 0.46, 0),
            Part(rect(-0.04, 0.07, 0.04, 0.11), 0.4, 0.44, 2),
            Part(rect(-0.2, 0.18, 0.2, 0.21), 0.22, 0.25, 5),
            Part(rect(-0.025, 0.47, 0.025, 0.5), 0.1, 0.14, 8)
        )
        "arrow" -> listOf(
            Part(arrow(1.0), 0.0, 0.06, 1),
            Part(arrow(0.8), 0.06, 0.11, 0),
            Part(arrow(0.55), 0.11, 0.15, 4)
        )
        "bears" -> wheels(0.41, 0.49, 0.1, -0.32, 0.22) + listOf(
            // борт кабриолета: стенки с вырезом под салон
            Part(body(0.45, 0.42, 0.12), 0.04, 0.18, 0, rect(-0.36, -0.32, 0.36, 0.26)),
            Part(rect(-0.36, -0.32, 0.36, 0.26), 0.04, 0.08, 10),
            Part(rect(-0.33, -0.27, -0.02, 0.1), 0.08, 0.17, 1),
            Part(rect(0.02, -0.27, 0.33, 0.1), 0.08, 0.17, 1),
            Part(rect(-0.36, 0.26, 0.36, 0.3), 0.18, 0.26, 2)
        ) + lights(0.4, 0.42, 0.1, 0.1, 0.16)
        else -> wheels(0.17, 0.23, 0.2, -0.34, 0.14) + listOf(
            Part(body(0.2, 0.5, 0.07), 0.04, 0.15, 0),
            Part(rect(-0.16, -0.3, 0.16, 0.1), 0.15, 0.26, 2),
            Part(rect(-0.15, -0.22, 0.15, 0.02), 0.26, 0.285, 4),
            Part(rect(-0.235, 0.06, -0.2, 0.11), 0.15, 0.19, 0),
            Part(rect(0.2, 0.06, 0.235, 0.11), 0.15, 0.19, 0)
        ) + lights(0.17, 0.5, 0.08, 0.09, 0.13)
    }

    private fun shade(c: Int, f: Float) =
        Color.rgb((Color.red(c) * f).toInt(), (Color.green(c) * f).toInt(), (Color.blue(c) * f).toInt())

    private fun mix(c: Int, w: Float) = Color.rgb(
        (Color.red(c) + (255 - Color.red(c)) * w).toInt(),
        (Color.green(c) + (255 - Color.green(c)) * w).toInt(),
        (Color.blue(c) + (255 - Color.blue(c)) * w).toInt()
    )

    private fun kindColor(kind: Int, car: Int): String {
        val c = when (kind) {
            1 -> shade(car, 0.6f)
            2 -> Color.parseColor("#263238")
            3 -> Color.parseColor("#111111")
            4 -> mix(car, 0.3f)
            5 -> Color.parseColor("#1B1B1B")
            8 -> Color.parseColor("#FFF59D")
            9 -> Color.parseColor("#FF5252")
            10 -> Color.parseColor("#3A2F2A")
            else -> car
        }
        return String.format("#%06X", c and 0xFFFFFF)
    }

    /** lengthM — длина машины в метрах на местности (подбирается по масштабу карты). */
    fun geoJson(type: String, color: Int, lat: Double, lon: Double, headingDeg: Double, lengthM: Double): String {
        val th = Math.toRadians(headingDeg)
        val sinT = sin(th)
        val cosT = cos(th)
        val mLat = 111320.0
        val mLon = 111320.0 * cos(Math.toRadians(lat))

        fun ring(pts: List<DoubleArray>, reverse: Boolean): JSONArray {
            val list = if (reverse) pts.reversed() else pts
            val r = JSONArray()
            for (i in 0..list.size) {
                val q = list[i % list.size]
                val x = q[0] * lengthM
                val y = q[1] * lengthM
                val east = x * cosT + y * sinT
                val north = -x * sinT + y * cosT
                r.put(JSONArray().put(lon + east / mLon).put(lat + north / mLat))
            }
            return r
        }

        val feats = JSONArray()
        for (p in parts(type)) {
            val rings = JSONArray().put(ring(p.pts, false))
            if (p.hole != null) rings.put(ring(p.hole, true))
            val geom = JSONObject().put("type", "Polygon").put("coordinates", rings)
            val props = JSONObject()
                .put("color", kindColor(p.kind, color))
                .put("b", p.base * lengthM)
                .put("h", p.h * lengthM)
            feats.put(JSONObject().put("type", "Feature").put("properties", props).put("geometry", geom))
        }
        return JSONObject().put("type", "FeatureCollection").put("features", feats).toString()
    }
}
