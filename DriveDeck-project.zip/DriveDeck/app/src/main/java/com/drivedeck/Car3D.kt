package com.drivedeck

import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.cos
import kotlin.math.sin

/**
 * Объёмная машинка для наклонной карты: набор «коробок» (fill-extrusion) с высотой.
 * Кабина и кузов собираются ступенями с сужением кверху — получаются скруглённые формы.
 * Единицы деталей — доли длины машины; y вперёд, x вправо.
 */
object Car3D {
    private class Part(
        val pts: List<DoubleArray>, val base: Double, val h: Double, val kind: Int,
        val hole: List<DoubleArray>? = null
    )

    // kind: 0 цвет кузова, 1 тёмный кузов, 2 стекло, 3 шины, 4 светлая крыша, 5 чёрный,
    //       8 фара, 9 задний фонарь, 10 салон, 11 диск, 12 белый
    private fun rect(x1: Double, y1: Double, x2: Double, y2: Double) = listOf(
        doubleArrayOf(x1, y1), doubleArrayOf(x2, y1), doubleArrayOf(x2, y2), doubleArrayOf(x1, y2)
    )

    /** Трапеция: снизу (сзади) ширина ±xb на y=yb, сверху (спереди) ±xt на y=yt. */
    private fun trap(xb: Double, yb: Double, xt: Double, yt: Double) = listOf(
        doubleArrayOf(-xb, yb), doubleArrayOf(xb, yb), doubleArrayOf(xt, yt), doubleArrayOf(-xt, yt)
    )

    private fun body(hw: Double, hl: Double, c: Double) = listOf(
        doubleArrayOf(-hw + c, -hl), doubleArrayOf(hw - c, -hl), doubleArrayOf(hw, -hl + c),
        doubleArrayOf(hw, hl - c), doubleArrayOf(hw - c, hl), doubleArrayOf(-hw + c, hl),
        doubleArrayOf(-hw, hl - c), doubleArrayOf(-hw, -hl + c)
    )

    private fun oct(cx: Double, cy: Double, rx: Double, ry: Double): List<DoubleArray> {
        val out = ArrayList<DoubleArray>()
        for (i in 0 until 8) {
            val a = Math.toRadians(22.5 + 45.0 * i)
            out.add(doubleArrayOf(cx + rx * cos(a), cy + ry * sin(a)))
        }
        return out
    }

    private fun wheels(x1: Double, x2: Double, yFront: Double, yRear: Double, len: Double): List<Part> = listOf(
        Part(rect(x1, yFront, x2, yFront + len), 0.0, 0.085, 3),
        Part(rect(-x2, yFront, -x1, yFront + len), 0.0, 0.085, 3),
        Part(rect(x1, yRear, x2, yRear + len), 0.0, 0.085, 3),
        Part(rect(-x2, yRear, -x1, yRear + len), 0.0, 0.085, 3)
    )

    private fun lights(hw: Double, hl: Double, w: Double, base: Double, top: Double): List<Part> = listOf(
        Part(rect(-hw, hl - 0.03, -hw + w, hl), base, top, 8),
        Part(rect(hw - w, hl - 0.03, hw, hl), base, top, 8),
        Part(rect(-hw, -hl, -hw + w, -hl + 0.03), base, top, 9),
        Part(rect(hw - w, -hl, hw, -hl + 0.03), base, top, 9)
    )

    private fun bumpers(hw: Double, hl: Double, base: Double, top: Double): List<Part> = listOf(
        Part(rect(-hw, hl - 0.018, hw, hl), base, top, 5),
        Part(rect(-hw, -hl, hw, -hl + 0.018), base, top, 5)
    )

    private fun arrow(s: Double) = listOf(
        doubleArrayOf(0.0, 0.5 * s), doubleArrayOf(0.3 * s, -0.5 * s),
        doubleArrayOf(0.0, -0.3 * s), doubleArrayOf(-0.3 * s, -0.5 * s)
    )

    private fun parts(type: String): List<Part> = when (type) {
        "suv" -> wheels(0.2, 0.265, 0.2, -0.36, 0.16) + listOf(
            Part(body(0.23, 0.5, 0.1), 0.04, 0.17, 0),
            Part(body(0.218, 0.48, 0.1), 0.17, 0.24, 0),
            Part(trap(0.2, -0.38, 0.18, 0.14), 0.24, 0.31, 2),
            Part(trap(0.186, -0.34, 0.17, 0.1), 0.31, 0.36, 2),
            Part(trap(0.176, -0.3, 0.165, 0.07), 0.36, 0.385, 4),
            Part(rect(-0.16, -0.28, -0.14, 0.05), 0.385, 0.405, 1),
            Part(rect(0.14, -0.28, 0.16, 0.05), 0.385, 0.405, 1),
            Part(trap(0.19, 0.14, 0.17, 0.44), 0.24, 0.255, 0),
            Part(rect(-0.275, 0.1, -0.23, 0.16), 0.24, 0.29, 0),
            Part(rect(0.23, 0.1, 0.275, 0.16), 0.24, 0.29, 0),
            Part(rect(-0.18, -0.5, 0.18, -0.47), 0.17, 0.25, 1)
        ) + lights(0.2, 0.5, 0.1, 0.1, 0.17) + bumpers(0.2, 0.5, 0.04, 0.1)
        "truck" -> wheels(0.17, 0.235, 0.28, -0.42, 0.14) + listOf(
            Part(rect(-0.19, -0.5, 0.19, 0.5), 0.05, 0.1, 1),
            Part(rect(-0.2, -0.5, 0.2, 0.07), 0.1, 0.34, 1),
            Part(rect(-0.18, -0.48, 0.18, 0.05), 0.34, 0.37, 4),
            Part(rect(-0.17, -0.45, 0.17, 0.02), 0.37, 0.385, 0),
            Part(body(0.19, 0.2, 0.06).map { doubleArrayOf(it[0], it[1] + 0.3) }, 0.1, 0.21, 0),
            Part(trap(0.17, 0.14, 0.15, 0.44), 0.21, 0.31, 2),
            Part(trap(0.16, 0.16, 0.145, 0.4), 0.31, 0.335, 4),
            Part(rect(-0.235, 0.3, -0.19, 0.36), 0.21, 0.26, 0),
            Part(rect(0.19, 0.3, 0.235, 0.36), 0.21, 0.26, 0)
        ) + lights(0.19, 0.5, 0.08, 0.12, 0.18) + bumpers(0.18, 0.5, 0.05, 0.11)
        "moto" -> listOf(
            Part(rect(-0.025, 0.3, 0.025, 0.5), 0.0, 0.11, 3),
            Part(rect(-0.03, -0.5, 0.03, -0.28), 0.0, 0.11, 3),
            Part(body(0.055, 0.3, 0.03), 0.08, 0.2, 0),
            Part(body(0.045, 0.14, 0.03).map { doubleArrayOf(it[0], it[1] + 0.12) }, 0.2, 0.25, 0),
            Part(rect(-0.045, -0.26, 0.045, -0.04), 0.2, 0.24, 5),
            Part(trap(0.085, -0.12, 0.065, 0.06), 0.2, 0.34, 1),
            Part(rect(-0.115, 0.0, 0.115, 0.07), 0.3, 0.36, 1),
            Part(rect(-0.135, 0.02, -0.08, 0.19), 0.28, 0.32, 1),
            Part(rect(0.08, 0.02, 0.135, 0.19), 0.28, 0.32, 1),
            Part(oct(0.0, 0.0, 0.058, 0.068), 0.36, 0.45, 0),
            Part(rect(-0.042, 0.045, 0.042, 0.068), 0.39, 0.43, 2),
            Part(rect(-0.2, 0.18, 0.2, 0.21), 0.22, 0.25, 5),
            Part(rect(-0.025, 0.47, 0.025, 0.5), 0.1, 0.15, 8)
        )
        "arrow" -> listOf(
            Part(arrow(1.0), 0.0, 0.05, 1),
            Part(arrow(0.86), 0.05, 0.09, 0),
            Part(arrow(0.66), 0.09, 0.13, 4),
            Part(
                listOf(
                    doubleArrayOf(0.0, 0.4), doubleArrayOf(0.035, -0.12),
                    doubleArrayOf(0.0, -0.08), doubleArrayOf(-0.035, -0.12)
                ), 0.13, 0.16, 12
            )
        )
        else -> wheels(0.17, 0.235, 0.2, -0.34, 0.14) + listOf(
            Part(body(0.2, 0.5, 0.11), 0.03, 0.115, 0),
            Part(body(0.188, 0.47, 0.1), 0.115, 0.15, 0),
            Part(trap(0.17, 0.08, 0.15, 0.42), 0.15, 0.162, 0),
            Part(trap(0.16, -0.44, 0.155, -0.3), 0.15, 0.16, 0),
            Part(trap(0.17, -0.28, 0.15, 0.08), 0.15, 0.21, 2),
            Part(trap(0.155, -0.24, 0.14, 0.04), 0.21, 0.26, 2),
            Part(trap(0.15, -0.2, 0.14, 0.0), 0.26, 0.285, 4),
            Part(rect(-0.24, 0.05, -0.19, 0.1), 0.15, 0.19, 0),
            Part(rect(0.19, 0.05, 0.24, 0.1), 0.15, 0.19, 0),
            Part(rect(-0.16, -0.49, 0.16, -0.46), 0.15, 0.19, 1)
        ) + lights(0.17, 0.5, 0.075, 0.09, 0.13) + bumpers(0.17, 0.5, 0.03, 0.075)
    }

    private fun shade(c: Int, f: Float) =
        Color.rgb((Color.red(c) * f).toInt(), (Color.green(c) * f).toInt(), (Color.blue(c) * f).toInt())

    private fun mix(c: Int, w: Float) = Color.rgb(
        (Color.red(c) + (255 - Color.red(c)) * w).toInt(),
        (Color.green(c) + (255 - Color.green(c)) * w).toInt(),
        (Color.blue(c) + (255 - Color.blue(c)) * w).toInt()
    )

    private fun kindColor(kind: Int, car: Int): String {
        val c = when (kind) {
            1 -> shade(car, 0.6f)
            2 -> Color.parseColor("#263238")
            3 -> Color.parseColor("#111111")
            4 -> mix(car, 0.3f)
            5 -> Color.parseColor("#1B1B1B")
            8 -> Color.parseColor("#FFF59D")
            9 -> Color.parseColor("#FF5252")
            10 -> Color.parseColor("#3A2F2A")
            11 -> Color.parseColor("#B0BEC5")
            12 -> Color.parseColor("#FFFFFF")
            else -> car
        }
        return String.format("#%06X", c and 0xFFFFFF)
    }

    /** lengthM — длина машины в метрах на местности (подбирается по масштабу карты). */
    fun geoJson(type: String, color: Int, lat: Double, lon: Double, headingDeg: Double, lengthM: Double): String {
        val th = Math.toRadians(headingDeg)
        val sinT = sin(th)
        val cosT = cos(th)
        val mLat = 111320.0
        val mLon = 111320.0 * cos(Math.toRadians(lat))

        fun ring(pts: List<DoubleArray>, reverse: Boolean): JSONArray {
            val list = if (reverse) pts.reversed() else pts
            val r = JSONArray()
            for (i in 0..list.size) {
                val q = list[i % list.size]
                val x = q[0] * lengthM
                val y = q[1] * lengthM
                val east = x * cosT + y * sinT
                val north = -x * sinT + y * cosT
                r.put(JSONArray().put(lon + east / mLon).put(lat + north / mLat))
            }
            return r
        }

        val feats = JSONArray()
        for (p in parts(type)) {
            val rings = JSONArray().put(ring(p.pts, false))
            if (p.hole != null) rings.put(ring(p.hole, true))
            val geom = JSONObject().put("type", "Polygon").put("coordinates", rings)
            val props = JSONObject()
                .put("color", kindColor(p.kind, color))
                .put("b", p.base * lengthM)
                .put("h", p.h * lengthM)
            feats.put(JSONObject().put("type", "Feature").put("properties", props).put("geometry", geom))
        }
        return JSONObject().put("type", "FeatureCollection").put("features", feats).toString()
    }
}
