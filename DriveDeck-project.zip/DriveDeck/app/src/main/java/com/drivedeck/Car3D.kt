package com.drivedeck

import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.cos
import kotlin.math.sin

/**
 * Объёмная машинка для наклонной карты: набор «коробок» (fill-extrusion) с высотой.
 * Единицы деталей — доли длины машины; y вперёд, x вправо.
 */
object Car3D {
    private class Part(val pts: List<DoubleArray>, val base: Double, val h: Double, val kind: Int)

    // kind: 0 цвет кузова, 1 тёмный кузов, 2 стекло, 3 шины, 4 светлая крыша
    private fun rect(x1: Double, y1: Double, x2: Double, y2: Double) = listOf(
        doubleArrayOf(x1, y1), doubleArrayOf(x2, y1), doubleArrayOf(x2, y2), doubleArrayOf(x1, y2)
    )

    private fun body(hw: Double, hl: Double, c: Double) = listOf(
        doubleArrayOf(-hw + c, -hl), doubleArrayOf(hw - c, -hl), doubleArrayOf(hw, -hl + c),
        doubleArrayOf(hw, hl - c), doubleArrayOf(hw - c, hl), doubleArrayOf(-hw + c, hl),
        doubleArrayOf(-hw, hl - c), doubleArrayOf(-hw, -hl + c)
    )

    private fun wheels(x1: Double, x2: Double, yFront: Double, yRear: Double, len: Double): List<Part> = listOf(
        Part(rect(x1, yFront, x2, yFront + len), 0.0, 0.07, 3),
        Part(rect(-x2, yFront, -x1, yFront + len), 0.0, 0.07, 3),
        Part(rect(x1, yRear, x2, yRear + len), 0.0, 0.07, 3),
        Part(rect(-x2, yRear, -x1, yRear + len), 0.0, 0.07, 3)
    )

    private fun parts(type: String): List<Part> = when (type) {
        "suv" -> wheels(0.19, 0.25, 0.2, -0.36, 0.16) + listOf(
            Part(body(0.22, 0.5, 0.08), 0.05, 0.19, 0),
            Part(rect(-0.18, -0.34, 0.18, 0.16), 0.19, 0.32, 2),
            Part(rect(-0.17, -0.3, 0.17, 0.12), 0.32, 0.35, 4)
        )
        "truck" -> wheels(0.17, 0.23, 0.28, -0.42, 0.14) + listOf(
            Part(rect(-0.19, -0.5, 0.19, 0.5), 0.05, 0.1, 1),
            Part(body(0.19, 0.5, 0.05).map { doubleArrayOf(it[0], it[1] * 0.38 + 0.31) }, 0.1, 0.3, 0),
            Part(rect(-0.17, 0.14, 0.17, 0.4), 0.3, 0.32, 4),
            Part(rect(-0.2, -0.5, 0.2, 0.08), 0.1, 0.38, 1)
        )
        "moto" -> listOf(
            Part(rect(-0.025, 0.3, 0.025, 0.5), 0.0, 0.1, 3),
            Part(rect(-0.03, -0.5, 0.03, -0.3), 0.0, 0.1, 3),
            Part(rect(-0.05, -0.3, 0.05, 0.3), 0.08, 0.2, 0),
            Part(rect(-0.075, -0.12, 0.075, 0.08), 0.2, 0.38, 1),
            Part(rect(-0.045, -0.02, 0.045, 0.08), 0.38, 0.46, 0)
        )
        "arrow" -> listOf(
            Part(
                listOf(
                    doubleArrayOf(0.0, 0.5), doubleArrayOf(0.3, -0.5),
                    doubleArrayOf(0.0, -0.3), doubleArrayOf(-0.3, -0.5)
                ), 0.0, 0.08, 0
            ),
            Part(
                listOf(
                    doubleArrayOf(0.0, 0.4), doubleArrayOf(0.12, -0.2),
                    doubleArrayOf(0.0, -0.12), doubleArrayOf(-0.12, -0.2)
                ), 0.08, 0.12, 4
            )
        )
        else -> wheels(0.17, 0.23, 0.2, -0.34, 0.14) + listOf(
            Part(body(0.2, 0.5, 0.07), 0.04, 0.15, 0),
            Part(rect(-0.16, -0.25, 0.16, 0.1), 0.15, 0.26, 2),
            Part(rect(-0.15, -0.21, 0.15, 0.06), 0.26, 0.285, 4)
        )
    }

    private fun shade(c: Int, f: Float) =
        Color.rgb((Color.red(c) * f).toInt(), (Color.green(c) * f).toInt(), (Color.blue(c) * f).toInt())

    private fun mix(c: Int, w: Float) = Color.rgb(
        (Color.red(c) + (255 - Color.red(c)) * w).toInt(),
        (Color.green(c) + (255 - Color.green(c)) * w).toInt(),
        (Color.blue(c) + (255 - Color.blue(c)) * w).toInt()
    )

    private fun kindColor(kind: Int, car: Int): String {
        val c = when (kind) {
            1 -> shade(car, 0.6f)
            2 -> Color.parseColor("#263238")
            3 -> Color.parseColor("#111111")
            4 -> mix(car, 0.3f)
            else -> car
        }
        return String.format("#%06X", c and 0xFFFFFF)
    }

    /** lengthM — длина машины в метрах на местности (подбирается по масштабу карты). */
    fun geoJson(type: String, color: Int, lat: Double, lon: Double, headingDeg: Double, lengthM: Double): String {
        val th = Math.toRadians(headingDeg)
        val sinT = sin(th)
        val cosT = cos(th)
        val mLat = 111320.0
        val mLon = 111320.0 * cos(Math.toRadians(lat))
        val feats = JSONArray()
        for (p in parts(type)) {
            val ring = JSONArray()
            for (i in 0..p.pts.size) {
                val q = p.pts[i % p.pts.size]
                val x = q[0] * lengthM
                val y = q[1] * lengthM
                val east = x * cosT + y * sinT
                val north = -x * sinT + y * cosT
                ring.put(JSONArray().put(lon + east / mLon).put(lat + north / mLat))
            }
            val geom = JSONObject().put("type", "Polygon").put("coordinates", JSONArray().put(ring))
            val props = JSONObject()
                .put("color", kindColor(p.kind, color))
                .put("b", p.base * lengthM)
                .put("h", p.h * lengthM)
            feats.put(JSONObject().put("type", "Feature").put("properties", props).put("geometry", geom))
        }
        return JSONObject().put("type", "FeatureCollection").put("features", feats).toString()
    }
}
